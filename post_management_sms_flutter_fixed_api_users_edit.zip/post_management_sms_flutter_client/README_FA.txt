نسخه ادغام‌شده Flutter: سامانه مرسولات + پنل پیامکی آنلاین

این نسخه پیامک‌ها را روی گوشی ذخیره نمی‌کند.
پیام‌ها در جدول sms_messages داخل همان دیتابیس MySQL سامانه مرسولات ذخیره می‌شوند.

ساختار:
- lib/main.dart: کد اپ Flutter
- pubspec.yaml: پکیج‌های لازم
- BACKEND_PATCH: فایل‌های PHP جدید برای قرار دادن داخل پوشه api روی هاست
- .github/workflows/build-apk.yml: ورک‌فلو آماده ساخت APK

مهم:
کلید API پیامک داخل Flutter نیست و نباید داخل GitHub عمومی باشد.
کلیدها فقط باید روی هاست، داخل فایل api/sms_service_config.php ذخیره شوند.

نصب بک‌اند روی هاست:
1) از پوشه BACKEND_PATCH همه فایل‌های PHP را داخل پوشه api پروژه قبلی آپلود کن.
   یعنی کنار فایل‌های زیر قرار بگیرند:
   api/config.php
   api/login.php
   api/shipments.php

2) فایل api/sms_service_config.php را باز کن و اطلاعات سرویس پیامکی را وارد کن:
   SMSIR_API_KEY
   SMSIR_DEFAULT_SENDER
   MELI_USERNAME
   MELI_PASSWORD_OR_APIKEY
   MELI_DEFAULT_SENDER

3) وارد اپ شو و آدرس API قبلی را بزن، مثل:
   https://your-domain.com/api

4) از داخل مرورگر یا Postman یک بار این آدرس را با توکن ورود اجرا کن:
   https://your-domain.com/api/sms_migrate.php

راه ساده‌تر:
بعد از نصب فایل‌ها، اگر از اپ وارد شوی و به بخش پیامک بروی، جدول‌ها در بیشتر endpointها خودکار هم ساخته می‌شوند؛ ولی اجرای sms_migrate.php برای اطمینان بهتر است.

ساخت APK با GitHub:
1) محتوای همین ZIP را داخل ریپوی GitHub بریز.
2) تب Actions را باز کن.
3) Workflow با نام Build Flutter APK را Run کن.
4) بعد از سبز شدن، از بخش Artifacts فایل APK را دانلود کن.

نکته امنیتی مهم:
اگر ریپوی GitHub عمومی است، فایل sms_service_config.php واقعیِ دارای API Key را داخل GitHub نگذار.
آن فایل فقط باید روی هاست باشد.
