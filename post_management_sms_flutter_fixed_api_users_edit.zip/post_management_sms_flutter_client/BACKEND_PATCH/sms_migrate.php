<?php
require_once __DIR__ . '/sms_common.php';
try{
  $u = user();
  sms_ensure_tables();
  if(function_exists('log_event')) log_event($u['username'] ?? 'system','sms_migrate','database',null,'ساخت جدول پیامک انجام شد');
  out(['ok'=>true,'message'=>'جدول پیامک روی همین دیتابیس سامانه مرسولات آماده شد.']);
}catch(Throwable $e){
  out(['ok'=>false,'error'=>'خطای ساخت جدول پیامک: '.$e->getMessage()],500);
}
?>
