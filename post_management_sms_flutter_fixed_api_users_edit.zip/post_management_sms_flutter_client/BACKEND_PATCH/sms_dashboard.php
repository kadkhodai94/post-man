<?php
require_once __DIR__ . '/sms_common.php';
try{
  sms_ensure_tables();
  $u=user();
  $where=[]; $params=[];
  if(($u['role'] ?? '') !== 'admin') { $where[]='created_by=?'; $params[]=$u['username'] ?? ''; }
  $w=$where?' WHERE '.implode(' AND ',$where):'';
  $st=db()->prepare("SELECT COUNT(*) FROM sms_messages$w"); $st->execute($params); $total=(int)$st->fetchColumn();
  $st=db()->prepare("SELECT COUNT(*) FROM sms_messages".($w?$w.' AND':' WHERE')." DATE(created_at)=CURDATE()"); $st->execute($params); $today=(int)$st->fetchColumn();
  $st=db()->prepare("SELECT COUNT(*) FROM sms_messages".($w?$w.' AND':' WHERE')." DATE_FORMAT(created_at,'%Y-%m')=DATE_FORMAT(CURDATE(),'%Y-%m')"); $st->execute($params); $month=(int)$st->fetchColumn();
  $st=db()->prepare("SELECT COUNT(*) FROM sms_messages".($w?$w.' AND':' WHERE')." delivery_level='delivered'"); $st->execute($params); $delivered=(int)$st->fetchColumn();
  $st=db()->prepare("SELECT COUNT(*) FROM sms_messages".($w?$w.' AND':' WHERE')." delivery_level='failed'"); $st->execute($params); $failed=(int)$st->fetchColumn();
  $waiting=max(0,$total-$delivered-$failed);
  out(['ok'=>true,'data'=>['total'=>$total,'today'=>$today,'month'=>$month,'delivered'=>$delivered,'failed'=>$failed,'waiting'=>$waiting]]);
}catch(Throwable $e){out(['ok'=>false,'error'=>'خطای داشبورد پیامک: '.$e->getMessage()],500);} 
?>
