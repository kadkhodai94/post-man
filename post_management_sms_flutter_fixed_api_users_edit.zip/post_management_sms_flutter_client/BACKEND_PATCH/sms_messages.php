<?php
require_once __DIR__ . '/sms_common.php';
try{
  sms_ensure_tables();
  $u=user();
  $where=[]; $params=[];
  if(($u['role'] ?? '') !== 'admin') { $where[]='created_by=?'; $params[]=$u['username'] ?? ''; }
  $q=trim((string)($_GET['q'] ?? ''));
  if($q!==''){
    $where[]='(receiver LIKE ? OR full_name LIKE ? OR text LIKE ? OR group_title LIKE ? OR rec_id LIKE ?)';
    $like='%'.$q.'%'; array_push($params,$like,$like,$like,$like,$like);
  }
  if(($_GET['today'] ?? '')==='1' && $q==='') $where[]='DATE(created_at)=CURDATE()';
  $sql='SELECT * FROM sms_messages';
  if($where) $sql.=' WHERE '.implode(' AND ',$where);
  $sql.=' ORDER BY id DESC LIMIT 500';
  $st=db()->prepare($sql); $st->execute($params);
  out(['ok'=>true,'data'=>$st->fetchAll()]);
}catch(Throwable $e){out(['ok'=>false,'error'=>'خطای دریافت پیام‌ها: '.$e->getMessage()],500);} 
?>
