<?php
require_once __DIR__ . '/sms_common.php';
try{
  sms_ensure_tables();
  $u = user();
  if(($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') out(['ok'=>false,'error'=>'این آدرس فقط POST قبول می‌کند'],405);
  $d=sms_json_input();
  $service=sms_normalize_service($d['service'] ?? $d['provider'] ?? 'smsir');
  $sender=sms_normalize_line($d['sender'] ?? ($service==='smsir'?SMSIR_DEFAULT_SENDER:MELI_DEFAULT_SENDER));
  $receiversRaw=trim((string)($d['receivers'] ?? ''));
  $text=trim((string)($d['text'] ?? ''));
  $groupTitle=trim((string)($d['group_title'] ?? ''));
  if($sender==='' || $receiversRaw==='' || $text==='') out(['ok'=>false,'error'=>'شماره فرستنده، گیرنده یا متن پیام خالی است'],422);

  $receivers=preg_split('/[\s,،]+/u',$receiversRaw,-1,PREG_SPLIT_NO_EMPTY);
  $receivers=array_values(array_unique(array_map('sms_normalize_mobile',$receivers)));
  $receivers=array_values(array_filter($receivers,function($n){ return preg_match('/^09\d{9}$/',$n); }));
  if(!$receivers) out(['ok'=>false,'error'=>'شماره گیرنده معتبر نیست. فرمت درست مثل 09123456789 است'],422);
  if(count($receivers)>100) out(['ok'=>false,'error'=>'در هر ارسال حداکثر ۱۰۰ شماره مجاز است'],422);

  $sendType=sms_detect_send_type(count($receivers),$service);
  $results=[];
  if($service==='smsir') $results=sms_send_smsir_bulk($receivers,$sender,$text);
  else foreach($receivers as $receiver) $results[]=sms_send_melli($receiver,$sender,$text)+['receiver'=>$receiver];

  $groupId='sms_'.date('Ymd_His').'_'.bin2hex(random_bytes(4));
  $success=0; $failed=0; $saved=[];
  $stmt=db()->prepare("INSERT INTO sms_messages
    (group_id,group_title,group_size,receiver,full_name,sender,text,service,rec_id,pack_id,send_ok,send_status,send_api_code,send_raw,send_http_code,send_method,send_type,send_type_label,delivery_text,delivery_level,created_by,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())");
  foreach($results as $r){
    $ok=!empty($r['ok']);
    if($ok) $success++; else $failed++;
    $deliveryText=$ok?'در انتظار گزارش دلیوری':'شناسه دلیوری واقعی دریافت نشد';
    $deliveryLevel=$ok?'pending':'unknown';
    $stmt->execute([
      $groupId,$groupTitle,count($receivers),$r['receiver'] ?? '', '', $sender,$text,$service,
      $r['rec_id'] ?? '',$r['pack_id'] ?? '',$ok?1:0,$r['status_text'] ?? '',$r['api_code'] ?? '',
      $r['raw_response'] ?? '',(string)($r['http_code'] ?? ''),$r['method'] ?? '',$sendType['send_type'],$sendType['send_type_label'],
      $deliveryText,$deliveryLevel,$u['username'] ?? ''
    ]);
    $saved[]=['id'=>db()->lastInsertId(),'receiver'=>$r['receiver'] ?? '','ok'=>$ok,'rec_id'=>$r['rec_id'] ?? '','status_text'=>$r['status_text'] ?? ''];
  }
  if(function_exists('log_event')) log_event($u['username'] ?? '','sms_send','sms_messages',$groupId,'ارسال پیامک: موفق '.$success.' / ناموفق '.$failed,null,['service'=>$service,'count'=>count($receivers)]);
  out(['ok'=>true,'message'=>'ارسال انجام و آنلاین ذخیره شد','service'=>$service,'success_count'=>$success,'failed_count'=>$failed,'count'=>count($results),'send_type'=>$sendType['send_type'],'send_type_label'=>$sendType['send_type_label'],'data'=>$saved]);
}catch(Throwable $e){
  out(['ok'=>false,'error'=>'خطای ارسال پیامک: '.$e->getMessage()],500);
}
?>
