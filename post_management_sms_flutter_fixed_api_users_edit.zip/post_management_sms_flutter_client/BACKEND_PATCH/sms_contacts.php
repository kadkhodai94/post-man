<?php
require_once __DIR__ . '/sms_common.php';
try{
  sms_ensure_tables();
  $u=user();
  $where=[]; $params=[];
  if(($u['role'] ?? '') !== 'admin') { $where[]='created_by=?'; $params[]=$u['username'] ?? ''; }
  $sql="SELECT receiver AS number, MAX(full_name) AS name, COUNT(*) AS count, MAX(created_at) AS last_at FROM sms_messages";
  if($where) $sql.=' WHERE '.implode(' AND ',$where);
  $sql.=" GROUP BY receiver ORDER BY last_at DESC LIMIT 2000";
  $st=db()->prepare($sql); $st->execute($params);
  out(['ok'=>true,'data'=>$st->fetchAll()]);
}catch(Throwable $e){out(['ok'=>false,'error'=>'خطای استخراج شماره‌ها: '.$e->getMessage()],500);} 
?>
