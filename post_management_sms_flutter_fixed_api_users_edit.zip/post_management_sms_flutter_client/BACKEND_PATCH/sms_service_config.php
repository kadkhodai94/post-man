<?php
/*
  تنظیمات سرویس پیامک
  این فایل را روی هاست و کنار api/config.php قرار بده.
  این فایل را داخل GitHub عمومی قرار نده؛ چون شامل کلیدهای API است.
*/

/* ملی پیامک */
const MELI_USERNAME = 'PUT_MELI_USERNAME_HERE';
const MELI_PASSWORD_OR_APIKEY = 'PUT_MELI_APIKEY_HERE';
const MELI_DEFAULT_SENDER = '50000000000000';

/* SMS.ir */
const SMSIR_API_KEY = 'PUT_SMSIR_API_KEY_HERE';
const SMSIR_DEFAULT_SENDER = '30000000000000';
const SMSIR_API_BASE_URL = 'https://api.sms.ir/v1';

const SMS_APP_DEBUG = false;
?>
