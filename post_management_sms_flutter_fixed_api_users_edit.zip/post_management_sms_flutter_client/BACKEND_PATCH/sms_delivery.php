<?php
require_once __DIR__ . '/sms_common.php';
try{
  sms_ensure_tables();
  $u=user();
  if(($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') out(['ok'=>false,'error'=>'این آدرس فقط POST قبول می‌کند'],405);
  $d=sms_json_input();
  $id=(int)($d['id'] ?? 0);
  $service=sms_normalize_service($d['service'] ?? 'smsir');
  $recId=sms_normalize_line($d['rec_id'] ?? $d['recId'] ?? '');
  if(!$recId) out(['ok'=>false,'error'=>'شناسه پیام / recId ارسال نشده است'],422);
  if(!preg_match('/^\d{6,}$/',$recId)){
    $result=['ok'=>false,'service'=>$service,'rec_id'=>$recId,'http_code'=>0,'delivery_code'=>'','delivery_text'=>'شناسه دلیوری واقعی نیست؛ این مقدار کد پاسخ API است','delivery_level'=>'unknown','raw_response'=>''];
  } else {
    $result=$service==='smsir' ? sms_get_smsir_delivery($recId) : sms_get_melli_delivery($recId);
  }
  if($id>0){
    $where='id=?'; $params=[
      $result['delivery_code'] ?? '',$result['delivery_text'] ?? '',$result['delivery_level'] ?? 'unknown',$id
    ];
    if(($u['role'] ?? '') !== 'admin'){ $where.=' AND created_by=?'; $params[]=$u['username'] ?? ''; }
    db()->prepare("UPDATE sms_messages SET delivery_code=?, delivery_text=?, delivery_level=?, delivery_checked_at=NOW() WHERE $where")->execute($params);
  }
  if(function_exists('log_event')) log_event($u['username'] ?? '','sms_delivery','sms_messages',$id ?: $recId,'بررسی دلیوری پیامک');
  out(['ok'=>true,'message'=>'دلیوری بررسی شد','result'=>$result]);
}catch(Throwable $e){out(['ok'=>false,'error'=>'خطای بررسی دلیوری: '.$e->getMessage()],500);} 
?>
