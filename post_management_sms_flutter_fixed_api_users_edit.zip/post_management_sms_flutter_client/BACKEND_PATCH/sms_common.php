<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/sms_service_config.php';

function sms_json_input(){
  $raw=file_get_contents('php://input');
  $json=json_decode($raw,true);
  if(is_array($json)) return $json;
  return $_POST ?: [];
}

function sms_normalize_digits($value){
  $fa=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
  $en=['0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9'];
  return str_replace($fa,$en,(string)$value);
}

function sms_normalize_mobile($number){
  $number=trim(sms_normalize_digits($number));
  $number=preg_replace('/[^0-9+]/','',$number);
  if(strpos($number,'+98')===0) $number='0'.substr($number,3);
  if(strpos($number,'0098')===0) $number='0'.substr($number,4);
  if(strpos($number,'98')===0 && strlen($number)===12) $number='0'.substr($number,2);
  return $number;
}

function sms_normalize_line($sender){
  return preg_replace('/\D+/','',sms_normalize_digits($sender));
}

function sms_normalize_service($service){
  $service=strtolower(trim((string)$service));
  if(in_array($service,['smsir','sms.ir','sms_ir','sms-ir'],true)) return 'smsir';
  if(in_array($service,['melli','melipayamak','meli'],true)) return 'melli';
  return 'smsir';
}

function sms_shorten($value,$limit=5000){
  if(is_string($value) && strlen($value)>$limit) return substr($value,0,$limit).'...[truncated]';
  return $value;
}

function sms_ensure_tables(){
  db()->exec("CREATE TABLE IF NOT EXISTS sms_messages (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    group_id VARCHAR(80) NULL,
    group_title VARCHAR(255) NULL,
    group_size INT NOT NULL DEFAULT 1,
    receiver VARCHAR(30) NOT NULL,
    first_name VARCHAR(100) NULL,
    last_name VARCHAR(100) NULL,
    full_name VARCHAR(255) NULL,
    sender VARCHAR(40) NULL,
    text TEXT NOT NULL,
    service VARCHAR(20) NOT NULL DEFAULT 'smsir',
    rec_id VARCHAR(100) NULL,
    pack_id VARCHAR(100) NULL,
    send_ok TINYINT(1) NOT NULL DEFAULT 0,
    send_status TEXT NULL,
    send_api_code VARCHAR(100) NULL,
    send_raw MEDIUMTEXT NULL,
    send_http_code VARCHAR(20) NULL,
    send_method VARCHAR(120) NULL,
    send_type VARCHAR(50) NULL,
    send_type_label VARCHAR(120) NULL,
    delivery_code VARCHAR(80) NULL,
    delivery_text TEXT NULL,
    delivery_level VARCHAR(40) NOT NULL DEFAULT 'unknown',
    delivery_checked_at DATETIME NULL,
    created_by VARCHAR(50) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sms_created_at(created_at),
    INDEX idx_sms_receiver(receiver),
    INDEX idx_sms_rec_id(rec_id),
    INDEX idx_sms_group(group_id),
    INDEX idx_sms_created_by(created_by)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function sms_detect_send_type($count,$service){
  if($service==='smsir') return ['send_type'=>'smsir_bulk','send_type_label'=>'SMS.ir / Bulk','send_type_note'=>'ارسال با SMS.ir انجام شد و پیام‌ها آنلاین ذخیره شدند.'];
  return ['send_type'=>'single_batch','send_type_label'=>'ارسال تکی پشت‌سرهم','send_type_note'=>'برای دلیوری دقیق، هر شماره جداگانه ارسال و ذخیره شد.'];
}

function sms_status_message_melli($code){
  $map=['0'=>'نام کاربری یا رمز/APIKey اشتباه است','1'=>'درخواست با موفقیت انجام شد','2'=>'اعتبار کافی نیست','3'=>'محدودیت ارسال روزانه','4'=>'محدودیت حجم ارسال','5'=>'شماره فرستنده معتبر نیست','7'=>'متن حاوی کلمه فیلتر شده است','10'=>'کاربر فعال نیست','11'=>'ارسال نشده','16'=>'شماره گیرنده‌ای یافت نشد','17'=>'متن پیام خالی است','18'=>'شماره گیرنده نامعتبر است','-110'=>'الزام استفاده از APIKey به جای رمز عبور','-109'=>'IP مجاز تنظیم نشده است'];
  $key=(string)$code;
  return $map[$key] ?? 'پاسخ API: '.$key;
}

function smsir_status_message($code){
  $map=['1'=>'عملیات با موفقیت انجام شد','10'=>'کلید وب‌سرویس نامعتبر است','11'=>'کلید وب‌سرویس غیرفعال است','12'=>'کلید محدود به IP است','13'=>'حساب کاربری غیرفعال است','14'=>'حساب در تعلیق است','20'=>'تعداد درخواست بیشتر از حد مجاز است','101'=>'شماره خط نامعتبر است','102'=>'اعتبار کافی نیست','103'=>'متن پیام خالی است','104'=>'شماره موبایل نادرست است','105'=>'تعداد موبایل‌ها بیشتر از حد مجاز است','107'=>'لیست موبایل‌ها خالی است','115'=>'شماره در لیست سیاه است','117'=>'متن ارسال‌شده مورد تأیید نیست','123'=>'خط ارسال‌کننده نیاز به فعال‌سازی دارد'];
  $key=(string)$code;
  return $map[$key] ?? 'کد وضعیت SMS.ir: '.$key;
}

function sms_parse_asmx_response($response){
  $clean=trim(strip_tags((string)$response));
  if(preg_match('/-?\d+/',$clean,$m)) return $m[0];
  return $clean;
}

function sms_send_melli($to,$from,$text){
  if(!function_exists('curl_init')) return ['ok'=>false,'method'=>'curl SendSimpleSMS2','http_code'=>0,'api_code'=>'','rec_id'=>'','status_text'=>'افزونه cURL روی هاست فعال نیست','raw_response'=>''];
  if(MELI_USERNAME==='' || MELI_USERNAME==='PUT_MELI_USERNAME_HERE' || MELI_PASSWORD_OR_APIKEY==='' || MELI_PASSWORD_OR_APIKEY==='PUT_MELI_APIKEY_HERE') return ['ok'=>false,'method'=>'ملی پیامک','http_code'=>0,'api_code'=>'','rec_id'=>'','status_text'=>'تنظیمات ملی پیامک کامل نشده است','raw_response'=>''];
  $url='https://api.payamak-panel.com/post/Send.asmx/SendSimpleSMS2';
  $fields=http_build_query(['username'=>MELI_USERNAME,'password'=>MELI_PASSWORD_OR_APIKEY,'to'=>$to,'from'=>$from,'text'=>$text,'isflash'=>'false'],'','&');
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$fields,CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded; charset=utf-8'],CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>45,CURLOPT_SSL_VERIFYPEER=>true]);
  $response=curl_exec($ch); $curlErr=curl_error($ch); $httpCode=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  if($curlErr) return ['ok'=>false,'method'=>'ملی پیامک / SendSimpleSMS2','http_code'=>$httpCode,'api_code'=>'','rec_id'=>'','status_text'=>'خطای اتصال cURL: '.$curlErr,'raw_response'=>$response ?: ''];
  $apiCode=sms_parse_asmx_response($response);
  $numeric=is_numeric($apiCode)?(int)$apiCode:null;
  $isReal=($numeric!==null && preg_match('/^\d{6,}$/',(string)$apiCode));
  return ['ok'=>($httpCode>=200 && $httpCode<300 && $isReal),'method'=>'ملی پیامک / SendSimpleSMS2','service'=>'melli','http_code'=>$httpCode,'api_code'=>(string)$apiCode,'rec_id'=>$isReal?(string)$apiCode:'','status_text'=>$isReal?'ارسال اولیه موفق؛ شناسه دلیوری دریافت شد':($numeric!==null?sms_status_message_melli($numeric):'پاسخ API قابل تشخیص نیست'),'raw_response'=>SMS_APP_DEBUG?(string)$response:($isReal?(string)$apiCode:sms_status_message_melli($apiCode))];
}

function sms_send_smsir_bulk($receivers,$from,$text){
  $results=[];
  if(!function_exists('curl_init')){
    foreach($receivers as $r) $results[]=['receiver'=>$r,'ok'=>false,'method'=>'SMS.ir / send/bulk','service'=>'smsir','http_code'=>0,'api_code'=>'','rec_id'=>'','pack_id'=>'','status_text'=>'افزونه cURL روی هاست فعال نیست','raw_response'=>''];
    return $results;
  }
  if(SMSIR_API_KEY==='' || SMSIR_API_KEY==='PUT_SMSIR_API_KEY_HERE'){
    foreach($receivers as $r) $results[]=['receiver'=>$r,'ok'=>false,'method'=>'SMS.ir / send/bulk','service'=>'smsir','http_code'=>0,'api_code'=>'','rec_id'=>'','pack_id'=>'','status_text'=>'API Key سامانه SMS.ir تنظیم نشده است','raw_response'=>''];
    return $results;
  }
  $url=rtrim(SMSIR_API_BASE_URL,'/').'/send/bulk';
  $payload=['lineNumber'=>(int)$from,'messageText'=>$text,'mobiles'=>array_values($receivers),'sendDateTime'=>null];
  $headers=['Content-Type: application/json','Accept: application/json','X-API-KEY: '.SMSIR_API_KEY];
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_HTTPHEADER=>$headers,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>45,CURLOPT_SSL_VERIFYPEER=>true]);
  $response=curl_exec($ch); $curlErr=curl_error($ch); $httpCode=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  if($curlErr){
    foreach($receivers as $r) $results[]=['receiver'=>$r,'ok'=>false,'method'=>'SMS.ir / send/bulk','service'=>'smsir','http_code'=>$httpCode,'api_code'=>'','rec_id'=>'','pack_id'=>'','status_text'=>'خطای اتصال cURL به SMS.ir: '.$curlErr,'raw_response'=>$response ?: ''];
    return $results;
  }
  $json=json_decode((string)$response,true);
  if(!is_array($json)){
    foreach($receivers as $r) $results[]=['receiver'=>$r,'ok'=>false,'method'=>'SMS.ir / send/bulk','service'=>'smsir','http_code'=>$httpCode,'api_code'=>'','rec_id'=>'','pack_id'=>'','status_text'=>'پاسخ SMS.ir JSON نبود','raw_response'=>SMS_APP_DEBUG?sms_shorten((string)$response):''];
    return $results;
  }
  $status=$json['status'] ?? null;
  $message=isset($json['message'])?(string)$json['message']:smsir_status_message($status);
  $data=is_array($json['data'] ?? null)?$json['data']:[];
  $messageIds=is_array($data['messageIds'] ?? null)?$data['messageIds']:[];
  $packId=$data['packId'] ?? '';
  for($i=0;$i<count($receivers);$i++){
    $id=$messageIds[$i] ?? null;
    $ok=($httpCode>=200 && $httpCode<300 && (string)$status==='1' && is_scalar($id) && preg_match('/^\d{6,}$/',(string)$id) && (int)$id>0);
    if($ok) $statusText='ارسال اولیه موفق؛ شناسه دلیوری SMS.ir دریافت شد';
    elseif($id===0 || $id==='0') $statusText='ارسال نشد: شماره در لیست سیاه SMS.ir است';
    elseif($id===null && (string)$status==='1') $statusText='ارسال نشد: شماره نامعتبر است یا متن بیش از حد مجاز است';
    else $statusText=$message ?: smsir_status_message($status);
    $results[]=['receiver'=>$receivers[$i],'ok'=>$ok,'method'=>'SMS.ir / send/bulk','service'=>'smsir','http_code'=>$httpCode,'api_code'=>$id!==null?(string)$id:(string)($status ?? ''),'rec_id'=>$ok?(string)$id:'','pack_id'=>(string)$packId,'status_text'=>$statusText,'raw_response'=>SMS_APP_DEBUG?sms_shorten((string)$response):($ok?(string)$id:$statusText)];
  }
  return $results;
}

function smsir_delivery_text($code){
  $map=['1'=>'رسیده به گوشی','2'=>'نرسیده به گوشی','3'=>'رسیده به مخابرات','4'=>'نرسیده به مخابرات','5'=>'رسیده به مخابرات','6'=>'خطا در ارسال','7'=>'لیست سیاه','8'=>'نامشخص'];
  $key=(string)$code;
  return $map[$key] ?? 'وضعیت دلیوری: '.$key;
}
function smsir_delivery_level($code){
  $key=(string)$code;
  if($key==='1') return 'delivered';
  if(in_array($key,['2','4','6','7'],true)) return 'failed';
  if(in_array($key,['3','5'],true)) return 'operator';
  return 'unknown';
}
function melli_delivery_text($code){
  $map=['0'=>'ارسال شده به مخابرات','1'=>'رسیده به گوشی','2'=>'نرسیده به گوشی','3'=>'خطا در ارسال','5'=>'رسیده به مخابرات','8'=>'رسیده به مخابرات','16'=>'پیامک یافت نشد'];
  $key=(string)$code;
  return $map[$key] ?? 'وضعیت دلیوری: '.$key;
}
function melli_delivery_level($code){
  $key=(string)$code;
  if($key==='1') return 'delivered';
  if(in_array($key,['2','3','16'],true)) return 'failed';
  if(in_array($key,['0','5','8'],true)) return 'operator';
  return 'unknown';
}

function sms_get_smsir_delivery($messageId){
  if(!function_exists('curl_init')) return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>0,'delivery_code'=>'','delivery_text'=>'افزونه cURL روی هاست فعال نیست','delivery_level'=>'unknown','raw_response'=>''];
  if(SMSIR_API_KEY==='' || SMSIR_API_KEY==='PUT_SMSIR_API_KEY_HERE') return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>0,'delivery_code'=>'','delivery_text'=>'API Key سامانه SMS.ir تنظیم نشده است','delivery_level'=>'unknown','raw_response'=>''];
  $url=rtrim(SMSIR_API_BASE_URL,'/').'/send/'.rawurlencode($messageId);
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Accept: application/json','X-API-KEY: '.SMSIR_API_KEY],CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>30,CURLOPT_SSL_VERIFYPEER=>true]);
  $response=curl_exec($ch); $curlErr=curl_error($ch); $httpCode=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  if($curlErr) return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>$httpCode,'delivery_code'=>'','delivery_text'=>'خطای اتصال cURL به SMS.ir: '.$curlErr,'delivery_level'=>'unknown','raw_response'=>$response ?: ''];
  $json=json_decode((string)$response,true);
  if(!is_array($json)) return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>$httpCode,'delivery_code'=>'','delivery_text'=>'پاسخ دلیوری SMS.ir JSON نبود','delivery_level'=>'unknown','raw_response'=>SMS_APP_DEBUG?sms_shorten((string)$response):''];
  $status=$json['status'] ?? null;
  $message=isset($json['message'])?(string)$json['message']:'';
  $data=is_array($json['data'] ?? null)?$json['data']:[];
  if((string)$status!=='1') return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>$httpCode,'delivery_code'=>(string)($status ?? ''),'delivery_text'=>$message ?: 'خطا در دریافت دلیوری SMS.ir','delivery_level'=>'unknown','raw_response'=>SMS_APP_DEBUG?sms_shorten((string)$response):''];
  $code=array_key_exists('deliveryState',$data)?$data['deliveryState']:'';
  return ['ok'=>true,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>$httpCode,'delivery_code'=>(string)$code,'delivery_text'=>smsir_delivery_text($code),'delivery_level'=>smsir_delivery_level($code),'raw_response'=>SMS_APP_DEBUG?sms_shorten((string)$response):(string)$code];
}

function sms_get_melli_delivery($recId){
  if(!function_exists('curl_init')) return ['ok'=>false,'service'=>'melli','rec_id'=>$recId,'http_code'=>0,'delivery_code'=>'','delivery_text'=>'افزونه cURL روی هاست فعال نیست','delivery_level'=>'unknown','raw_response'=>''];
  if(MELI_USERNAME==='' || MELI_USERNAME==='PUT_MELI_USERNAME_HERE' || MELI_PASSWORD_OR_APIKEY==='' || MELI_PASSWORD_OR_APIKEY==='PUT_MELI_APIKEY_HERE') return ['ok'=>false,'service'=>'melli','rec_id'=>$recId,'http_code'=>0,'delivery_code'=>'','delivery_text'=>'تنظیمات ملی پیامک کامل نشده است','delivery_level'=>'unknown','raw_response'=>''];
  $url='https://api.payamak-panel.com/post/Send.asmx/GetDelivery';
  $fields=http_build_query(['username'=>MELI_USERNAME,'password'=>MELI_PASSWORD_OR_APIKEY,'recId'=>$recId],'','&');
  $ch=curl_init($url);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$fields,CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded; charset=utf-8'],CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>45,CURLOPT_SSL_VERIFYPEER=>true]);
  $response=curl_exec($ch); $curlErr=curl_error($ch); $httpCode=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  if($curlErr) return ['ok'=>false,'service'=>'melli','rec_id'=>$recId,'http_code'=>$httpCode,'delivery_code'=>'','delivery_text'=>'خطای اتصال cURL: '.$curlErr,'delivery_level'=>'unknown','raw_response'=>$response ?: ''];
  $code=sms_parse_asmx_response($response);
  return ['ok'=>($httpCode>=200 && $httpCode<300 && is_numeric($code)),'service'=>'melli','rec_id'=>$recId,'http_code'=>$httpCode,'delivery_code'=>(string)$code,'delivery_text'=>is_numeric($code)?melli_delivery_text($code):'پاسخ دلیوری قابل تشخیص نیست','delivery_level'=>melli_delivery_level($code),'raw_response'=>SMS_APP_DEBUG?(string)$response:(string)$code];
}
?>
