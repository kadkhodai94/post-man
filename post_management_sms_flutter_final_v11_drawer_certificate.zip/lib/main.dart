import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const PostSmsApp());

const persianMonths = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

const shipmentTypes = ['بسته', 'پاکت', 'امانت', 'گواهینامه', 'کارت سوخت', 'کارت بانکی', 'کارت پلاک', 'برگ سبز'];

const String kDefaultApiBase = 'https://podtman.anony.ir/post/api';
const int kAppVersionCode = 11;
const String kAppVersionName = '1.0.11';


const kNavy = Color(0xff1d9bf0);
const kNavy2 = Color(0xff27c4a6);
const kOrange = Color(0xff16a34a);
const kSoftBg = Color(0xffedf9f8);
const kBorder = Color(0xffb9e7df);
const kSurface = Color(0xfff6fffd);
const kText = Color(0xff166b80);
const kMuted = Color(0xff5d8d98);
const kSoftBlue = Color(0xffdff4ff);
const kSoftGreen = Color(0xffdcfce7);
const kSoftMint = Color(0xffe7fff7);
const kSoftYellow = Color(0xfffff7df);
const kDanger = Color(0xffef6f6c);

const appPermissionLabels = {
  'sms.send': 'ارسال پیامک',
  'sms.view': 'مشاهده پیام‌ها',
  'shipment.create': 'ثبت مرسوله',
  'shipment.view': 'مشاهده مرسولات',
  'user.view': 'مشاهده کاربران',
  'user.manage': 'مدیریت کاربران',
  'dashboard.view': 'داشبورد',
  'report.view': 'گزارش‌ها',
  'log.view': 'لاگ‌ها',
};

const statusText = {
  'registered': 'ثبت شد',
  'processing': 'در حال پردازش',
  'in_transit': 'در مسیر',
  'delivered': 'تحویل شد',
  'returned': 'برگشتی',
  'cancelled': 'لغو شده',
};

String toFa(Object? value) => '$value'.replaceAllMapped(RegExp(r'\d'), (m) => '۰۱۲۳۴۵۶۷۸۹'[int.parse(m.group(0)!)]);
String dateVal(int y, int m, int d) => '$y/${persianMonths[m - 1]}/$d';

String todayShamsiDate() {
  final now = DateTime.now();
  final j = gregorianToJalali(now.year, now.month, now.day);
  return dateVal(j[0], j[1], j[2]);
}

String asText(dynamic value, [String fallback = '']) {
  if (value == null) return fallback;
  if (value is String) return value;
  if (value is List) return value.map((e) => e?.toString() ?? '').where((e) => e.isNotEmpty).join('، ');
  if (value is Map) return jsonEncode(value);
  return value.toString();
}

List<String> asStringList(dynamic value) {
  if (value == null) return <String>[];
  if (value is List<String>) return value;
  if (value is List) return value.map((e) => e?.toString() ?? '').where((e) => e.isNotEmpty).toList();
  if (value is String && value.trim().isNotEmpty) return <String>[value];
  return <String>[];
}

List<int> gregorianToJalali(int gy, int gm, int gd) {
  final gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  var jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  final gy2 = gm > 2 ? gy + 1 : gy;
  var days = 365 * gy + ((gy2 + 3) ~/ 4) - ((gy2 + 99) ~/ 100) + ((gy2 + 399) ~/ 400) - 80 + gd + gdm[gm - 1];
  jy += 33 * (days ~/ 12053);
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    jy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  final jm = days < 186 ? 1 + (days ~/ 31) : 7 + ((days - 186) ~/ 30);
  final jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

class PostSmsApp extends StatelessWidget {
  const PostSmsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سامانه مرسولات و پیامک',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: kNavy,
          primary: kNavy,
          secondary: kNavy2,
          surface: kSurface,
          onSurface: kText,
          onPrimary: kSurface,
        ),
        scaffoldBackgroundColor: kSoftBg,
        useMaterial3: true,
        fontFamily: null,
        textTheme: ThemeData.light().textTheme.apply(bodyColor: kText, displayColor: kText),
        iconTheme: const IconThemeData(color: kNavy),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          backgroundColor: kSoftBg,
          foregroundColor: kText,
          surfaceTintColor: kSoftBg,
          elevation: 0,
        ),
        drawerTheme: const DrawerThemeData(backgroundColor: kSoftBg, surfaceTintColor: kSoftBg),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: kNavy2, foregroundColor: kSurface),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: kNavy,
            foregroundColor: kSurface,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
        ),
        cardTheme: CardThemeData(
          color: kSurface,
          elevation: 0,
          margin: const EdgeInsets.symmetric(vertical: 7),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: kBorder),
          ),
        ),
        chipTheme: ChipThemeData(
          backgroundColor: kSoftGreen,
          selectedColor: kSoftBlue,
          labelStyle: const TextStyle(color: kText, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: kBorder)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: kSurface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: kBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: kNavy2, width: 1.8),
          ),
        ),
      ),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const HomePage(),
    );
  }
}

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}

class ApiService {
  String baseUrl = '';
  String token = '';
  final Map<String, Uint8List> _imageCache = {};

  Uri uri(String path, [Map<String, String>? query]) {
    final normalized = baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    final fullPath = path.startsWith('/') ? path : '/$path';
    final parsed = Uri.parse('$normalized$fullPath');
    return query == null || query.isEmpty ? parsed : parsed.replace(queryParameters: query);
  }

  String imageUrl(String src) {
    var cleanSrc = src.trim();
    if (cleanSrc.startsWith('http://') || cleanSrc.startsWith('https://')) return cleanSrc;
    final root = baseUrl.trim().replaceAll(RegExp(r'/api/?$'), '').replaceAll(RegExp(r'/+$'), '');
    cleanSrc = cleanSrc.replaceAll('\\', '/').replaceAll('../', '').replaceAll('./', '');
    cleanSrc = cleanSrc.startsWith('/') ? cleanSrc.substring(1) : cleanSrc;
    if (cleanSrc.startsWith('post/')) cleanSrc = cleanSrc.substring(5);
    return '$root/$cleanSrc';
  }

  Future<Uint8List> imageBytes(String src) async {
    final cacheKey = src.trim();
    if (_imageCache.containsKey(cacheKey)) return _imageCache[cacheKey]!;
    var cleanSrc = cacheKey;
    final headers = authHeaders;
    late http.Response response;
    if (cleanSrc.startsWith('secure:') || cleanSrc.endsWith('.pimg') || cleanSrc.contains('private_uploads/')) {
      cleanSrc = cleanSrc.replaceFirst('secure:', '').replaceAll('private_uploads/', '');
      response = await http.get(uri('/secure_image.php', {'f': cleanSrc}), headers: headers);
    } else if (cleanSrc.startsWith('http://') || cleanSrc.startsWith('https://')) {
      response = await http.get(Uri.parse(cleanSrc), headers: headers);
    } else {
      response = await http.get(Uri.parse(imageUrl(cleanSrc)), headers: headers);
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ApiException('تصویر قابل دریافت نیست');
    }
    _imageCache[cacheKey] = response.bodyBytes;
    if (_imageCache.length > 120) _imageCache.remove(_imageCache.keys.first);
    return response.bodyBytes;
  }

  Map<String, String> get authHeaders => token.isEmpty ? {} : {'Authorization': 'Bearer $token'};

  Future<Map<String, dynamic>> login(String username, String password) async {
    final response = await http.post(
      uri('/login.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> getJson(String path, {Map<String, String>? query}) async {
    final response = await http.get(uri(path, query), headers: authHeaders);
    return _decode(response);
  }

  Future<Map<String, dynamic>> postJson(String path, Map<String, dynamic> data) async {
    final response = await http.post(
      uri(path),
      headers: {'Content-Type': 'application/json; charset=utf-8', ...authHeaders},
      body: jsonEncode(data),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> deleteJson(String path, {Map<String, String>? query}) async {
    final response = await http.delete(uri(path, query), headers: authHeaders);
    return _decode(response);
  }

  Future<Map<String, dynamic>> saveShipment({required Map<String, String> fields, required List<PendingPhoto> photos}) async {
    final request = http.MultipartRequest('POST', uri('/save.php'));
    request.headers.addAll(authHeaders);
    request.fields.addAll(fields);
    for (var i = 0; i < photos.length; i++) {
      final name = photos[i].file.name.isEmpty ? 'photo_${i + 1}.jpg' : photos[i].file.name;
      request.files.add(http.MultipartFile.fromBytes('images[]', photos[i].bytes, filename: name));
    }
    final streamed = await request.send();
    final response = await http.Response.fromStream(streamed);
    return _decode(response);
  }

  Map<String, dynamic> _decode(http.Response response) {
    late Map<String, dynamic> decoded;
    try {
      decoded = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      final body = utf8.decode(response.bodyBytes, allowMalformed: true);
      throw ApiException('پاسخ سرور معتبر نیست: ${body.substring(0, body.length < 180 ? body.length : 180)}');
    }
    if (decoded['ok'] != true) {
      throw ApiException((decoded['error'] ?? decoded['message'] ?? 'خطای سرور').toString());
    }
    return decoded;
  }
}


class AppUpdateInfo {
  AppUpdateInfo({
    required this.versionCode,
    required this.versionName,
    required this.downloadUrl,
    required this.notes,
    required this.forceUpdate,
    required this.enabled,
  });

  final int versionCode;
  final String versionName;
  final String downloadUrl;
  final String notes;
  final bool forceUpdate;
  final bool enabled;

  bool get isNewer => enabled && versionCode > kAppVersionCode && downloadUrl.trim().isNotEmpty;

  factory AppUpdateInfo.fromJson(Map<String, dynamic> json) => AppUpdateInfo(
        versionCode: int.tryParse('${json['version_code'] ?? json['latest_version_code'] ?? 0}') ?? 0,
        versionName: asText(json['version_name'] ?? json['latest_version_name'], 'نسخه جدید'),
        downloadUrl: asText(json['download_url'] ?? json['apk_url'] ?? json['url']),
        notes: asText(json['notes'] ?? json['message'], 'نسخه جدید آماده نصب است.'),
        forceUpdate: '${json['force_update'] ?? json['force'] ?? '0'}' == '1' || json['force_update'] == true,
        enabled: '${json['enabled'] ?? '1'}' != '0',
      );
}

class PendingPhoto {
  PendingPhoto(this.file, this.bytes);
  final XFile file;
  final Uint8List bytes;
}

class Shipment {
  Shipment({
    required this.id,
    required this.trackingCode,
    required this.fullname,
    required this.phone,
    required this.receiverInfo,
    required this.shipmentType,
    required this.status,
    required this.shamsiDate,
    required this.description,
    required this.images,
    required this.createdBy,
    required this.updatedBy,
    required this.createdAt,
  });

  final int id;
  final String trackingCode;
  final String fullname;
  final String phone;
  final String receiverInfo;
  final String shipmentType;
  final String status;
  final String shamsiDate;
  final String description;
  final List<String> images;
  final String createdBy;
  final String updatedBy;
  final String createdAt;

  factory Shipment.fromJson(Map<String, dynamic> json) {
    final imgs = <String>[];
    final raw = json['images'];
    if (raw is List) imgs.addAll(raw.map((e) => '$e').where((e) => e.isNotEmpty));
    if (raw is String && raw.trim().isNotEmpty) {
      try {
        final dec = jsonDecode(raw);
        if (dec is List) imgs.addAll(dec.map((e) => '$e').where((e) => e.isNotEmpty));
      } catch (_) {}
    }
    final single = (json['image'] ?? '').toString();
    if (imgs.isEmpty && single.isNotEmpty) imgs.add(single);
    return Shipment(
      id: int.tryParse('${json['id']}') ?? 0,
      trackingCode: asText(json['tracking_code']),
      fullname: asText(json['fullname']),
      phone: asText(json['phone']),
      receiverInfo: asText(json['receiver_info']),
      shipmentType: asText(json['shipment_type'], 'بسته'),
      status: asText(json['status'], 'registered'),
      shamsiDate: asText(json['shamsi_date']),
      description: asText(json['description']),
      images: imgs,
      createdBy: asText(json['created_by']),
      updatedBy: asText(json['updated_by']),
      createdAt: asText(json['created_at']),
    );
  }
}

class DashboardData {
  DashboardData({required this.total, required this.today, required this.month, required this.latest});
  final int total;
  final int today;
  final int month;
  final List<Shipment> latest;

  factory DashboardData.fromJson(Map<String, dynamic> json) {
    final latest = <Shipment>[];
    final raw = json['latest'];
    if (raw is List) {
      for (final item in raw) {
        if (item is Map) latest.add(Shipment.fromJson(Map<String, dynamic>.from(item)));
      }
    }
    return DashboardData(
      total: int.tryParse('${json['total']}') ?? 0,
      today: int.tryParse('${json['today']}') ?? 0,
      month: int.tryParse('${json['month']}') ?? 0,
      latest: latest,
    );
  }
}

class AppUser {
  AppUser({
    required this.id,
    required this.username,
    required this.role,
    required this.roleLabel,
    required this.isActive,
    required this.lastLoginAt,
    required this.permissions,
  });
  final int id;
  final String username;
  final String role;
  final String roleLabel;
  final bool isActive;
  final String lastLoginAt;
  final List<String> permissions;

  bool can(String permission) => role == 'admin' || permissions.contains(permission);

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        id: int.tryParse('${json['id']}') ?? 0,
        username: asText(json['username']),
        role: asText(json['role'], 'user'),
        roleLabel: asText(json['role_label'] ?? json['role'], 'کاربر عادی'),
        isActive: '${json['is_active']}' == '1' || json['is_active'] == true,
        lastLoginAt: asText(json['last_login_at'], '-'),
        permissions: asStringList(json['permissions']),
      );
}

class SmsGroup {
  SmsGroup({required this.id, required this.title, required this.messages});
  final String id;
  final String title;
  final List<SmsMessage> messages;
  String get text => messages.isEmpty ? '' : messages.first.text;
  String get service => messages.isEmpty ? '' : messages.first.service;
  String get createdAt => messages.isEmpty ? '' : messages.first.createdAt;
  int get successCount => messages.where((m) => m.sendOk).length;
  int get failedCount => messages.where((m) => !m.sendOk || m.deliveryLevel == 'failed').length;
  int get deliveredCount => messages.where((m) => m.deliveryLevel == 'delivered').length;
  int get pendingCount => messages.length - deliveredCount - failedCount;
}

class AppLog {
  AppLog({required this.createdAt, required this.username, required this.action, required this.entity, required this.ip, required this.details});
  final String createdAt;
  final String username;
  final String action;
  final String entity;
  final String ip;
  final String details;

  factory AppLog.fromJson(Map<String, dynamic> json) => AppLog(
        createdAt: asText(json['created_at']),
        username: (json['username'] ?? '-').toString(),
        action: (json['action'] ?? '-').toString(),
        entity: '${json['entity'] ?? '-'} #${json['entity_id'] ?? ''}',
        ip: (json['ip_address'] ?? '-').toString(),
        details: (json['details'] ?? '-').toString(),
      );
}

class SmsStats {
  SmsStats({required this.total, required this.today, required this.month, required this.delivered, required this.failed, required this.waiting});
  final int total;
  final int today;
  final int month;
  final int delivered;
  final int failed;
  final int waiting;
  factory SmsStats.fromJson(Map<String, dynamic> json) => SmsStats(
        total: int.tryParse('${json['total']}') ?? 0,
        today: int.tryParse('${json['today']}') ?? 0,
        month: int.tryParse('${json['month']}') ?? 0,
        delivered: int.tryParse('${json['delivered']}') ?? 0,
        failed: int.tryParse('${json['failed']}') ?? 0,
        waiting: int.tryParse('${json['waiting']}') ?? 0,
      );
}

class SmsMessage {
  SmsMessage({
    required this.id,
    required this.groupId,
    required this.groupTitle,
    required this.receiver,
    required this.fullName,
    required this.sender,
    required this.text,
    required this.service,
    required this.recId,
    required this.sendOk,
    required this.sendStatus,
    required this.deliveryText,
    required this.deliveryLevel,
    required this.createdAt,
  });
  final int id;
  final String groupId;
  final String groupTitle;
  final String receiver;
  final String fullName;
  final String sender;
  final String text;
  final String service;
  final String recId;
  final bool sendOk;
  final String sendStatus;
  final String deliveryText;
  final String deliveryLevel;
  final String createdAt;

  factory SmsMessage.fromJson(Map<String, dynamic> json) => SmsMessage(
        id: int.tryParse('${json['id']}') ?? 0,
        groupId: asText(json['group_id']),
        groupTitle: asText(json['group_title']),
        receiver: asText(json['receiver']),
        fullName: asText(json['full_name']),
        sender: asText(json['sender']),
        text: asText(json['text']),
        service: asText(json['service'], 'smsir'),
        recId: asText(json['rec_id']),
        sendOk: '${json['send_ok']}' == '1' || json['send_ok'] == true,
        sendStatus: asText(json['send_status']),
        deliveryText: asText(json['delivery_text']),
        deliveryLevel: asText(json['delivery_level'], 'unknown'),
        createdAt: asText(json['created_at']),
      );
}

class SmsContact {
  SmsContact({required this.number, required this.name, required this.count});
  final String number;
  final String name;
  final int count;
  factory SmsContact.fromJson(Map<String, dynamic> json) => SmsContact(
        number: asText(json['number']),
        name: asText(json['name']),
        count: int.tryParse('${json['count']}') ?? 0,
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final api = ApiService();
  final picker = ImagePicker();

  final apiController = TextEditingController(text: kDefaultApiBase);
  final loginUserController = TextEditingController(text: 'admin');
  final loginPassController = TextEditingController();
  final searchController = TextEditingController();
  final fullnameController = TextEditingController();
  final phoneController = TextEditingController();
  final receiverController = TextEditingController();
  final newUserController = TextEditingController();
  final newPassController = TextEditingController();
  final userIdController = TextEditingController();
  final smsSenderController = TextEditingController(text: '30002108020400');
  final smsNumbersController = TextEditingController();
  final smsTextController = TextEditingController();
  final smsGroupController = TextEditingController();
  final smsSearchController = TextEditingController();
  final logUserController = TextEditingController();

  bool loggedIn = false;
  bool loading = false;
  bool saving = false;
  bool sendingSms = false;
  bool rememberMe = true;
  String username = '';
  String role = '';
  String roleLabel = '';
  List<String> permissions = [];

  int pageIndex = 0;
  String shipmentType = shipmentTypes.first;
  int jy = 1405, jm = 1, jd = 1;
  int ry = 1405, rm = 1, rd = 1;
  int reportTypeIndex = 0;
  int? editingShipmentId;
  bool newUserActive = true;
  bool permSmsSend = false;
  bool permSmsView = false;
  bool permShipmentCreate = true;
  bool permShipmentView = true;
  String smsService = 'smsir';
  bool smsTodayOnly = true;
  String logAction = '';
  String logEntity = '';

  DashboardData? dashboard;
  SmsStats? smsStats;
  List<Shipment> shipments = [];
  List<PendingPhoto> selectedPhotos = [];
  List<AppUser> users = [];
  List<AppLog> logs = [];
  List<SmsMessage> smsMessages = [];
  List<SmsContact> smsContacts = [];
  Timer? searchDebounce;
  bool autoCheckingDelivery = false;
  DateTime? lastAutoDeliveryCheck;
  AppUpdateInfo? availableUpdate;
  bool updateDialogOpen = false;

  bool has(String permission) => role == 'admin' || permissions.contains(permission);
  bool get canAdmin => role == 'admin';

  int firstAllowedPage() {
    if (has('shipment.create')) return 0;
    if (has('shipment.view')) return 1;
    if (has('sms.send')) return 2;
    if (has('sms.view')) return 3;
    if (has('dashboard.view')) return 5;
    if (has('user.view')) return 7;
    return 0;
  }

  @override
  void initState() {
    super.initState();
    _setToday();
    _restoreSession();
  }

  @override
  void dispose() {
    searchDebounce?.cancel();
    for (final c in [
      apiController, loginUserController, loginPassController, searchController, fullnameController,
      phoneController, receiverController, newUserController, newPassController, userIdController,
      smsSenderController, smsNumbersController, smsTextController, smsGroupController, smsSearchController,
      logUserController,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  void _setToday() {
    final now = DateTime.now();
    final j = gregorianToJalali(now.year, now.month, now.day);
    jy = ry = j[0];
    jm = rm = j[1];
    jd = rd = j[2];
  }

  Future<void> _restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    apiController.text = asText(prefs.get('post_api_base'), kDefaultApiBase);
    rememberMe = prefs.get('post_remember_me') is bool ? prefs.getBool('post_remember_me') ?? true : true;
    final savedUser = asText(prefs.get('post_saved_user'), asText(prefs.get('post_user')));
    final savedPass = asText(prefs.get('post_saved_pass'));
    if (savedUser.isNotEmpty) loginUserController.text = savedUser;
    if (rememberMe && savedPass.isNotEmpty) loginPassController.text = savedPass;

    final token = asText(prefs.get('post_token'));
    if (token.isNotEmpty) {
      api.baseUrl = apiController.text.trim();
      api.token = token;
      username = asText(prefs.get('post_user'));
      role = asText(prefs.get('post_role'));
      roleLabel = asText(prefs.get('post_role_label'), role);
      permissions = asStringList(prefs.get('post_permissions'));
      setState(() {
        loggedIn = true;
        pageIndex = firstAllowedPage();
      });
      await boot();
      unawaited(checkForAppUpdate());
      return;
    }

    if (rememberMe && savedUser.isNotEmpty && savedPass.isNotEmpty) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      if (mounted && !loggedIn) await login(silent: true);
    }
  }

  Future<void> login({bool silent = false}) async {
    final base = (apiController.text.trim().isEmpty ? kDefaultApiBase : apiController.text.trim()).replaceAll(RegExp(r'/+$'), '');
    setState(() => loading = true);
    try {
      api.baseUrl = base;
      final result = await api.login(loginUserController.text.trim(), loginPassController.text);
      api.token = asText(result['token']);
      username = asText(result['username']);
      role = asText(result['role']);
      roleLabel = asText(result['role_label'], role);
      permissions = asStringList(result['permissions']);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('post_api_base', base);
      await prefs.setString('post_token', api.token);
      await prefs.setString('post_user', username);
      await prefs.setString('post_role', role);
      await prefs.setString('post_role_label', roleLabel);
      await prefs.setStringList('post_permissions', permissions);
      await prefs.setBool('post_remember_me', rememberMe);
      if (rememberMe) {
        await prefs.setString('post_saved_user', loginUserController.text.trim());
        await prefs.setString('post_saved_pass', loginPassController.text);
      } else {
        await prefs.remove('post_saved_user');
        await prefs.remove('post_saved_pass');
      }
      setState(() {
        loggedIn = true;
        pageIndex = firstAllowedPage();
      });
      await boot();
      unawaited(checkForAppUpdate());
      if (!silent) showSnack('ورود موفق بود');
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('post_token');
    await prefs.remove('post_user');
    await prefs.remove('post_role');
    await prefs.remove('post_role_label');
    await prefs.remove('post_permissions');
    api.token = '';
    setState(() {
      loggedIn = false;
      dashboard = null;
      smsStats = null;
      shipments.clear();
      users.clear();
      logs.clear();
      smsMessages.clear();
      smsContacts.clear();
    });
  }


  Future<void> requestLogout() async {
    if (await confirm('از حساب خارج شوید؟') != true) return;
    await logout();
  }

  Future<bool> onBackPressed() async {
    if (!loggedIn) return true;
    final first = firstAllowedPage();
    if (pageIndex != first) {
      setState(() => pageIndex = first);
      return false;
    }
    final ok = await confirm('از برنامه خارج شوید؟') == true;
    return ok;
  }

  Future<void> boot() async {
    try {
      final tasks = <Future<void>>[];
      if (has('dashboard.view')) tasks.add(loadDashboard());
      if (has('sms.view')) tasks.add(loadSmsDashboard(silent: true));
      if (pageIndex == 1 && has('shipment.view')) tasks.add(loadShipments());
      if (pageIndex == 3 && has('sms.view')) tasks.add(loadSmsMessages(autoCheck: false));
      if (tasks.isNotEmpty) await Future.wait(tasks);
      if (has('sms.send')) unawaited(syncOldLocalSmsMessages());
    } catch (e) {
      showSnack(e.toString());
    }
  }


  Future<void> checkForAppUpdate({bool manual = false}) async {
    try {
      if (api.baseUrl.trim().isEmpty) api.baseUrl = kDefaultApiBase;
      final result = await api.getJson('/app_update.php', query: {
        'platform': 'android',
        'current_code': '$kAppVersionCode',
        'current_version': kAppVersionName,
      });
      final raw = result['data'] is Map ? Map<String, dynamic>.from(result['data'] as Map) : Map<String, dynamic>.from(result);
      final info = AppUpdateInfo.fromJson(raw);
      if (!mounted) return;
      setState(() => availableUpdate = info.isNewer ? info : null);
      if (info.isNewer) {
        final prefs = await SharedPreferences.getInstance();
        final dismissedCode = prefs.getInt('post_dismissed_update_code') ?? 0;
        if (manual || info.forceUpdate || dismissedCode != info.versionCode) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) showUpdateDialog(info);
          });
        }
      } else if (manual) {
        showSnack('نسخه برنامه به‌روز است');
      }
    } catch (e) {
      if (manual) showSnack('بررسی آپدیت انجام نشد: $e');
    }
  }

  Future<void> showUpdateDialog(AppUpdateInfo info) async {
    if (updateDialogOpen || !mounted) return;
    updateDialogOpen = true;
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: !info.forceUpdate,
        builder: (context) => WillPopScope(
          onWillPop: () async => !info.forceUpdate,
          child: AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
            title: Row(children: const [
              Icon(Icons.system_update_alt, color: kNavy),
              SizedBox(width: 8),
              Expanded(child: Text('نسخه جدید آماده است')),
            ]),
            content: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: kSoftMint,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: kBorder),
              ),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('نسخه فعلی: $kAppVersionName', style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Text('نسخه جدید: ${info.versionName}', style: const TextStyle(fontWeight: FontWeight.w900, color: kNavy)),
                const SizedBox(height: 10),
                Text(info.notes, style: const TextStyle(height: 1.6)),
                const SizedBox(height: 10),
                const Text('فایل جدید را روی همین برنامه نصب کن؛ نیازی به حذف نسخه قبلی نیست.', style: TextStyle(fontWeight: FontWeight.w700)),
              ]),
            ),
            actions: [
              if (!info.forceUpdate)
                TextButton(
                  onPressed: () async {
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.setInt('post_dismissed_update_code', info.versionCode);
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: const Text('بعداً'),
                ),
              FilledButton.icon(
                onPressed: () async {
                  final uri = Uri.tryParse(info.downloadUrl);
                  if (uri == null) {
                    showSnack('لینک آپدیت معتبر نیست');
                    return;
                  }
                  final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
                  if (!opened) showSnack('لینک دانلود باز نشد');
                  if (!info.forceUpdate && context.mounted) Navigator.pop(context);
                },
                icon: const Icon(Icons.download),
                label: const Text('دانلود و نصب'),
              ),
            ],
          ),
        ),
      );
    } finally {
      updateDialogOpen = false;
    }
  }

  Future<void> loadDashboard() async {
    if (!has('dashboard.view')) return;
    final result = await api.getJson('/dashboard.php');
    setState(() => dashboard = DashboardData.fromJson(Map<String, dynamic>.from(result['data'])));
  }

  Future<void> loadSmsDashboard({bool silent = false}) async {
    if (!has('sms.view')) return;
    try {
      final result = await api.getJson('/sms_dashboard.php');
      setState(() => smsStats = SmsStats.fromJson(Map<String, dynamic>.from(result['data'])));
    } catch (e) {
      if (!silent) showSnack(e.toString());
    }
  }

  Future<void> loadShipments() async {
    if (!has('shipment.view')) return;
    final query = <String, String>{};
    final q = searchController.text.trim();
    if (q.isNotEmpty) {
      query['q'] = q;
    } else {
      query['date'] = todayShamsiDate();
    }
    final result = await api.getJson('/shipments.php', query: query);
    final data = result['data'] as List? ?? [];
    if (!mounted) return;
    setState(() => shipments = data.map((e) => Shipment.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadUsers() async {
    if (!has('user.view')) return;
    final result = await api.getJson('/users.php');
    final data = result['data'] as List? ?? [];
    setState(() => users = data.map((e) => AppUser.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadLogs() async {
    if (!has('log.view')) return;
    final query = <String, String>{};
    if (logUserController.text.trim().isNotEmpty) query['username'] = logUserController.text.trim();
    if (logAction.isNotEmpty) query['action'] = logAction;
    if (logEntity.isNotEmpty) query['entity'] = logEntity;
    final result = await api.getJson('/logs.php', query: query);
    final data = result['data'] as List? ?? [];
    setState(() => logs = data.map((e) => AppLog.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadSmsMessages({bool autoCheck = true}) async {
    if (!has('sms.view')) return;
    final query = <String, String>{};
    final smsQ = smsSearchController.text.trim();
    if (smsQ.isNotEmpty) {
      query['q'] = smsQ;
    } else {
      query['today'] = '1';
    }
    final result = await api.getJson('/sms_messages.php', query: query);
    final data = result['data'] as List? ?? [];
    final loaded = data.map((e) => SmsMessage.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    setState(() => smsMessages = loaded);
    if (autoCheck) unawaited(autoUpdatePendingDeliveries());
  }

  Future<void> loadSmsContacts() async {
    if (!has('sms.view')) return;
    final result = await api.getJson('/sms_contacts.php');
    final data = result['data'] as List? ?? [];
    setState(() => smsContacts = data.map((e) => SmsContact.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> autoUpdatePendingDeliveries({bool force = false}) async {
    if (!has('sms.view') || autoCheckingDelivery) return;
    final now = DateTime.now();
    if (!force && lastAutoDeliveryCheck != null && now.difference(lastAutoDeliveryCheck!).inMinutes < 4) return;
    final pending = smsMessages
        .where((m) => m.recId.isNotEmpty && m.sendOk && m.deliveryLevel != 'delivered' && m.deliveryLevel != 'failed')
        .take(12)
        .toList();
    if (pending.isEmpty) return;
    autoCheckingDelivery = true;
    lastAutoDeliveryCheck = now;
    try {
      for (final m in pending) {
        try {
          await api.postJson('/sms_delivery.php', {
            'id': m.id,
            'service': m.service,
            'rec_id': m.recId,
            'receiver': m.receiver,
          });
        } catch (_) {}
      }
      await loadSmsMessages(autoCheck: false);
      await loadSmsDashboard(silent: true);
    } finally {
      autoCheckingDelivery = false;
    }
  }

  Future<void> syncOldLocalSmsMessages({bool manual = false}) async {
    if (!has('sms.send')) return;
    final prefs = await SharedPreferences.getInstance();
    final keys = [
      'sms_pending_local',
      'sms_local_messages',
      'pending_sms_messages',
      'local_sms_outbox',
      'sms_panel_sent_history',
      'sms_sent_history',
      'smsir_sent_history',
      'sms_history',
      'sent_messages',
      'sms_panel_cache',
    ];
    var total = 0;
    var skipped = 0;
    for (final key in keys) {
      final stored = prefs.get(key);
      final candidates = <String>[];
      if (stored is List<String>) {
        candidates.addAll(stored);
      } else if (stored is List) {
        candidates.addAll(stored.map((e) => e?.toString() ?? '').where((e) => e.isNotEmpty));
      } else if (stored is String && stored.trim().isNotEmpty) {
        candidates.add(stored);
      }
      if (candidates.isEmpty) continue;
      var uploadedThisKey = false;
      for (final raw in candidates) {
        try {
          final decoded = jsonDecode(raw);
          final messages = decoded is List ? decoded : [decoded];
          final result = await api.postJson('/sms_import_local.php', {'messages': messages, 'source': key});
          final imported = int.tryParse('${result['imported'] ?? 0}') ?? 0;
          final duplicate = int.tryParse('${result['duplicates'] ?? 0}') ?? 0;
          total += imported;
          skipped += duplicate;
          if (imported > 0 || duplicate > 0 || '${result['ok']}' == 'true') uploadedThisKey = true;
        } catch (_) {}
      }
      if (uploadedThisKey) await prefs.remove(key);
    }
    try {
      final result = await api.postJson('/sms_sync_panel_history.php', {'days': 7});
      total += int.tryParse('${result['imported'] ?? 0}') ?? 0;
      skipped += int.tryParse('${result['duplicates'] ?? 0}') ?? 0;
    } catch (_) {}

    if (total > 0) {
      if (has('sms.view')) {
        await loadSmsMessages(autoCheck: false);
        await loadSmsDashboard(silent: true);
      }
      if (manual) showSnack('همگام‌سازی انجام شد: ${toFa(total)} پیام منتقل شد');
    } else if (manual) {
      final dupText = skipped > 0 ? '؛ ${toFa(skipped)} پیام قبلاً روی هاست بود' : '';
      showSnack('پیام جدیدی برای انتقال پیدا نشد$dupText');
    }
  }

  void showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  bool canOpenPage(int index) {
    if (index == 0) return has('shipment.create');
    if (index == 1 || index == 6) return has('shipment.view');
    if (index == 2) return has('sms.send');
    if (index == 3 || index == 4) return has('sms.view');
    if (index == 5) return has('dashboard.view') || has('sms.view');
    if (index == 7) return has('user.view');
    if (index == 8) return has('log.view');
    return false;
  }

  Future<void> openPage(int index, {bool closeDrawer = false}) async {
    if (!canOpenPage(index)) {
      showSnack('شما به این بخش دسترسی ندارید');
      return;
    }
    if (closeDrawer && Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
      await Future<void>.delayed(const Duration(milliseconds: 120));
    }
    if (!mounted) return;
    setState(() => pageIndex = index);
    try {
      if (index == 1) await loadShipments();
      if (index == 2) await loadSmsDashboard(silent: true);
      if (index == 3) await loadSmsMessages();
      if (index == 4) await loadSmsContacts();
      if (index == 5) { if (has('dashboard.view')) await loadDashboard(); if (has('sms.view')) await loadSmsDashboard(silent: true); }
      if (index == 6) await loadShipments();
      if (index == 7) await loadUsers();
      if (index == 8) await loadLogs();
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> pickFromCamera() async {
    final photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 82, maxWidth: 1600);
    if (photo == null) return;
    final bytes = await photo.readAsBytes();
    if (!mounted) return;
    setState(() => selectedPhotos.add(PendingPhoto(photo, bytes)));
  }

  Future<void> pickFromGallery() async {
    final photos = await picker.pickMultiImage(imageQuality: 82, maxWidth: 1600);
    final pending = <PendingPhoto>[];
    for (final photo in photos) pending.add(PendingPhoto(photo, await photo.readAsBytes()));
    setState(() => selectedPhotos.addAll(pending));
  }

  Future<void> saveShipment() async {
    if (!has('shipment.create')) return showSnack('شما اجازه ثبت ندارید');
    if (fullnameController.text.trim().isEmpty) return showSnack('نام و نام خانوادگی گیرنده الزامی است');
    setState(() => saving = true);
    try {
      await api.saveShipment(
        fields: {
          'editId': editingShipmentId?.toString() ?? '',
          'fullname': fullnameController.text.trim(),
          'phone': phoneController.text.trim(),
          'shipment_type': shipmentType,
          'receiver_info': receiverController.text.trim(),
          'description': '',
          'shamsi_date': dateVal(jy, jm, jd),
        },
        photos: selectedPhotos,
      );
      resetForm();
      await loadShipments();
      await loadDashboard();
      showSnack('مرسوله ذخیره شد');
      setState(() => pageIndex = 1);
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void resetForm() {
    fullnameController.clear();
    phoneController.clear();
    receiverController.clear();
    editingShipmentId = null;
    shipmentType = shipmentTypes.first;
    selectedPhotos.clear();
    _setToday();
    setState(() {});
  }

  void editShipment(Shipment shipment) {
    if (!has('shipment.edit')) return showSnack('شما اجازه ویرایش ندارید');
    setState(() {
      editingShipmentId = shipment.id;
      fullnameController.text = shipment.fullname;
      phoneController.text = shipment.phone;
      receiverController.text = shipment.receiverInfo;
      shipmentType = shipmentTypes.contains(shipment.shipmentType) ? shipment.shipmentType : shipmentTypes.first;
      selectedPhotos.clear();
      pageIndex = 0;
    });
  }

  Future<bool?> confirm(String message) => showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('تأیید'),
          content: Text(message),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تأیید')),
          ],
        ),
      );

  Future<void> deleteShipment(Shipment shipment) async {
    if (!has('shipment.delete')) return showSnack('شما اجازه حذف ندارید');
    if (await confirm('این مرسوله حذف شود؟') != true) return;
    try {
      await api.deleteJson('/delete.php', query: {'id': shipment.id.toString()});
      await loadShipments();
      await loadDashboard();
      showSnack('مرسوله حذف شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  void resetUserForm() {
    userIdController.clear();
    newUserController.clear();
    newPassController.clear();
    newUserActive = true;
    permSmsSend = false;
    permSmsView = false;
    permShipmentCreate = true;
    permShipmentView = true;
    setState(() {});
  }

  void editUser(AppUser user) {
    if (!has('user.manage')) return showSnack('شما اجازه مدیریت کاربر ندارید');
    userIdController.text = user.id.toString();
    newUserController.text = user.username;
    newPassController.clear();
    newUserActive = user.isActive;
    permSmsSend = user.can('sms.send');
    permSmsView = user.can('sms.view');
    permShipmentCreate = user.can('shipment.create');
    permShipmentView = user.can('shipment.view');
    setState(() {});
    showSnack('کاربر ${user.username} برای ویرایش انتخاب شد');
  }

  Future<void> saveUser() async {
    if (!has('user.manage')) return showSnack('شما اجازه مدیریت کاربر ندارید');
    try {
      await api.postJson('/save_user.php', {
        'id': int.tryParse(userIdController.text) ?? 0,
        'username': newUserController.text.trim(),
        'password': newPassController.text,
        'is_active': newUserActive ? 1 : 0,
        'can_send_sms': permSmsSend ? 1 : 0,
        'can_view_sms': permSmsView ? 1 : 0,
        'can_register_shipment': permShipmentCreate ? 1 : 0,
        'can_view_shipments': permShipmentView ? 1 : 0,
      });
      resetUserForm();
      await loadUsers();
      showSnack('کاربر ذخیره شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> disableUser(AppUser user) async {
    if (!has('user.manage')) return;
    if (await confirm('کاربر ${user.username} غیرفعال شود؟') != true) return;
    try {
      await api.deleteJson('/delete_user.php', query: {'id': user.id.toString()});
      await loadUsers();
      showSnack('کاربر غیرفعال شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> sendSms() async {
    if (!has('sms.send')) return showSnack('شما اجازه ارسال پیامک ندارید');
    final numbers = smsNumbersController.text.trim();
    final text = smsTextController.text.trim();
    if (numbers.isEmpty || text.isEmpty) return showSnack('شماره گیرنده و متن پیام را وارد کنید');
    setState(() => sendingSms = true);
    try {
      final result = await api.postJson('/sms_send.php', {
        'service': smsService,
        'sender': smsSenderController.text.trim(),
        'receivers': numbers,
        'text': text,
        'group_title': smsGroupController.text.trim(),
      });
      final success = result['success_count'] ?? 0;
      final failed = result['failed_count'] ?? 0;
      smsNumbersController.clear();
      smsGroupController.clear();
      if (has('sms.view')) {
        await loadSmsDashboard(silent: true);
        await loadSmsMessages();
        setState(() => pageIndex = 3);
      }
      showSnack('ارسال ثبت شد؛ موفق: $success / ناموفق: $failed');
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => sendingSms = false);
    }
  }

  Future<void> updateDelivery(SmsMessage message) async {
    if (message.recId.isEmpty) return showSnack('این پیام شناسه دلیوری ندارد');
    try {
      await api.postJson('/sms_delivery.php', {
        'id': message.id,
        'service': message.service,
        'rec_id': message.recId,
        'receiver': message.receiver,
      });
      await loadSmsMessages();
      await loadSmsDashboard(silent: true);
      showSnack('وضعیت دلیوری به‌روزرسانی شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> sendWithDeviceSms(SmsMessage message) async {
    final phone = message.receiver.trim();
    if (phone.isEmpty) return showSnack('شماره گیرنده موجود نیست');
    try {
      final prefs = await SharedPreferences.getInstance();
      final stored = prefs.get('sms_pending_local');
      final cache = <String>[];
      if (stored is List<String>) {
        cache.addAll(stored);
      } else if (stored is List) {
        cache.addAll(stored.map((e) => e?.toString() ?? '').where((e) => e.isNotEmpty));
      } else if (stored is String && stored.trim().isNotEmpty) {
        cache.add(stored);
      }
      cache.add(jsonEncode({
        'receiver': message.receiver,
        'full_name': message.fullName,
        'sender': 'device_sms',
        'text': message.text,
        'service': 'device',
        'send_ok': 1,
        'send_status': 'باز شده در برنامه پیامک گوشی؛ وضعیت ارسال باید توسط کاربر تأیید شود',
        'delivery_level': 'unknown',
        'delivery_text': 'ارسال با پیامک عادی گوشی؛ دلیوری پنل قابل بررسی نیست',
        'created_at': DateTime.now().toIso8601String(),
      }));
      await prefs.setStringList('sms_pending_local', cache);
      final encodedPhone = Uri.encodeComponent(phone);
      final encodedBody = Uri.encodeComponent(message.text);
      final candidates = [
        Uri.parse('sms:$encodedPhone?body=$encodedBody'),
        Uri.parse('smsto:$encodedPhone?body=$encodedBody'),
      ];
      var opened = false;
      for (final uri in candidates) {
        if (await canLaunchUrl(uri)) {
          opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
          if (opened) break;
        }
      }
      if (!opened) {
        showSnack('برنامه پیامک گوشی باز نشد');
        return;
      }
      showSnack('برنامه پیامک باز شد؛ بعد از ارسال، همگام‌سازی پنل/گوشی را بزن');
    } catch (e) {
      showSnack('خطای ارسال با پیام عادی: $e');
    }
  }

  Future<void> shareVcf() async {
    if (smsContacts.isEmpty) return showSnack('شماره‌ای برای ذخیره وجود ندارد');
    final buffer = StringBuffer();
    for (var i = 0; i < smsContacts.length; i++) {
      final c = smsContacts[i];
      final name = (c.name.isNotEmpty ? c.name : 'SMS Contact ${i + 1}').replaceAll('\n', ' ');
      buffer.write('BEGIN:VCARD\nVERSION:3.0\nFN:$name\nTEL;TYPE=CELL:${c.number}\nEND:VCARD\n');
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/sms_contacts.vcf');
    await file.writeAsString(buffer.toString(), encoding: utf8);
    await Share.shareXFiles([XFile(file.path)], text: 'خروجی شماره‌های پنل پیامکی');
  }

  List<Shipment> reportRows() {
    final rows = List<Shipment>.from(shipments);
    if (reportTypeIndex == 0) return rows.where((e) => e.shamsiDate == dateVal(ry, rm, rd)).toList();
    if (reportTypeIndex == 1) return rows.where((e) => e.shamsiDate.startsWith('$ry/${persianMonths[rm - 1]}/')).toList();
    return rows;
  }

  @override
  Widget build(BuildContext context) => loggedIn ? buildShell() : buildLogin();

  Widget buildLogin() {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [kSoftBlue, kSoftGreen, kSurface])),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: Card(
                elevation: 18,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('📮✉️', style: TextStyle(fontSize: 50)),
                    const SizedBox(height: 8),
                    const Text('ورود به سامانه', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Text('مرسولات + پنل پیامکی آنلاین', style: TextStyle(color: Colors.blueGrey.shade600)),
                    const SizedBox(height: 18),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xffeef2ff),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: const Color(0xffc7d2fe)),
                      ),
                      child: const Text('اتصال به سرور اصلی فعال است', textAlign: TextAlign.center),
                    ),
                    const SizedBox(height: 12),
                    TextField(controller: loginUserController, decoration: const InputDecoration(labelText: 'نام کاربری')),
                    const SizedBox(height: 12),
                    TextField(controller: loginPassController, obscureText: true, decoration: const InputDecoration(labelText: 'رمز عبور')),
                    const SizedBox(height: 8),
                    CheckboxListTile(value: rememberMe, onChanged: (v) => setState(() => rememberMe = v ?? true), title: const Text('مرا به خاطر بسپار'), controlAffinity: ListTileControlAffinity.leading, contentPadding: EdgeInsets.zero),
                    const SizedBox(height: 8),
                    SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: loading ? null : login, child: loading ? const CircularProgressIndicator() : const Text('ورود'))),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildShell() {
    final pages = [
      buildShipmentForm(), buildShipmentList(), buildSmsSend(), buildSmsMessages(), buildSmsContacts(), buildDashboard(), buildReport(), buildUsers(), buildLogs()
    ];
    final titles = ['ثبت مرسوله', 'مرسولات', 'ارسال پیامک', 'پیام‌های ثبت‌شده', 'استخراج شماره‌ها', 'داشبورد', 'گزارش مرسولات', 'کاربران', 'لاگ‌ها'];
    return WillPopScope(
      onWillPop: onBackPressed,
      child: Scaffold(
      appBar: AppBar(
        title: Text(titles[pageIndex], style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        actions: [
          Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Text('$username | $roleLabel', style: const TextStyle(fontSize: 12)))),
          IconButton(onPressed: requestLogout, icon: const Icon(Icons.logout), tooltip: 'خروج'),
        ],
      ),
      drawer: Drawer(child: SafeArea(child: buildDrawer())),
      body: Container(
        color: kSoftBg,
        child: SafeArea(
          child: Column(children: [
            if (availableUpdate != null) updateBanner(availableUpdate!),
            Expanded(child: pages[pageIndex]),
          ]),
        ),
      ),
      floatingActionButton: (pageIndex == 0 || pageIndex == 3 || !has('shipment.create')) ? null : FloatingActionButton.extended(
        onPressed: () => openPage(0),
        icon: const Icon(Icons.add_box_outlined),
        label: const Text('ثبت سریع'),
      ),
    ));
  }


  Widget updateBanner(AppUpdateInfo info) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => showUpdateDialog(info),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [kSoftBlue, kSoftGreen]),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kBorder),
            ),
            child: Row(children: [
              const Icon(Icons.system_update_alt, color: kNavy),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('آپدیت جدید ${info.versionName}', style: const TextStyle(fontWeight: FontWeight.w900)),
                  const Text('برای نصب، روی این باکس بزنید. حذف نسخه قبلی لازم نیست.', style: TextStyle(fontSize: 12)),
                ]),
              ),
              const Icon(Icons.chevron_left, color: kNavy),
            ]),
          ),
        ),
      );

  Widget buildDrawer() {
    Widget item(int index, IconData icon, String title) => ListTile(
          selected: pageIndex == index,
          leading: Icon(icon),
          title: Text(title),
          onTap: () => openPage(index, closeDrawer: true),
        );
    return ListView(padding: EdgeInsets.zero, children: [
      DrawerHeader(
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [kNavy, kNavy2, Color(0xff67e8f9)])),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('📮✉️', style: TextStyle(fontSize: 42)),
          const Spacer(),
          Text(username, style: const TextStyle(color: kSurface, fontWeight: FontWeight.w900, fontSize: 18)),
          Text(roleLabel, style: const TextStyle(color: kSoftBlue)),
        ]),
      ),
      if (has('shipment.create')) item(0, Icons.add_circle, 'ثبت مرسوله'),
      if (has('shipment.view')) item(1, Icons.inventory_2, 'مرسولات'),
      const Divider(),
      if (has('sms.send')) item(2, Icons.send, 'ارسال پیامک'),
      if (has('sms.view')) item(3, Icons.mark_chat_read, 'پیام‌های ثبت‌شده'),
      if (has('sms.view')) item(4, Icons.contacts, 'استخراج شماره‌ها'),
      const Divider(),
      if (has('dashboard.view')) item(5, Icons.dashboard, 'داشبورد'),
      if (has('report.view')) item(6, Icons.bar_chart, 'گزارش مرسولات'),
      if (has('user.view')) item(7, Icons.people, 'کاربران'),
      if (has('log.view')) item(8, Icons.receipt_long, 'لاگ‌ها'),
      const Divider(),
      ListTile(leading: const Icon(Icons.system_update_alt), title: const Text('بررسی آپدیت'), onTap: () async { if (Navigator.of(context).canPop()) Navigator.of(context).pop(); await Future<void>.delayed(const Duration(milliseconds: 120)); checkForAppUpdate(manual: true); }),
      ListTile(leading: const Icon(Icons.logout), title: const Text('خروج'), onTap: () async { if (Navigator.of(context).canPop()) Navigator.of(context).pop(); await Future<void>.delayed(const Duration(milliseconds: 120)); await requestLogout(); }),
    ]);
  }

  Widget pageList({required List<Widget> children, Future<void> Function()? onRefresh}) {
    final list = ListView(padding: const EdgeInsets.all(16), children: children);
    return onRefresh == null ? list : RefreshIndicator(onRefresh: onRefresh, child: list);
  }

  Widget sectionTitle(String title, [String? subtitle]) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 12, 4, 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          if (subtitle != null) Text(subtitle, style: TextStyle(color: Colors.blueGrey.shade600)),
        ]),
      );

  Widget statCard(String title, Object value, IconData icon) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const Spacer(),
            Text(toFa(value), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Text(title, style: TextStyle(color: Colors.blueGrey.shade600, fontWeight: FontWeight.bold)),
          ]),
        ),
      );

  Widget buildDashboard() {
    final d = dashboard;
    final s = smsStats;
    return pageList(onRefresh: () async { await loadDashboard(); await loadSmsDashboard(); }, children: [
      sectionTitle('داشبورد', 'خلاصه مرسولات و پیامک‌ها'),
      GridView.count(
        crossAxisCount: MediaQuery.sizeOf(context).width > 720 ? 4 : 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 1.35,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        children: [
          statCard('کل مرسولات', d?.total ?? 0, Icons.inventory_2),
          statCard('مرسولات امروز', d?.today ?? 0, Icons.today),
          statCard('کل پیامک‌ها', s?.total ?? 0, Icons.sms),
          statCard('پیامک امروز', s?.today ?? 0, Icons.mark_email_read),
        ],
      ),
      const SizedBox(height: 8),
      Card(child: ListTile(leading: const Icon(Icons.cloud_done), title: const Text('ذخیره پیام‌ها آنلاین است'), subtitle: const Text('پیام‌ها داخل دیتابیس همان سامانه مرسولات ذخیره می‌شوند، نه حافظه گوشی.'))),
      if (d?.latest.isNotEmpty == true) ...[
        sectionTitle('آخرین مرسولات'),
        ...d!.latest.map((e) => Card(child: ListTile(title: Text(e.fullname), subtitle: Text('${e.trackingCode}\n${e.phone}'), isThreeLine: true, leading: shipmentThumbs(e), onTap: () => openPage(1)))).toList(),
      ],
    ]);
  }

  Widget buildShipmentList() {
    if (!has('shipment.view')) return noAccess();
    return pageList(onRefresh: loadShipments, children: [
      sectionTitle('مرسولات امروز', 'بدون جستجو فقط مرسولات امروز نمایش داده می‌شود؛ جستجو کل مرسولات را می‌گردد.'),
      TextField(
        controller: searchController,
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search), labelText: 'جستجو در مرسولات', suffixIcon: IconButton(icon: const Icon(Icons.refresh), onPressed: loadShipments)),
        onChanged: (_) {
          searchDebounce?.cancel();
          searchDebounce = Timer(const Duration(milliseconds: 500), loadShipments);
        },
      ),
      const SizedBox(height: 10),
      if (shipments.isEmpty) emptyBox('مرسوله‌ای پیدا نشد'),
      ...shipments.map((s) => Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  shipmentThumbs(s),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [Expanded(child: Text(s.fullname, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))), Chip(label: Text(statusText[s.status] ?? s.status))]),
                    Text('کد: ${s.trackingCode}'),
                    if (s.phone.isNotEmpty) Text('تلفن: ${s.phone}'),
                    Text('نوع: ${s.shipmentType} | تاریخ: ${s.shamsiDate}'),
                    if (s.receiverInfo.isNotEmpty) Text(s.receiverInfo),
                  ])),
                ]),
                Row(children: [
                  if (has('shipment.edit')) TextButton.icon(onPressed: () => editShipment(s), icon: const Icon(Icons.edit), label: const Text('ویرایش')),
                  if (has('shipment.delete')) TextButton.icon(onPressed: () => deleteShipment(s), icon: const Icon(Icons.delete), label: const Text('حذف')),
                ]),
              ]),
            ),
          )),
    ]);
  }


  Widget secureImage(String src, {double? width, double? height, BoxFit fit = BoxFit.cover}) {
    return FutureBuilder<Uint8List>(
      future: api.imageBytes(src),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return Container(
            width: width,
            height: height,
            alignment: Alignment.center,
            color: kSoftBlue.withOpacity(0.35),
            child: const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
          );
        }
        if (snapshot.hasError || !snapshot.hasData) {
          return Container(
            width: width,
            height: height,
            alignment: Alignment.center,
            color: kSoftBlue.withOpacity(0.35),
            child: const Icon(Icons.broken_image_outlined, color: kMuted),
          );
        }
        return Image.memory(snapshot.data!, width: width, height: height, fit: fit);
      },
    );
  }

  Widget shipmentThumbs(Shipment shipment) {
    if (shipment.images.isEmpty) {
      return Container(
        width: 74,
        height: 74,
        decoration: BoxDecoration(color: kSoftBlue.withOpacity(0.35), borderRadius: BorderRadius.circular(16)),
        child: const Icon(Icons.image_not_supported_outlined, color: kMuted),
      );
    }
    final first = shipment.images.first;
    return GestureDetector(
      onTap: () => showShipmentImages(shipment),
      child: Stack(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: secureImage(first, width: 74, height: 74, fit: BoxFit.cover),
        ),
        if (shipment.images.length > 1)
          Positioned(
            left: 4,
            bottom: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: kNavy.withOpacity(0.55), borderRadius: BorderRadius.circular(10)),
              child: Text('+${toFa(shipment.images.length - 1)}', style: const TextStyle(color: Colors.white, fontSize: 11)),
            ),
          ),
      ]),
    );
  }

  void showShipmentImages(Shipment shipment) {
    if (shipment.images.isEmpty) return;
    showDialog(
      context: context,
      builder: (context) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Expanded(child: Text(shipment.fullname, style: const TextStyle(fontWeight: FontWeight.w900))),
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
            ]),
            SizedBox(
              height: MediaQuery.sizeOf(context).height * 0.65,
              child: PageView(
                children: shipment.images.map((img) => InteractiveViewer(
                  child: Center(child: secureImage(img, fit: BoxFit.contain)),
                )).toList(),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget selectedPhotoPreview() {
    if (selectedPhotos.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 92,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: selectedPhotos.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) => Stack(children: [
          ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(selectedPhotos[i].bytes, width: 92, height: 92, fit: BoxFit.cover)),
          Positioned(
            top: 2,
            left: 2,
            child: InkWell(
              onTap: () => setState(() => selectedPhotos.removeAt(i)),
              child: Container(decoration: BoxDecoration(color: kNavy.withOpacity(0.42), shape: BoxShape.circle), padding: const EdgeInsets.all(3), child: const Icon(Icons.close, color: Colors.white, size: 16)),
            ),
          ),
        ]),
      ),
    );
  }


  Widget mediaPickButton({required String label, required IconData icon, required Color color, required VoidCallback onPressed}) =>
      SizedBox(
        width: 154,
        height: 58,
        child: FilledButton.tonalIcon(
          onPressed: onPressed,
          style: FilledButton.styleFrom(
            backgroundColor: color.withOpacity(0.14),
            foregroundColor: color,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
              side: BorderSide(color: color.withOpacity(0.28)),
            ),
          ),
          icon: Icon(icon, size: 26, color: color),
          label: Text(label, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        ),
      );

  Widget buildShipmentForm() {
    if (!has('shipment.create')) return noAccess();
    return pageList(children: [
      sectionTitle(editingShipmentId == null ? 'ثبت سریع مرسوله' : 'ویرایش مرسوله', 'این صفحه، صفحه اصلی برنامه است.'),
      TextField(controller: fullnameController, decoration: const InputDecoration(labelText: 'نام و نام خانوادگی گیرنده')),
      const SizedBox(height: 10),
      TextField(controller: phoneController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره تماس')),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: shipmentType, decoration: const InputDecoration(labelText: 'نوع مرسوله'), items: shipmentTypes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => shipmentType = v ?? shipmentTypes.first)),
      const SizedBox(height: 10),
      TextField(controller: receiverController, minLines: 3, maxLines: 5, decoration: const InputDecoration(labelText: 'اطلاعات گیرنده / توضیحات')),
      const SizedBox(height: 10),
      buildDatePicker('تاریخ شمسی', jy, jm, jd, (y, m, d) => setState(() { jy = y; jm = m; jd = d; })),
      const SizedBox(height: 10),
      Center(
        child: Wrap(
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 12,
          runSpacing: 12,
          children: [
            mediaPickButton(label: 'دوربین', icon: Icons.add_a_photo_rounded, color: const Color(0xff00a8e8), onPressed: pickFromCamera),
            mediaPickButton(label: 'گالری', icon: Icons.photo_library_rounded, color: const Color(0xff16b886), onPressed: pickFromGallery),
            if (selectedPhotos.isNotEmpty) mediaPickButton(label: 'حذف عکس‌ها', icon: Icons.delete_sweep_rounded, color: kDanger, onPressed: () => setState(selectedPhotos.clear)),
          ],
        ),
      ),
      const SizedBox(height: 10),
      selectedPhotoPreview(),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: saving ? null : saveShipment, child: saving ? const CircularProgressIndicator() : const Text('ذخیره مرسوله'))),
    ]);
  }

  Widget buildDatePicker(String title, int y, int m, int d, void Function(int, int, int) onChanged) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: DropdownButtonFormField<int>(value: y, items: List.generate(8, (i) => 1403 + i).map((e) => DropdownMenuItem(value: e, child: Text(toFa(e)))).toList(), onChanged: (v) => onChanged(v ?? y, m, d), decoration: const InputDecoration(labelText: 'سال'))),
              const SizedBox(width: 8),
              Expanded(child: DropdownButtonFormField<int>(value: m, items: List.generate(12, (i) => i + 1).map((e) => DropdownMenuItem(value: e, child: Text(persianMonths[e - 1]))).toList(), onChanged: (v) => onChanged(y, v ?? m, d), decoration: const InputDecoration(labelText: 'ماه'))),
              const SizedBox(width: 8),
              Expanded(child: DropdownButtonFormField<int>(value: d, items: List.generate(31, (i) => i + 1).map((e) => DropdownMenuItem(value: e, child: Text(toFa(e)))).toList(), onChanged: (v) => onChanged(y, m, v ?? d), decoration: const InputDecoration(labelText: 'روز'))),
            ]),
          ]),
        ),
      );

  Widget buildReport() {
    if (!has('report.view')) return noAccess();
    final rows = reportRows();
    return pageList(children: [
      sectionTitle('گزارش مرسولات'),
      SegmentedButton<int>(segments: const [ButtonSegment(value: 0, label: Text('روزانه')), ButtonSegment(value: 1, label: Text('ماهانه')), ButtonSegment(value: 2, label: Text('همه'))], selected: {reportTypeIndex}, onSelectionChanged: (v) => setState(() => reportTypeIndex = v.first)),
      const SizedBox(height: 10),
      if (reportTypeIndex != 2) buildDatePicker('تاریخ گزارش', ry, rm, rd, (y, m, d) => setState(() { ry = y; rm = m; rd = d; })),
      Card(child: ListTile(leading: const Icon(Icons.bar_chart), title: Text('تعداد نتیجه: ${toFa(rows.length)}'))),
      ...rows.map((e) => Card(child: ListTile(title: Text(e.fullname), subtitle: Text('${e.trackingCode} | ${e.shamsiDate}')))),
    ]);
  }

  Widget buildSmsSend() {
    if (!has('sms.send')) return noAccess();
    return pageList(children: [
      sectionTitle('ارسال پیامک', 'پیام‌ها بعد از ارسال در دیتابیس آنلاین ذخیره می‌شوند'),
      DropdownButtonFormField<String>(value: smsService, decoration: const InputDecoration(labelText: 'سرویس ارسال'), items: const [DropdownMenuItem(value: 'smsir', child: Text('SMS.ir')), DropdownMenuItem(value: 'melli', child: Text('ملی پیامک'))], onChanged: (v) => setState(() => smsService = v ?? 'smsir')),
      const SizedBox(height: 10),
      TextField(controller: smsSenderController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره خط فرستنده')),
      const SizedBox(height: 10),
      TextField(controller: smsGroupController, decoration: const InputDecoration(labelText: 'عنوان گروه ارسال - اختیاری')),
      const SizedBox(height: 10),
      TextField(controller: smsNumbersController, minLines: 5, maxLines: 10, keyboardType: TextInputType.multiline, decoration: const InputDecoration(labelText: 'شماره گیرنده‌ها + نام اختیاری', hintText: 'مثال:\n09123456789\nعلی احمدی\nیا: 09123456789 علی احمدی')),
      const SizedBox(height: 10),
      TextField(controller: smsTextController, minLines: 5, maxLines: 10, decoration: const InputDecoration(labelText: 'متن پیام')),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(onPressed: sendingSms ? null : sendSms, icon: const Icon(Icons.send), label: sendingSms ? const Text('در حال ارسال...') : const Text('ارسال و ذخیره آنلاین'))),
      const SizedBox(height: 8),
      const Card(child: ListTile(leading: Icon(Icons.security), title: Text('API Key داخل اپ نیست'), subtitle: Text('کلیدهای SMS فقط در هاست و فایل PHP نگهداری می‌شوند.'))),
    ]);
  }

  List<SmsGroup> groupedSmsMessages() {
    final map = <String, List<SmsMessage>>{};
    final titles = <String, String>{};
    for (final message in smsMessages) {
      final fallbackDate = message.createdAt.length >= 10 ? message.createdAt.substring(0, 10) : message.createdAt;
      final key = message.groupId.isNotEmpty ? message.groupId : '${message.text}__$fallbackDate';
      map.putIfAbsent(key, () => []).add(message);
      titles[key] = message.groupTitle.isNotEmpty ? message.groupTitle : (message.text.length > 42 ? '${message.text.substring(0, 42)}...' : message.text);
    }
    final groups = map.entries.map((e) => SmsGroup(id: e.key, title: titles[e.key] ?? 'ارسال پیامک', messages: e.value)).toList();
    groups.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return groups;
  }

  String smsDeliveryLabel(SmsMessage m) {
    final level = m.deliveryLevel;
    if (level == 'delivered') return 'رسیده به گوشی';
    if (level == 'failed') return 'ناموفق / نرسیده';
    if (level == 'operator') return 'تحویل به مخابرات';
    if (level == 'pending') return 'در انتظار رسیدن به گوشی';
    return m.deliveryText.isNotEmpty ? m.deliveryText : 'در انتظار بررسی خودکار';
  }

  Color smsStatusColor(SmsMessage m) {
    if (!m.sendOk || m.deliveryLevel == 'failed') return kDanger;
    if (m.deliveryLevel == 'delivered') return kNavy2;
    return kNavy;
  }

  String smsSendLabel(SmsMessage m) => m.sendOk ? 'ارسال موفق' : 'ارسال ناموفق';

  Widget smsStatusBadge(String text, Color color, {IconData? icon}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: color.withOpacity(0.22)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[
            Icon(icon, size: 14, color: color),
            const SizedBox(width: 4),
          ],
          Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900)),
        ]),
      );

  Widget smsGroupMetric(String label, int value, Color color, IconData icon) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.18)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 15, color: color),
          const SizedBox(width: 5),
          Text('$label: ${toFa(value)}', style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
        ]),
      );

  Widget buildSmsMessages() {
    if (!has('sms.view')) return noAccess();
    final groups = groupedSmsMessages();
    return pageList(onRefresh: loadSmsMessages, children: [
      sectionTitle('پیام‌های ثبت‌شده امروز', autoCheckingDelivery ? 'بررسی خودکار دلیوری در حال انجام است...' : 'بدون جستجو فقط پیام‌های امروز نمایش داده می‌شود؛ جستجو کل پیام‌ها را می‌گردد.'),
      Row(children: [
        Expanded(child: TextField(controller: smsSearchController, decoration: InputDecoration(prefixIcon: const Icon(Icons.search), labelText: 'جستجو شماره، متن، نام یا عنوان گروه', suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: loadSmsMessages)), onSubmitted: (_) => loadSmsMessages())),
        const SizedBox(width: 8),
        Chip(label: const Text('امروز'), avatar: const Icon(Icons.today_rounded, size: 18)),
      ]),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: () => autoUpdatePendingDeliveries(force: true), icon: const Icon(Icons.autorenew_rounded), label: const Text('بررسی خودکار دلیوری'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton.icon(onPressed: () => syncOldLocalSmsMessages(manual: true), icon: const Icon(Icons.cloud_upload_rounded), label: const Text('همگام‌سازی پنل/گوشی'))),
      ]),
      const SizedBox(height: 10),
      if (smsMessages.isEmpty) emptyBox('پیامی پیدا نشد'),
      ...groups.map((g) {
        final failed = g.failedCount;
        final mainColor = failed > 0 ? kDanger : (g.deliveredCount == g.messages.length && g.messages.isNotEmpty ? kNavy2 : kNavy);
        return Card(
          child: Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              collapsedShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              leading: Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kSoftBlue, kSoftGreen]),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: kBorder),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.forum_rounded, size: 18, color: kNavy),
                  Text(toFa(g.messages.length), style: const TextStyle(color: kText, fontWeight: FontWeight.w900, fontSize: 13)),
                ]),
              ),
              title: Text(g.title.isEmpty ? 'ارسال بدون عنوان' : g.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: kText, fontSize: 16)),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(g.text, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(height: 1.65, color: kMuted, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  Wrap(spacing: 6, runSpacing: 6, children: [
                    smsGroupMetric('گیرنده', g.messages.length, kNavy, Icons.people_alt_outlined),
                    smsGroupMetric('موفق', g.successCount, kNavy2, Icons.check_circle_outline),
                    smsGroupMetric('تحویل', g.deliveredCount, kNavy2, Icons.done_all_rounded),
                    if (failed > 0) smsGroupMetric('ناموفق', failed, kDanger, Icons.error_outline),
                  ]),
                  const SizedBox(height: 8),
                  Row(children: [
                    Icon(Icons.access_time_rounded, size: 15, color: mainColor),
                    const SizedBox(width: 4),
                    Expanded(child: Text('تاریخ: ${g.createdAt}', style: const TextStyle(color: kMuted, fontSize: 12, fontWeight: FontWeight.w700))),
                  ]),
                ]),
              ),
              children: [
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(top: 4, bottom: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: kSoftMint,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kBorder),
                  ),
                  child: Text(g.text, style: const TextStyle(height: 1.75, color: kText, fontWeight: FontWeight.w700)),
                ),
                ...g.messages.map((m) {
                  final itemColor = smsStatusColor(m);
                  final delivery = smsDeliveryLabel(m);
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(11),
                    decoration: BoxDecoration(
                      color: kSurface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: itemColor.withOpacity(0.20)),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(color: itemColor.withOpacity(0.12), shape: BoxShape.circle),
                          child: Icon(m.deliveryLevel == 'delivered' ? Icons.check_rounded : (m.deliveryLevel == 'failed' ? Icons.close_rounded : Icons.schedule_rounded), color: itemColor),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(m.fullName.isNotEmpty ? m.fullName : 'بدون نام', style: const TextStyle(fontWeight: FontWeight.w900, color: kText)),
                          const SizedBox(height: 3),
                          Text(m.receiver, textDirection: TextDirection.ltr, style: const TextStyle(color: kMuted, fontWeight: FontWeight.w800)),
                        ])),
                        smsStatusBadge(m.service.toUpperCase(), kNavy),
                      ]),
                      const SizedBox(height: 9),
                      Wrap(spacing: 6, runSpacing: 6, children: [
                        smsStatusBadge(smsSendLabel(m), itemColor, icon: m.sendOk ? Icons.check_circle_outline : Icons.error_outline),
                        smsStatusBadge('دلیوری: $delivery', m.deliveryLevel == 'failed' ? kDanger : (m.deliveryLevel == 'delivered' ? kNavy2 : kNavy), icon: Icons.cell_tower_rounded),
                      ]),
                      const SizedBox(height: 8),
                      Text('زمان: ${m.createdAt}', style: const TextStyle(color: kMuted, fontSize: 12)),
                      const SizedBox(height: 8),
                      Wrap(spacing: 8, runSpacing: 8, children: [
                        SizedBox(
                          width: 142,
                          child: FilledButton.tonalIcon(
                            onPressed: m.recId.isNotEmpty ? () => updateDelivery(m) : null,
                            icon: Icon(m.deliveryLevel == 'delivered' ? Icons.verified_rounded : Icons.autorenew_rounded),
                            label: Text(m.deliveryLevel == 'delivered' ? 'تأیید رسیدن' : 'دلیوری خودکار'),
                          ),
                        ),
                        if (has('sms.send')) SizedBox(
                          width: 142,
                          child: OutlinedButton.icon(
                            onPressed: () { smsNumbersController.text = m.fullName.isNotEmpty ? '${m.receiver} ${m.fullName}' : m.receiver; smsTextController.text = m.text; smsGroupController.text = 'ارسال مجدد'; openPage(2); },
                            icon: const Icon(Icons.replay_rounded),
                            label: const Text('ارسال مجدد'),
                          ),
                        ),
                        if (has('sms.send')) SizedBox(
                          width: 154,
                          child: FilledButton.icon(
                            onPressed: () => sendWithDeviceSms(m),
                            icon: const Icon(Icons.phone_android_rounded),
                            label: Text((m.deliveryLevel == 'failed' || !m.sendOk) ? 'ارسال با گوشی' : 'ارسال با گوشی'),
                          ),
                        ),
                      ]),
                    ]),
                  );
                }),
              ],
            ),
          ),
        );
      }),
    ]);
  }

  Widget buildSmsContacts() {
    if (!has('sms.view')) return noAccess();
    return pageList(onRefresh: loadSmsContacts, children: [
      sectionTitle('استخراج شماره‌ها', 'از پیام‌های ذخیره‌شده آنلاین'),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: loadSmsContacts, icon: const Icon(Icons.refresh), label: const Text('به‌روزرسانی'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.tonalIcon(onPressed: shareVcf, icon: const Icon(Icons.save_alt), label: const Text('ذخیره VCF'))),
      ]),
      const SizedBox(height: 10),
      Card(child: ListTile(leading: const Icon(Icons.contacts), title: Text('شماره‌های یکتا: ${toFa(smsContacts.length)}'))),
      if (smsContacts.isEmpty) emptyBox('شماره‌ای پیدا نشد'),
      ...smsContacts.map((c) => Card(child: ListTile(leading: const Icon(Icons.person), title: Text(c.number, textDirection: TextDirection.ltr), subtitle: Text((c.name.isNotEmpty ? c.name : 'بدون نام') + ' | تعداد پیام: ${toFa(c.count)}')))),
    ]);
  }

  Widget permissionSwitch(String title, String subtitle, bool value, ValueChanged<bool> onChanged, {bool enabled = true}) => SwitchListTile(
        value: value,
        onChanged: enabled ? onChanged : null,
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        activeColor: kOrange,
        contentPadding: EdgeInsets.zero,
      );

  String userPermissionSummary(AppUser u) {
    if (u.role == 'admin') return 'دسترسی کامل مدیر';
    final labels = <String>[];
    if (u.can('sms.send')) labels.add('ارسال پیام');
    if (u.can('sms.view')) labels.add('مشاهده پیام‌ها');
    if (u.can('shipment.create')) labels.add('ثبت مرسوله');
    if (u.can('shipment.view')) labels.add('مشاهده مرسولات');
    return labels.isEmpty ? 'بدون دسترسی عملیاتی' : labels.join('، ');
  }

  Widget buildUsers() {
    if (!has('user.view')) return noAccess();
    final isEditingUser = userIdController.text.trim().isNotEmpty;
    final editingIsAdmin = users.any((u) => u.id.toString() == userIdController.text.trim() && u.role == 'admin') || newUserController.text.trim() == 'admin';
    return pageList(onRefresh: loadUsers, children: [
      sectionTitle(isEditingUser ? 'ویرایش کاربر' : 'مدیریت کاربران', 'برای هر کاربر دسترسی بخش‌ها را جداگانه مشخص کن'),
      if (has('user.manage')) Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (isEditingUser)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(color: const Color(0xfffff7ed), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xffffedd5))),
            child: Text('حالت ویرایش فعال است؛ شناسه کاربر: ${userIdController.text}', textAlign: TextAlign.center),
          ),
        TextField(controller: newUserController, decoration: const InputDecoration(labelText: 'نام کاربری')),
        const SizedBox(height: 10),
        TextField(controller: newPassController, obscureText: true, decoration: InputDecoration(labelText: isEditingUser ? 'رمز جدید؛ اگر خالی بماند تغییر نمی‌کند' : 'رمز عبور')),
        SwitchListTile(value: newUserActive, onChanged: (v) => setState(() => newUserActive = v), title: const Text('کاربر فعال باشد'), activeColor: kOrange, contentPadding: EdgeInsets.zero),
        const Divider(),
        Text('دسترسی‌ها', style: TextStyle(color: Colors.blueGrey.shade700, fontWeight: FontWeight.w900)),
        if (editingIsAdmin)
          const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('کاربر admin دسترسی کامل دارد و محدود نمی‌شود.')),
        permissionSwitch('ارسال پیامک', 'اجازه ورود به صفحه ارسال پیام و ارسال از پنل پیامکی', permSmsSend, (v) => setState(() => permSmsSend = v), enabled: !editingIsAdmin),
        permissionSwitch('مشاهده پیام‌های ارسالی', 'اجازه دیدن پیام‌های ذخیره‌شده، گروه‌ها و استخراج شماره‌ها', permSmsView, (v) => setState(() => permSmsView = v), enabled: !editingIsAdmin),
        permissionSwitch('ثبت مرسولات', 'اجازه ثبت سریع مرسوله جدید', permShipmentCreate, (v) => setState(() => permShipmentCreate = v), enabled: !editingIsAdmin),
        permissionSwitch('مشاهده مرسولات ثبت‌شده', 'اجازه دیدن لیست و جستجوی مرسولات', permShipmentView, (v) => setState(() => permShipmentView = v), enabled: !editingIsAdmin),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: FilledButton(onPressed: saveUser, child: Text(isEditingUser ? 'ذخیره ویرایش' : 'ثبت کاربر'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton(onPressed: resetUserForm, child: const Text('فرم جدید'))),
        ]),
      ]))),
      if (users.isEmpty) emptyBox('کاربری پیدا نشد'),
      ...users.map((u) => Card(child: ListTile(
        leading: Icon(u.isActive ? Icons.check_circle_outline : Icons.block_outlined, color: u.isActive ? kNavy : kDanger),
        title: Text(u.username, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('${u.roleLabel} | ${u.isActive ? 'فعال' : 'غیرفعال'}\n${userPermissionSummary(u)}\nآخرین ورود: ${u.lastLoginAt}', maxLines: 4),
        isThreeLine: true,
        trailing: has('user.manage') ? Wrap(spacing: 4, children: [
          IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'ویرایش', onPressed: () => editUser(u)),
          if (u.username != 'admin') IconButton(icon: const Icon(Icons.block), tooltip: 'غیرفعال کردن', onPressed: () => disableUser(u)),
        ]) : null,
      ))),
    ]);
  }

  Widget buildLogs() {
    if (!has('log.view')) return noAccess();
    return pageList(onRefresh: loadLogs, children: [
      sectionTitle('لاگ‌ها'),
      TextField(controller: logUserController, decoration: InputDecoration(labelText: 'فیلتر نام کاربری', suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: loadLogs))),
      const SizedBox(height: 10),
      if (logs.isEmpty) emptyBox('لاگی پیدا نشد'),
      ...logs.map((l) => Card(child: ListTile(title: Text('${l.action} | ${l.entity}'), subtitle: Text('${l.username} | ${l.createdAt}\n${l.details}'), isThreeLine: true))),
    ]);
  }

  Widget emptyBox(String text) => Card(child: Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(text, style: TextStyle(color: Colors.blueGrey.shade600)))));
  Widget noAccess() => Center(child: Text('شما به این بخش دسترسی ندارید', style: TextStyle(color: Colors.blueGrey.shade700, fontWeight: FontWeight.bold)));
}
