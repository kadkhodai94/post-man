import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const PostManagementApp());
}

const List<String> persianMonths = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
];

const List<String> shipmentTypes = [
  'بسته',
  'پاکت',
  'امانت',
  'کارت سوخت',
  'کارت بانکی',
  'کارت پلاک',
  'برگ سبز',
];

const Map<String, String> statusText = {
  'registered': 'ثبت شد',
  'processing': 'در حال پردازش',
  'in_transit': 'در مسیر',
  'delivered': 'تحویل شد',
  'returned': 'برگشتی',
  'cancelled': 'لغو شده',
};

String toFa(Object? value) {
  return '$value'.replaceAllMapped(RegExp(r'\d'), (m) => '۰۱۲۳۴۵۶۷۸۹'[int.parse(m.group(0)!)]);
}

String dateVal(int y, int m, int d) => '$y/${persianMonths[m - 1]}/$d';

List<int> gregorianToJalali(int gy, int gm, int gd) {
  final gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  var jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  final gy2 = gm > 2 ? gy + 1 : gy;
  var days = 365 * gy +
      ((gy2 + 3) ~/ 4) -
      ((gy2 + 99) ~/ 100) +
      ((gy2 + 399) ~/ 400) -
      80 +
      gd +
      gdm[gm - 1];
  jy += 33 * (days ~/ 12053);
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    jy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  final jm = days < 186 ? 1 + (days ~/ 31) : 7 + ((days - 186) ~/ 30);
  final jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

class PostManagementApp extends StatelessWidget {
  const PostManagementApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مدیریت مرسولات',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff1d4ed8)),
        useMaterial3: true,
        fontFamily: 'sans',
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: Colors.blueGrey.shade100),
          ),
        ),
      ),
      builder: (context, child) {
        return Directionality(textDirection: TextDirection.rtl, child: child!);
      },
      home: const HomePage(),
    );
  }
}

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}

class ApiService {
  String baseUrl = '';
  String token = '';

  Uri uri(String path, [Map<String, String>? query]) {
    final normalized = baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    final fullPath = path.startsWith('/') ? path : '/$path';
    final parsed = Uri.parse('$normalized$fullPath');
    return query == null ? parsed : parsed.replace(queryParameters: query);
  }

  String imageUrl(String src) {
    if (src.startsWith('http://') || src.startsWith('https://')) return src;
    final root = baseUrl.trim().replaceAll(RegExp(r'/api/?$'), '').replaceAll(RegExp(r'/+$'), '');
    final clean = src.startsWith('/') ? src.substring(1) : src;
    return '$root/$clean';
  }

  Map<String, String> get authHeaders => token.isEmpty ? {} : {'Authorization': 'Bearer $token'};

  Future<Map<String, dynamic>> login(String username, String password) async {
    final response = await http.post(
      uri('/login.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> getJson(String path, {Map<String, String>? query}) async {
    final response = await http.get(uri(path, query), headers: authHeaders);
    return _decode(response);
  }

  Future<Map<String, dynamic>> postJson(String path, Map<String, dynamic> data) async {
    final response = await http.post(
      uri(path),
      headers: {'Content-Type': 'application/json', ...authHeaders},
      body: jsonEncode(data),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> deleteJson(String path, {Map<String, String>? query}) async {
    final response = await http.delete(uri(path, query), headers: authHeaders);
    return _decode(response);
  }

  Future<Map<String, dynamic>> saveShipment({
    required Map<String, String> fields,
    required List<PendingPhoto> photos,
  }) async {
    final request = http.MultipartRequest('POST', uri('/save.php'));
    request.headers.addAll(authHeaders);
    request.fields.addAll(fields);
    for (var i = 0; i < photos.length; i++) {
      final name = photos[i].file.name.isEmpty ? 'photo_${i + 1}.jpg' : photos[i].file.name;
      request.files.add(http.MultipartFile.fromBytes('images[]', photos[i].bytes, filename: name));
    }
    final streamed = await request.send();
    final response = await http.Response.fromStream(streamed);
    return _decode(response);
  }

  Map<String, dynamic> _decode(http.Response response) {
    Map<String, dynamic>? json;
    try {
      json = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      throw ApiException('پاسخ سرور معتبر نیست: ${response.body.substring(0, response.body.length < 180 ? response.body.length : 180)}');
    }
    if (json['ok'] != true) {
      throw ApiException((json['error'] ?? 'خطای سرور').toString());
    }
    return json;
  }
}

class Shipment {
  Shipment({
    required this.id,
    required this.trackingCode,
    required this.fullname,
    required this.phone,
    required this.receiverInfo,
    required this.shipmentType,
    required this.status,
    required this.shamsiDate,
    required this.description,
    required this.images,
    required this.createdBy,
    required this.updatedBy,
    required this.createdAt,
  });

  final int id;
  final String trackingCode;
  final String fullname;
  final String phone;
  final String receiverInfo;
  final String shipmentType;
  final String status;
  final String shamsiDate;
  final String description;
  final List<String> images;
  final String createdBy;
  final String updatedBy;
  final String createdAt;

  factory Shipment.fromJson(Map<String, dynamic> json) {
    final rawImages = json['images'];
    final images = <String>[];
    if (rawImages is List) {
      images.addAll(rawImages.map((e) => e.toString()).where((e) => e.isNotEmpty));
    } else if (rawImages is String && rawImages.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(rawImages);
        if (decoded is List) images.addAll(decoded.map((e) => e.toString()).where((e) => e.isNotEmpty));
      } catch (_) {}
    }
    final single = (json['image'] ?? '').toString();
    if (images.isEmpty && single.isNotEmpty) images.add(single);
    return Shipment(
      id: int.tryParse('${json['id']}') ?? 0,
      trackingCode: (json['tracking_code'] ?? '').toString(),
      fullname: (json['fullname'] ?? '').toString(),
      phone: (json['phone'] ?? '').toString(),
      receiverInfo: (json['receiver_info'] ?? '').toString(),
      shipmentType: (json['shipment_type'] ?? 'بسته').toString(),
      status: (json['status'] ?? 'registered').toString(),
      shamsiDate: (json['shamsi_date'] ?? '').toString(),
      description: (json['description'] ?? '').toString(),
      images: images,
      createdBy: (json['created_by'] ?? '').toString(),
      updatedBy: (json['updated_by'] ?? '').toString(),
      createdAt: (json['created_at'] ?? '').toString(),
    );
  }
}

class AppUser {
  AppUser({required this.id, required this.username, required this.roleLabel, required this.isActive, required this.lastLoginAt});
  final int id;
  final String username;
  final String roleLabel;
  final bool isActive;
  final String lastLoginAt;

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        id: int.tryParse('${json['id']}') ?? 0,
        username: (json['username'] ?? '').toString(),
        roleLabel: (json['role_label'] ?? json['role'] ?? 'کاربر عادی').toString(),
        isActive: '${json['is_active']}' == '1',
        lastLoginAt: (json['last_login_at'] ?? '-').toString(),
      );
}

class AppLog {
  AppLog({required this.createdAt, required this.username, required this.action, required this.entity, required this.ip, required this.details});
  final String createdAt;
  final String username;
  final String action;
  final String entity;
  final String ip;
  final String details;

  factory AppLog.fromJson(Map<String, dynamic> json) => AppLog(
        createdAt: (json['created_at'] ?? '').toString(),
        username: (json['username'] ?? '-').toString(),
        action: (json['action'] ?? '-').toString(),
        entity: '${json['entity'] ?? '-'} #${json['entity_id'] ?? ''}',
        ip: (json['ip_address'] ?? '-').toString(),
        details: (json['details'] ?? '-').toString(),
      );
}

class DashboardData {
  DashboardData({
    required this.total,
    required this.today,
    required this.month,
    required this.byStatus,
    required this.byType,
    required this.last7Days,
    required this.latest,
  });

  final int total;
  final int today;
  final int month;
  final Map<String, int> byStatus;
  final Map<String, int> byType;
  final List<MapEntry<String, int>> last7Days;
  final List<Shipment> latest;

  factory DashboardData.fromJson(Map<String, dynamic> json) {
    Map<String, int> readMap(dynamic value) {
      if (value is! Map) return {};
      return value.map((k, v) => MapEntry(k.toString(), int.tryParse('$v') ?? 0));
    }

    final chart = <MapEntry<String, int>>[];
    final chartRaw = json['last_7_days'];
    if (chartRaw is List) {
      for (final row in chartRaw) {
        if (row is Map) chart.add(MapEntry((row['date'] ?? '').toString(), int.tryParse('${row['count']}') ?? 0));
      }
    }

    final latest = <Shipment>[];
    final latestRaw = json['latest'];
    if (latestRaw is List) {
      for (final row in latestRaw) {
        if (row is Map<String, dynamic>) latest.add(Shipment.fromJson(row));
        if (row is Map && row is! Map<String, dynamic>) latest.add(Shipment.fromJson(Map<String, dynamic>.from(row)));
      }
    }

    return DashboardData(
      total: int.tryParse('${json['total']}') ?? 0,
      today: int.tryParse('${json['today']}') ?? 0,
      month: int.tryParse('${json['month']}') ?? 0,
      byStatus: readMap(json['by_status']),
      byType: readMap(json['by_type']),
      last7Days: chart,
      latest: latest,
    );
  }
}

class PendingPhoto {
  PendingPhoto(this.file, this.bytes);
  final XFile file;
  final Uint8List bytes;
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final api = ApiService();
  final picker = ImagePicker();

  final apiController = TextEditingController();
  final loginUserController = TextEditingController(text: 'admin');
  final loginPassController = TextEditingController();

  final searchController = TextEditingController();
  final fullnameController = TextEditingController();
  final phoneController = TextEditingController();
  final receiverController = TextEditingController();
  final userIdController = TextEditingController();
  final newUserController = TextEditingController();
  final newPassController = TextEditingController();
  final logUserController = TextEditingController();

  bool loggedIn = false;
  bool loading = false;
  bool saving = false;
  bool rememberMe = true;
  String username = '';
  String role = '';
  String roleLabel = '';
  List<String> permissions = [];

  int pageIndex = 2;
  bool logsOpen = false;
  String shipmentType = shipmentTypes.first;
  int jy = 1405;
  int jm = 1;
  int jd = 1;
  int? editingShipmentId;
  List<PendingPhoto> selectedPhotos = [];

  int reportTypeIndex = 0;
  int ry = 1405;
  int rm = 1;
  int rd = 1;
  String logAction = '';
  String logEntity = '';
  bool newUserActive = true;

  DashboardData? dashboard;
  List<Shipment> shipments = [];
  List<AppUser> users = [];
  List<AppLog> logs = [];
  Timer? searchDebounce;

  bool has(String permission) => permissions.contains(permission);

  @override
  void initState() {
    super.initState();
    _setToday();
    _restoreSession();
  }

  @override
  void dispose() {
    searchDebounce?.cancel();
    apiController.dispose();
    loginUserController.dispose();
    loginPassController.dispose();
    searchController.dispose();
    fullnameController.dispose();
    phoneController.dispose();
    receiverController.dispose();
    userIdController.dispose();
    newUserController.dispose();
    newPassController.dispose();
    logUserController.dispose();
    super.dispose();
  }

  void _setToday() {
    final now = DateTime.now();
    final j = gregorianToJalali(now.year, now.month, now.day);
    jy = ry = j[0];
    jm = rm = j[1];
    jd = rd = j[2];
  }

  Future<void> _restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    apiController.text = prefs.getString('post_api_base') ?? '';
    final token = prefs.getString('post_token') ?? '';
    if (token.isEmpty || apiController.text.trim().isEmpty) return;
    api.baseUrl = apiController.text.trim();
    api.token = token;
    username = prefs.getString('post_user') ?? '';
    role = prefs.getString('post_role') ?? '';
    roleLabel = prefs.getString('post_role_label') ?? role;
    permissions = prefs.getStringList('post_permissions') ?? [];
    setState(() => loggedIn = true);
    await boot();
  }

  Future<void> login() async {
    final base = apiController.text.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) return showSnack('آدرس API را وارد کنید؛ مثال: https://domain.com/api');
    setState(() => loading = true);
    try {
      api.baseUrl = base;
      final result = await api.login(loginUserController.text.trim(), loginPassController.text);
      api.token = result['token'].toString();
      username = (result['username'] ?? '').toString();
      role = (result['role'] ?? '').toString();
      roleLabel = (result['role_label'] ?? role).toString();
      permissions = (result['permissions'] as List? ?? []).map((e) => e.toString()).toList();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('post_api_base', base);
      await prefs.setString('post_token', api.token);
      await prefs.setString('post_user', username);
      await prefs.setString('post_role', role);
      await prefs.setString('post_role_label', roleLabel);
      await prefs.setStringList('post_permissions', permissions);
      loggedIn = true;
      pageIndex = has('dashboard.view') ? 0 : 2;
      await boot();
      showSnack('ورود موفق بود');
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('post_token');
    await prefs.remove('post_user');
    await prefs.remove('post_role');
    await prefs.remove('post_role_label');
    await prefs.remove('post_permissions');
    api.token = '';
    setState(() {
      loggedIn = false;
      dashboard = null;
      shipments.clear();
      users.clear();
      logs.clear();
    });
  }

  Future<void> boot() async {
    try {
      if (has('dashboard.view')) await loadDashboard();
      if (has('shipment.view')) await loadShipments();
      if (has('user.view')) await loadUsers();
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> loadDashboard() async {
    if (!has('dashboard.view')) return;
    final result = await api.getJson('/dashboard.php');
    setState(() => dashboard = DashboardData.fromJson(Map<String, dynamic>.from(result['data'])));
  }

  Future<void> loadShipments() async {
    if (!has('shipment.view')) return;
    final query = <String, String>{};
    final q = searchController.text.trim();
    if (q.isNotEmpty) query['q'] = q;
    final result = await api.getJson('/shipments.php', query: query);
    final data = result['data'] as List? ?? [];
    setState(() => shipments = data.map((e) => Shipment.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadUsers() async {
    if (!has('user.view')) return;
    final result = await api.getJson('/users.php');
    final data = result['data'] as List? ?? [];
    setState(() => users = data.map((e) => AppUser.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadLogs() async {
    if (!has('log.view')) return;
    final query = <String, String>{};
    if (logUserController.text.trim().isNotEmpty) query['username'] = logUserController.text.trim();
    if (logAction.isNotEmpty) query['action'] = logAction;
    if (logEntity.isNotEmpty) query['entity'] = logEntity;
    final result = await api.getJson('/logs.php', query: query);
    final data = result['data'] as List? ?? [];
    setState(() => logs = data.map((e) => AppLog.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  void showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  bool canOpen(int index) {
    switch (index) {
      case 0:
        return has('dashboard.view');
      case 1:
        return has('shipment.view');
      case 2:
        return has('shipment.create');
      case 3:
        return has('report.view');
      case 4:
        return has('user.view');
    }
    return false;
  }

  Future<void> openPage(int index) async {
    if (!canOpen(index)) return showSnack('شما به این قسمت دسترسی ندارید');
    setState(() {
      pageIndex = index;
      logsOpen = false;
    });
    try {
      if (index == 0) await loadDashboard();
      if (index == 1) await loadShipments();
      if (index == 4) await loadUsers();
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> pickFromCamera() async {
    final photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 82, maxWidth: 1600);
    if (photo == null) return;
    final bytes = await photo.readAsBytes();
    setState(() => selectedPhotos.add(PendingPhoto(photo, bytes)));
  }

  Future<void> pickFromGallery() async {
    final photos = await picker.pickMultiImage(imageQuality: 82, maxWidth: 1600);
    if (photos.isEmpty) return;
    final pending = <PendingPhoto>[];
    for (final photo in photos) {
      pending.add(PendingPhoto(photo, await photo.readAsBytes()));
    }
    setState(() => selectedPhotos.addAll(pending));
  }

  Future<void> saveShipment() async {
    if (fullnameController.text.trim().isEmpty) return showSnack('نام و نام خانوادگی گیرنده الزامی است');
    setState(() => saving = true);
    try {
      await api.saveShipment(
        fields: {
          'editId': editingShipmentId?.toString() ?? '',
          'fullname': fullnameController.text.trim(),
          'phone': phoneController.text.trim(),
          'shipment_type': shipmentType,
          'receiver_info': receiverController.text.trim(),
          'description': '',
          'shamsi_date': dateVal(jy, jm, jd),
        },
        photos: selectedPhotos,
      );
      resetForm();
      if (has('shipment.view')) await loadShipments();
      if (has('dashboard.view')) await loadDashboard();
      showSnack('مرسوله ذخیره شد');
      if (has('shipment.view')) setState(() => pageIndex = 1);
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void resetForm() {
    fullnameController.clear();
    phoneController.clear();
    receiverController.clear();
    editingShipmentId = null;
    shipmentType = shipmentTypes.first;
    selectedPhotos.clear();
    _setToday();
    setState(() {});
  }

  void editShipment(Shipment shipment) {
    if (!has('shipment.edit')) return showSnack('شما اجازه ویرایش ندارید');
    setState(() {
      editingShipmentId = shipment.id;
      fullnameController.text = shipment.fullname;
      phoneController.text = shipment.phone;
      receiverController.text = shipment.receiverInfo;
      shipmentType = shipmentTypes.contains(shipment.shipmentType) ? shipment.shipmentType : shipmentTypes.first;
      selectedPhotos.clear();
      pageIndex = 2;
    });
  }

  Future<void> deleteShipment(Shipment shipment) async {
    if (!has('shipment.delete')) return showSnack('شما اجازه حذف ندارید');
    final confirmed = await confirm('این مرسوله حذف شود؟');
    if (confirmed != true) return;
    try {
      await api.deleteJson('/delete.php', query: {'id': shipment.id.toString()});
      await loadShipments();
      if (has('dashboard.view')) await loadDashboard();
      showSnack('مرسوله حذف شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<bool?> confirm(String message) {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تأیید'),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تأیید')),
        ],
      ),
    );
  }

  Future<void> saveUser() async {
    if (!has('user.manage')) return showSnack('شما اجازه مدیریت کاربر ندارید');
    try {
      await api.postJson('/save_user.php', {
        'id': int.tryParse(userIdController.text) ?? 0,
        'username': newUserController.text.trim(),
        'password': newPassController.text,
        'is_active': newUserActive ? 1 : 0,
      });
      resetUserForm();
      await loadUsers();
      showSnack('کاربر ذخیره شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  void resetUserForm() {
    userIdController.clear();
    newUserController.clear();
    newPassController.clear();
    newUserActive = true;
    setState(() {});
  }

  void editUser(AppUser user) {
    setState(() {
      userIdController.text = user.id.toString();
      newUserController.text = user.username;
      newPassController.clear();
      newUserActive = user.isActive;
    });
  }

  Future<void> disableUser(AppUser user) async {
    if (!has('user.manage')) return;
    final confirmed = await confirm('کاربر ${user.username} غیرفعال شود؟');
    if (confirmed != true) return;
    try {
      await api.deleteJson('/delete_user.php', query: {'id': user.id.toString()});
      await loadUsers();
      showSnack('کاربر غیرفعال شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  List<Shipment> reportRows() {
    final rows = List<Shipment>.from(shipments);
    if (reportTypeIndex == 0) return rows.where((e) => e.shamsiDate == dateVal(ry, rm, rd)).toList();
    if (reportTypeIndex == 1) return rows.where((e) => e.shamsiDate.startsWith('$ry/${persianMonths[rm - 1]}/')).toList();
    return rows;
  }

  @override
  Widget build(BuildContext context) {
    return loggedIn ? buildAppShell() : buildLogin();
  }

  Widget buildLogin() {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xff0f172a), Color(0xff1d4ed8), Color(0xff38bdf8)]),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: Card(
                elevation: 18,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('📮', style: TextStyle(fontSize: 54)),
                      const SizedBox(height: 8),
                      const Text('ورود به سامانه پست', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 6),
                      Text('نسخه فلاتر مدیریت مرسولات', style: TextStyle(color: Colors.blueGrey.shade600)),
                      const SizedBox(height: 18),
                      TextField(controller: apiController, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'آدرس API', hintText: 'https://your-domain.com/api')),
                      const SizedBox(height: 12),
                      TextField(controller: loginUserController, decoration: const InputDecoration(labelText: 'نام کاربری')),
                      const SizedBox(height: 12),
                      TextField(controller: loginPassController, obscureText: true, decoration: const InputDecoration(labelText: 'رمز عبور')),
                      const SizedBox(height: 10),
                      CheckboxListTile(
                        value: rememberMe,
                        onChanged: (v) => setState(() => rememberMe = v ?? true),
                        title: const Text('مرا به خاطر بسپار'),
                        controlAffinity: ListTileControlAffinity.leading,
                        contentPadding: EdgeInsets.zero,
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: FilledButton(
                          onPressed: loading ? null : login,
                          child: loading ? const CircularProgressIndicator() : const Text('ورود'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildAppShell() {
    final pages = [buildDashboard(), buildShipmentList(), buildShipmentForm(), buildReport(), buildUsers()];
    return Scaffold(
      appBar: AppBar(
        title: const Text('سامانه مدیریت مرسولات'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Center(child: Text('$username | $roleLabel', style: const TextStyle(fontSize: 12))),
          ),
          IconButton(onPressed: logout, icon: const Icon(Icons.logout), tooltip: 'خروج'),
        ],
      ),
      body: Container(
        color: const Color(0xfff3f6fb),
        child: SafeArea(child: pages[pageIndex]),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: pageIndex,
        onDestinationSelected: openPage,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'داشبورد'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'مرسولات'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'ثبت'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'گزارش'),
          NavigationDestination(icon: Icon(Icons.people_alt_outlined), selectedIcon: Icon(Icons.people_alt), label: 'کاربران'),
        ],
      ),
    );
  }

  Widget buildDashboard() {
    if (!has('dashboard.view')) return noAccess();
    final d = dashboard;
    return RefreshIndicator(
      onRefresh: loadDashboard,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          if (has('log.view'))
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.tonalIcon(
                onPressed: () async {
                  setState(() => logsOpen = !logsOpen);
                  if (logsOpen) await loadLogs();
                },
                icon: Icon(logsOpen ? Icons.close : Icons.receipt_long),
                label: Text(logsOpen ? 'بستن لاگ‌ها' : 'مشاهده لاگ‌ها'),
              ),
            ),
          if (logsOpen) buildLogsPanel() else ...[
            GridView.count(
              crossAxisCount: MediaQuery.sizeOf(context).width > 720 ? 4 : 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 1.45,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              children: [
                statCard('کل مرسولات', d?.total ?? 0),
                statCard('امروز', d?.today ?? 0),
                statCard('ماه جاری', d?.month ?? 0),
                statCard('تحویل شده', d?.byStatus['delivered'] ?? 0),
              ],
            ),
            const SizedBox(height: 12),
            appCard(title: 'روند ۷ روز اخیر', child: barList(d?.last7Days ?? [])),
            appCard(title: 'تفکیک وضعیت', child: barList((d?.byStatus ?? {}).entries.map((e) => MapEntry(statusText[e.key] ?? e.key, e.value)).toList())),
            appCard(title: 'تفکیک نوع مرسوله', child: barList((d?.byType ?? {}).entries.toList())),
            appCard(
              title: 'آخرین مرسولات',
              child: Column(
                children: (d?.latest ?? []).isEmpty
                    ? [const Text('هنوز مرسوله‌ای ثبت نشده است.')]
                    : (d?.latest ?? []).map((e) => ListTile(title: Text(e.fullname), subtitle: Text(e.trackingCode), leading: const Icon(Icons.inventory_2))).toList(),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget statCard(String title, int number) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: Colors.blueGrey.shade100)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(title, style: TextStyle(color: Colors.blueGrey.shade600, fontSize: 12)),
            const SizedBox(height: 8),
            Text(toFa(number), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }

  Widget appCard({required String title, required Widget child}) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: Colors.blueGrey.shade100)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          const SizedBox(height: 12),
          child,
        ]),
      ),
    );
  }

  Widget barList(List<MapEntry<String, int>> rows) {
    if (rows.isEmpty) return const Text('داده‌ای وجود ندارد.');
    final max = rows.map((e) => e.value).fold<int>(1, (a, b) => b > a ? b : a);
    return Column(
      children: rows.map((e) {
        final progress = (e.value / max).clamp(0.02, 1.0).toDouble();
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(
            children: [
              SizedBox(width: 96, child: Text(toFa(e.key), overflow: TextOverflow.ellipsis)),
              Expanded(child: LinearProgressIndicator(value: progress, minHeight: 10, borderRadius: BorderRadius.circular(99))),
              const SizedBox(width: 8),
              Text(toFa(e.value), style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget buildShipmentList({List<Shipment>? customRows, bool reportMode = false}) {
    if (!has('shipment.view')) return noAccess();
    final rows = customRows ?? shipments;
    return RefreshIndicator(
      onRefresh: loadShipments,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          if (!reportMode)
            appCard(
              title: 'جستجوی مرسوله',
              child: Column(
                children: [
                  TextField(
                    controller: searchController,
                    decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'نام، تلفن، کد رهگیری یا هر کلمه کلیدی'),
                    onChanged: (_) {
                      searchDebounce?.cancel();
                      searchDebounce = Timer(const Duration(milliseconds: 350), loadShipments);
                    },
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () {
                        searchController.clear();
                        loadShipments();
                      },
                      child: const Text('پاک کردن جستجو'),
                    ),
                  ),
                ],
              ),
            ),
          if (rows.isEmpty)
            appCard(title: 'مرسولات', child: const Text('موردی پیدا نشد.'))
          else
            ...rows.map((shipment) => shipmentCard(shipment, reportMode: reportMode)),
        ],
      ),
    );
  }

  Widget shipmentCard(Shipment shipment, {bool reportMode = false}) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 7),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: Colors.blueGrey.shade100)),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            imageThumb(shipment),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(shipment.fullname, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                  infoLine(Icons.confirmation_number_outlined, shipment.trackingCode.isEmpty ? '-' : shipment.trackingCode),
                  infoLine(Icons.phone_outlined, '${shipment.phone.isEmpty ? '-' : shipment.phone} | ${shipment.shipmentType}'),
                  infoLine(Icons.calendar_today_outlined, '${shipment.shamsiDate.isEmpty ? '-' : shipment.shamsiDate} | ${shipment.createdAt.length >= 16 ? shipment.createdAt.substring(0, 16) : shipment.createdAt}'),
                  infoLine(Icons.notes_outlined, shipment.receiverInfo.isEmpty ? '-' : shipment.receiverInfo),
                  infoLine(Icons.person_outline, 'ثبت‌کننده: ${shipment.createdBy.isEmpty ? '-' : shipment.createdBy}${shipment.updatedBy.isNotEmpty ? ' | ویرایش: ${shipment.updatedBy}' : ''}'),
                  if (!reportMode)
                    Wrap(
                      spacing: 7,
                      runSpacing: 7,
                      children: [
                        if (has('shipment.edit')) OutlinedButton(onPressed: () => editShipment(shipment), child: const Text('ویرایش')),
                        OutlinedButton(onPressed: () => showReceipt(shipment), child: const Text('رسید')),
                        if (has('shipment.delete')) FilledButton.tonal(onPressed: () => deleteShipment(shipment), child: const Text('حذف')),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget imageThumb(Shipment shipment) {
    if (shipment.images.isEmpty) {
      return Container(
        width: 82,
        height: 82,
        decoration: BoxDecoration(color: Colors.blueGrey.shade50, borderRadius: BorderRadius.circular(18)),
        child: const Icon(Icons.image_not_supported_outlined),
      );
    }
    return GestureDetector(
      onTap: () => showGallery(shipment.images),
      child: Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Image.network(api.imageUrl(shipment.images.first), width: 82, height: 82, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: 82, height: 82, color: Colors.blueGrey.shade50, child: const Icon(Icons.broken_image))),
          ),
          if (shipment.images.length > 1)
            Positioned(
              right: 4,
              bottom: 4,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                decoration: BoxDecoration(color: Colors.black.withOpacity(.65), borderRadius: BorderRadius.circular(99)),
                child: Text('${toFa(shipment.images.length)} عکس', style: const TextStyle(color: Colors.white, fontSize: 10)),
              ),
            ),
        ],
      ),
    );
  }

  Widget infoLine(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: Colors.blueGrey.shade500),
          const SizedBox(width: 5),
          Expanded(child: Text(toFa(text), style: TextStyle(color: Colors.blueGrey.shade700, height: 1.35))),
        ],
      ),
    );
  }

  void showGallery(List<String> images) {
    showDialog<void>(
      context: context,
      builder: (context) => Dialog.fullscreen(
        child: Stack(
          children: [
            PageView.builder(
              itemCount: images.length,
              itemBuilder: (context, index) => InteractiveViewer(
                child: Center(child: Image.network(api.imageUrl(images[index]), fit: BoxFit.contain)),
              ),
            ),
            Positioned(top: 12, right: 12, child: FilledButton.tonal(onPressed: () => Navigator.pop(context), child: const Text('بستن'))),
          ],
        ),
      ),
    );
  }

  void showReceipt(Shipment shipment) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('رسید تحویل مرسوله'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              receiptRow('شماره رهگیری', shipment.trackingCode),
              receiptRow('گیرنده', shipment.fullname),
              receiptRow('تلفن', shipment.phone),
              receiptRow('نوع', shipment.shipmentType),
              receiptRow('وضعیت', statusText[shipment.status] ?? shipment.status),
              receiptRow('تاریخ', shipment.shamsiDate),
              receiptRow('مشخصات تحویل', shipment.receiverInfo),
              receiptRow('ثبت‌کننده', shipment.createdBy),
            ],
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('بستن'))],
      ),
    );
  }

  Widget receiptRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Text('${toFa(label)}: ${toFa(value.isEmpty ? '-' : value)}'),
    );
  }

  Widget buildShipmentForm() {
    if (!has('shipment.create')) return noAccess();
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        appCard(
          title: editingShipmentId == null ? 'ثبت مرسوله جدید' : 'ویرایش مرسوله',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('عکس مرسوله', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: OutlinedButton.icon(onPressed: pickFromCamera, icon: const Icon(Icons.camera_alt_outlined), label: const Text('دوربین'))),
                  const SizedBox(width: 8),
                  Expanded(child: OutlinedButton.icon(onPressed: pickFromGallery, icon: const Icon(Icons.photo_library_outlined), label: const Text('گالری'))),
                ],
              ),
              if (selectedPhotos.isNotEmpty) ...[
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Expanded(child: Text('عکس‌های انتخاب‌شده', style: TextStyle(fontWeight: FontWeight.bold))),
                    TextButton(onPressed: () => setState(() => selectedPhotos.clear()), child: const Text('پاک کردن')),
                  ],
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: List.generate(selectedPhotos.length, (index) {
                    return Stack(
                      children: [
                        ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(selectedPhotos[index].bytes, width: 70, height: 70, fit: BoxFit.cover)),
                        Positioned(
                          top: -8,
                          left: -8,
                          child: IconButton.filledTonal(
                            visualDensity: VisualDensity.compact,
                            onPressed: () => setState(() => selectedPhotos.removeAt(index)),
                            icon: const Icon(Icons.close, size: 14),
                          ),
                        ),
                      ],
                    );
                  }),
                ),
              ],
              const SizedBox(height: 12),
              TextField(controller: fullnameController, decoration: const InputDecoration(labelText: 'نام و نام خانوادگی گیرنده')),
              const SizedBox(height: 10),
              TextField(controller: phoneController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره تلفن')),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: shipmentType,
                items: shipmentTypes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (v) => setState(() => shipmentType = v ?? shipmentTypes.first),
                decoration: const InputDecoration(labelText: 'نوع مرسوله'),
              ),
              const SizedBox(height: 10),
              const Text('تاریخ شمسی', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              jalaliRow(y: jy, m: jm, d: jd, onYear: (v) => setState(() => jy = v), onMonth: (v) => setState(() => jm = v), onDay: (v) => setState(() => jd = v)),
              const SizedBox(height: 10),
              TextField(controller: receiverController, minLines: 3, maxLines: 5, decoration: const InputDecoration(labelText: 'مشخصات تحویل گیرنده / آدرس / توضیحات')),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton(
                  onPressed: saving ? null : saveShipment,
                  child: saving ? const CircularProgressIndicator() : Text(editingShipmentId == null ? 'ذخیره آنلاین' : 'ذخیره ویرایش'),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(width: double.infinity, child: OutlinedButton(onPressed: resetForm, child: const Text('فرم جدید'))),
            ],
          ),
        ),
      ],
    );
  }

  Widget jalaliRow({required int y, required int m, required int d, required ValueChanged<int> onYear, required ValueChanged<int> onMonth, required ValueChanged<int> onDay}) {
    final years = [for (var year = 1404; year <= 1414; year++) year];
    return Row(
      children: [
        Expanded(
          child: DropdownButtonFormField<int>(
            value: y,
            items: years.map((e) => DropdownMenuItem(value: e, child: Text(toFa(e)))).toList(),
            onChanged: (v) => onYear(v ?? y),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          flex: 2,
          child: DropdownButtonFormField<int>(
            value: m,
            items: List.generate(12, (i) => DropdownMenuItem(value: i + 1, child: Text(persianMonths[i]))),
            onChanged: (v) => onMonth(v ?? m),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: DropdownButtonFormField<int>(
            value: d < 1 ? 1 : (d > 31 ? 31 : d),
            items: List.generate(31, (i) => DropdownMenuItem(value: i + 1, child: Text(toFa((i + 1).toString().padLeft(2, '0'))))),
            onChanged: (v) => onDay(v ?? d),
          ),
        ),
      ],
    );
  }

  Widget buildReport() {
    if (!has('report.view')) return noAccess();
    final rows = reportRows();
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        appCard(
          title: 'گزارش‌گیری',
          child: Column(
            children: [
              DropdownButtonFormField<int>(
                value: reportTypeIndex,
                items: const [
                  DropdownMenuItem(value: 0, child: Text('روزانه')),
                  DropdownMenuItem(value: 1, child: Text('ماهانه')),
                  DropdownMenuItem(value: 2, child: Text('همه')),
                ],
                onChanged: (v) => setState(() => reportTypeIndex = v ?? 0),
                decoration: const InputDecoration(labelText: 'نوع گزارش'),
              ),
              const SizedBox(height: 10),
              jalaliRow(y: ry, m: rm, d: rd, onYear: (v) => setState(() => ry = v), onMonth: (v) => setState(() => rm = v), onDay: (v) => setState(() => rd = v)),
              const SizedBox(height: 10),
              SizedBox(width: double.infinity, child: FilledButton.tonal(onPressed: () => setState(() {}), child: const Text('نمایش گزارش'))),
            ],
          ),
        ),
        appCard(title: 'خلاصه گزارش', child: Text('تعداد: ${toFa(rows.length)}')),
        ...rows.map((e) => shipmentCard(e, reportMode: true)),
      ],
    );
  }

  Widget buildUsers() {
    if (!has('user.view')) return noAccess();
    return RefreshIndicator(
      onRefresh: loadUsers,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          appCard(
            title: 'افزودن کاربر عادی',
            child: Column(
              children: [
                TextField(controller: newUserController, decoration: const InputDecoration(labelText: 'نام کاربری', hintText: 'مثلاً user1')),
                const SizedBox(height: 10),
                TextField(controller: newPassController, obscureText: true, decoration: const InputDecoration(labelText: 'رمز عبور جدید')),
                const SizedBox(height: 10),
                SwitchListTile(
                  value: newUserActive,
                  onChanged: (v) => setState(() => newUserActive = v),
                  title: const Text('فعال'),
                  contentPadding: EdgeInsets.zero,
                ),
                Row(
                  children: [
                    Expanded(child: FilledButton(onPressed: saveUser, child: const Text('ذخیره کاربر عادی'))),
                    const SizedBox(width: 8),
                    Expanded(child: OutlinedButton(onPressed: resetUserForm, child: const Text('فرم جدید'))),
                  ],
                ),
              ],
            ),
          ),
          appCard(
            title: 'لیست کاربران',
            child: Column(
              children: users.isEmpty
                  ? [const Text('کاربری یافت نشد.')]
                  : users.map((user) {
                      return ListTile(
                        title: Text(user.username),
                        subtitle: Text('${user.roleLabel} | ${user.isActive ? 'فعال' : 'غیرفعال'} | آخرین ورود: ${user.lastLoginAt}'),
                        leading: Icon(user.isActive ? Icons.check_circle_outline : Icons.block_outlined),
                        trailing: Wrap(
                          spacing: 4,
                          children: [
                            IconButton(onPressed: () => editUser(user), icon: const Icon(Icons.edit_outlined)),
                            if (user.username != 'admin') IconButton(onPressed: () => disableUser(user), icon: const Icon(Icons.delete_outline)),
                          ],
                        ),
                      );
                    }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildLogsPanel() {
    return Column(
      children: [
        appCard(
          title: 'لاگ کامل فعالیت‌ها',
          child: Column(
            children: [
              TextField(controller: logUserController, decoration: const InputDecoration(labelText: 'نام کاربری')),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: logAction,
                decoration: const InputDecoration(labelText: 'عملیات'),
                items: const [
                  DropdownMenuItem(value: '', child: Text('همه عملیات‌ها')),
                  DropdownMenuItem(value: 'login_success', child: Text('ورود موفق')),
                  DropdownMenuItem(value: 'login_failed', child: Text('ورود ناموفق')),
                  DropdownMenuItem(value: 'create', child: Text('ایجاد')),
                  DropdownMenuItem(value: 'update', child: Text('ویرایش')),
                  DropdownMenuItem(value: 'delete', child: Text('حذف')),
                  DropdownMenuItem(value: 'disable', child: Text('غیرفعال')),
                  DropdownMenuItem(value: 'status_change', child: Text('تغییر وضعیت')),
                ],
                onChanged: (v) => setState(() => logAction = v ?? ''),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: logEntity,
                decoration: const InputDecoration(labelText: 'بخش'),
                items: const [
                  DropdownMenuItem(value: '', child: Text('همه بخش‌ها')),
                  DropdownMenuItem(value: 'auth', child: Text('ورود')),
                  DropdownMenuItem(value: 'shipment', child: Text('مرسوله')),
                  DropdownMenuItem(value: 'user', child: Text('کاربر')),
                  DropdownMenuItem(value: 'database', child: Text('دیتابیس')),
                ],
                onChanged: (v) => setState(() => logEntity = v ?? ''),
              ),
              const SizedBox(height: 10),
              SizedBox(width: double.infinity, child: FilledButton.tonal(onPressed: loadLogs, child: const Text('نمایش لاگ‌ها'))),
            ],
          ),
        ),
        if (logs.isEmpty)
          appCard(title: 'نتیجه', child: const Text('لاگی یافت نشد.'))
        else
          ...logs.map((log) => Card(
                elevation: 0,
                margin: const EdgeInsets.symmetric(vertical: 6),
                child: ListTile(
                  title: Text('${log.createdAt} | ${log.username}'),
                  subtitle: Text('${log.action} | ${log.entity}\nIP: ${log.ip}\n${log.details}'),
                ),
              )),
      ],
    );
  }

  Widget noAccess() {
    return Center(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [Icon(Icons.lock_outline, size: 46), SizedBox(height: 10), Text('شما به این قسمت دسترسی ندارید')],
          ),
        ),
      ),
    );
  }
}
