<?php require_once __DIR__ . '/api/config.php'; require_once __DIR__ . '/api/auth.php'; sms_panel_require_permission_page('send'); ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ارسال پیام</title>
<style>
:root{--bg:#f4f7fb;--card:#fff;--text:#111827;--muted:#64748b;--line:#e2e8f0;--primary:#2563eb;--primary2:#1d4ed8;--ok:#16a34a;--bad:#dc2626;--warn:#d97706;--soft:#f8fafc;--shadow:0 14px 35px rgba(15,23,42,.07)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Tahoma,Arial,sans-serif;color:var(--text);direction:rtl}.app{max-width:720px;margin:auto;padding:14px 12px 30px}.header{position:sticky;top:0;z-index:10;background:rgba(244,247,251,.94);backdrop-filter:blur(10px);padding:10px 0 12px}.title{font-size:23px;font-weight:900;margin:8px 2px 14px}.tabs{display:grid;grid-template-columns:repeat(auto-fit,minmax(115px,1fr));gap:8px}.tab{display:flex;align-items:center;justify-content:center;min-height:44px;border:1px solid var(--line);border-radius:16px;background:#fff;color:#334155;text-decoration:none;font-size:13px;font-weight:800;box-shadow:0 6px 16px rgba(15,23,42,.04)}.tab.active{background:var(--primary);border-color:var(--primary);color:#fff}.tab.logout{background:#fff1f2;color:#be123c;border-color:#fecdd3}.card{background:var(--card);border:1px solid var(--line);border-radius:24px;padding:18px;margin:14px 0;box-shadow:var(--shadow)}label{display:block;font-size:14px;font-weight:800;margin:12px 2px 8px}textarea,select,input{width:100%;border:1px solid #d7dee9;border-radius:17px;background:#fff;padding:14px 15px;font-size:15px;color:var(--text);outline:none}textarea{min-height:120px;line-height:1.9;resize:vertical}textarea:focus,select:focus,input:focus{border-color:#93c5fd;box-shadow:0 0 0 4px #dbeafe}.row{display:grid;grid-template-columns:1fr 1fr;gap:10px}.meta{background:var(--soft);border:1px solid var(--line);border-radius:18px;padding:12px 13px;margin-top:12px;color:#475569;font-size:13px;line-height:1.9}.warn{color:var(--warn);font-weight:800}.btn{width:100%;border:0;border-radius:18px;padding:15px;margin-top:14px;background:var(--primary);color:#fff;font-size:16px;font-weight:900;cursor:pointer}.btn:active{transform:scale(.99)}.btn:hover{background:var(--primary2)}.notice{display:none;margin-top:14px;border-radius:18px;padding:13px 14px;font-size:14px;line-height:1.9}.notice.ok{display:block;background:#dcfce7;color:#166534;border:1px solid #bbf7d0}.notice.bad{display:block;background:#fee2e2;color:#991b1b;border:1px solid #fecaca}.notice.wait{display:block;background:#fef3c7;color:#92400e;border:1px solid #fde68a}.linkbtn{display:inline-block;margin-top:8px;color:#1d4ed8;font-weight:900;text-decoration:none}.small{font-size:12px;color:var(--muted);line-height:1.9;margin-top:8px}@media(max-width:540px){.app{padding:10px 10px 24px}.title{font-size:21px}.card{border-radius:22px;padding:15px}.row{grid-template-columns:1fr}.tab{font-size:12px;min-height:42px;padding:0 4px}}
.install-app{display:none;align-items:center;justify-content:center;width:100%;min-height:42px;border:1px solid #bfdbfe;border-radius:16px;background:#eff6ff;color:#1d4ed8;font-size:13px;font-weight:900;margin-top:8px;cursor:pointer}.install-app:hover{background:#dbeafe}</style>

<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="#2563eb">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="پنل پیامک">
<link rel="apple-touch-icon" href="icons/icon-192.png">
</head>
<body>
<div class="app">
  <div class="header">
    <div class="title">ارسال پیام</div>
    <?php sms_panel_nav('send'); ?>
    <button class="install-app" type="button" data-install-app>نصب پنل روی گوشی</button>
  </div>

  <section class="card">
    <label for="receiver-numbers">لیست شماره‌ها و نام مخاطبین</label>
    <textarea id="receiver-numbers" placeholder="هر مخاطب را در دو خط وارد کن:
09123456789
علی رضایی
09351234567
سارا محمدی"></textarea>
    <div class="small">خط اول شماره، خط دوم نام و نام خانوادگی همان شماره است. فقط شماره‌ها به API ارسال می‌شوند؛ نام‌ها فقط داخل پنل، جستجو و خروجی مخاطبین ذخیره می‌شوند.</div>

    <label for="group-title">عنوان گروه</label>
    <input id="group-title" placeholder="مثلاً بسته‌های امروز / مسیر ۱ / مشتریان کرد">
    <div class="small">اگر چند شماره را همزمان ارسال کنی، در صفحه جستجو داخل یک کادر گروهی نمایش داده می‌شوند. عنوان بالا اسم همان گروه است.</div>

    <div class="row">
      <div>
        <label for="sms-service">سرویس ارسال</label>
        <select id="sms-service">
          <option value="smsir" selected>SMS.ir</option>
          <option value="melli">ملی پیامک</option>
        </select>
      </div>
      <div>
        <label for="sender-number">شماره فرستنده</label>
        <select id="sender-number"></select>
      </div>
      <div>
        <label for="send-type-label">نوع ارسال</label>
        <input id="send-type-label" value="ارسال تکی" readonly>
      </div>
    </div>

    <label for="message-text">متن پیام</label>
    <textarea id="message-text" placeholder="متن پیام فارسی یا عددی"></textarea>

    <div class="meta" id="send-info">تعداد شماره معتبر: ۰</div>
    <div class="small warn">خط سالم SMS.ir روی پنل تنظیم شده است: 30002108020400</div>

    <button class="btn" id="send-btn" onclick="sendMessage()">ارسال پیام</button>
    <div id="notice" class="notice"></div>
  </section>
</div>

<script>
function getMessages(){try{return JSON.parse(localStorage.getItem('sms_messages')||'[]')}catch(e){return []}}
function saveMessages(m){localStorage.setItem('sms_messages',JSON.stringify(m))}
function makeId(){return 'sms_'+Date.now()+'_'+Math.random().toString(16).slice(2)}
function makeGroupId(){return 'grp_'+Date.now()+'_'+Math.random().toString(16).slice(2)}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function normalizeDigits(str){const fa='۰۱۲۳۴۵۶۷۸۹',ar='٠١٢٣٤٥٦٧٨٩';return String(str).replace(/[۰-۹]/g,d=>fa.indexOf(d)).replace(/[٠-٩]/g,d=>ar.indexOf(d))}
function normalizeNumber(n){let x=normalizeDigits(n).replace(/\s+/g,'').replace(/[^0-9+]/g,'');if(x.startsWith('+98'))x='0'+x.slice(3);if(x.startsWith('98')&&x.length===12)x='0'+x.slice(2);return x}
function isValidMobile(n){return /^09\d{9}$/.test(n)}
function isLikelyRecId(code, service='melli'){const x=String(code||'').trim(); if((service||'')==='ippanel') return /^[A-Za-z0-9_.:-]{6,}$/.test(x); return /^\d{6,}$/.test(x)}

const SENDER_NUMBERS = {
  melli: [
    {value:<?php echo json_encode(defined('MELI_DEFAULT_SENDER') ? MELI_DEFAULT_SENDER : '50002710080704'); ?>, label:<?php echo json_encode(defined('MELI_DEFAULT_SENDER') ? MELI_DEFAULT_SENDER : '50002710080704'); ?>}
  ],
  smsir: [
    {value:<?php echo json_encode(defined('SMSIR_DEFAULT_SENDER') ? SMSIR_DEFAULT_SENDER : '30002108020400'); ?>, label:<?php echo json_encode(defined('SMSIR_DEFAULT_SENDER') ? SMSIR_DEFAULT_SENDER : '30002108020400'); ?>}
  ]
};
function updateSenderOptions(){
  const service=(document.getElementById('sms-service')?.value||'melli');
  const select=document.getElementById('sender-number');
  const list=service==='smsir'?SENDER_NUMBERS.smsir:SENDER_NUMBERS.melli;
  const old=select.value;
  select.innerHTML=list.map((item,i)=>'<option value="'+escapeHtml(item.value)+'" '+(i===0?'selected':'')+'>'+escapeHtml(item.label)+'</option>').join('');
  if(list.some(item=>item.value===old)) select.value=old;
}

function splitFullName(fullName){
  const clean=String(fullName||'').trim().replace(/\s+/g,' ');
  if(!clean)return {firstName:'',lastName:'',fullName:''};
  const parts=clean.split(' ');
  return {firstName:parts[0]||'',lastName:parts.slice(1).join(' '),fullName:clean};
}
function getReceiverEntries(){
  const raw=document.getElementById('receiver-numbers').value||'';
  const lines=raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  const entries=[];
  const seen=new Set();
  for(let i=0;i<lines.length;i++){
    const phone=normalizeNumber(lines[i]);
    if(!isValidMobile(phone)) continue;
    let nameLine='';
    if(i+1<lines.length && !isValidMobile(normalizeNumber(lines[i+1]))){
      nameLine=lines[i+1].trim();
      i++;
    }
    if(seen.has(phone)) continue;
    seen.add(phone);
    const n=splitFullName(nameLine);
    entries.push({phone,firstName:n.firstName,lastName:n.lastName,fullName:n.fullName});
  }
  return entries;
}
function getReceivers(){return getReceiverEntries().map(e=>e.phone)}
function detectSendType(count,service){if(service==='smsir')return {type:'smsir_bulk',label:'SMS.ir / Bulk',note:'ارسال با وب‌سرویس SMS.ir انجام می‌شود و شناسه هر پیام برای دلیوری ذخیره می‌شود.'};return count<10?{type:'single',label:'ارسال تکی',note:'کمتر از ۱۰ شماره است؛ ارسال انبوه استفاده نمی‌شود.'}:{type:'single_batch',label:'ارسال تکی پشت‌سرهم',note:'برای گرفتن شناسه و دلیوری جداگانه، ارسال به‌صورت تکی پشت‌سرهم انجام می‌شود.'}}
function updateInfo(){const count=getReceivers().length;const service=(document.getElementById('sms-service')?.value||'melli');const d=detectSendType(count,service);document.getElementById('send-type-label').value=count?d.label:'ارسال تکی';document.getElementById('send-info').innerHTML='تعداد شماره معتبر: <b>'+count+'</b><br>'+escapeHtml(d.note)}
function showNotice(type,html){const n=document.getElementById('notice');n.className='notice '+type;n.innerHTML=html}
async function sendMessage(){
  const entries=getReceiverEntries();
  const receivers=entries.map(e=>e.phone);
  const contactMap={};
  entries.forEach(e=>{contactMap[e.phone]=e});
  const service=(document.getElementById('sms-service')?.value||'melli');
  const senderRaw=document.getElementById('sender-number').value.trim();
  const sender=normalizeDigits(senderRaw);
  const text=document.getElementById('message-text').value.trim();
  const groupInput=document.getElementById('group-title');
  const groupTitleRaw=(groupInput?.value||'').trim();
  const groupId=receivers.length>1?makeGroupId():'';
  const groupTitle=receivers.length>1?(groupTitleRaw||('گروه '+new Date().toLocaleString('fa-IR'))):(groupTitleRaw||'ارسال تکی');
  const btn=document.getElementById('send-btn');
  if(!receivers.length){showNotice('bad','شماره گیرنده معتبر وارد نشده است.');return}
  if(!sender){showNotice('bad','شماره فرستنده را انتخاب کن.');return}
  if(!text){showNotice('bad','متن پیام را وارد کن.');return}
  const detected=detectSendType(receivers.length,service);
  btn.disabled=true;btn.textContent='در حال ارسال...';showNotice('wait','در حال ارسال و ذخیره نتیجه‌ها...');
  try{
    const controller = new AbortController();
    const timer = setTimeout(()=>controller.abort(), 30000);
    let res, raw;
    try {
      res=await fetch('api/send.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:new URLSearchParams({service:service,receivers:receivers.join('\n'),sender:senderUsed,text:text}),signal:controller.signal});
      raw=await res.text();
    } finally { clearTimeout(timer); }
    let data;
    try{data=JSON.parse(raw)}catch(e){throw new Error('پاسخ سرور JSON نبود یا PHP خطا داده است. اگر SMS.ir را تست می‌کنی فایل api/smsir_last_response.log و error_log هاست را بررسی کن. پاسخ کوتاه: '+escapeHtml((raw||'').slice(0,180)))}
    if(!res.ok && data && data.message){throw new Error(data.message)}
    if(data.status==='config_error'){showNotice('bad',escapeHtml(data.message||'تنظیمات API ناقص است.'));return}
    if(data.status==='error' && !data.results){showNotice('bad',escapeHtml(data.message||'ارسال انجام نشد.'));return}
    let messages=getMessages();
    (data.results||[]).forEach(r=>{
      const serviceName = r.service || data.service || service;
      const senderUsed = normalizeDigits(data.sender_used || sender);
      const recId = r.rec_id || (isLikelyRecId(r.api_code, serviceName) ? String(r.api_code) : '');
      const ok = isLikelyRecId(recId, serviceName);
      const c=contactMap[r.receiver||'']||{};
      messages.push({id:makeId(),group_id:groupId,group_title:groupTitle,group_size:receivers.length,receiver:r.receiver||'',first_name:c.firstName||'',last_name:c.lastName||'',full_name:c.fullName||'',sender:senderUsed,text:text,date:new Date().toLocaleString('fa-IR'),created_at_iso:new Date().toISOString(),rec_id:ok?recId:'',send_ok:ok,send_status:ok?'ارسال اولیه موفق؛ شناسه دلیوری واقعی دریافت شد':(r.status_text||'ارسال ناموفق'),send_api_code:r.api_code||'',send_raw:r.raw_response||'',send_http_code:r.http_code||'',send_method:r.method||'',service:serviceName,delivery_code:'',delivery_text:ok?'در انتظار گزارش دلیوری':'شناسه دلیوری واقعی دریافت نشد',delivery_level:ok?'pending':'unknown',delivery_checked_at:'',send_type:r.send_type||data.send_type||detected.type,send_type_label:r.send_type_label||data.send_type_label||detected.label});
    });
    saveMessages(messages);
    document.getElementById('receiver-numbers').value='';document.getElementById('message-text').value='';if(groupInput)groupInput.value='';updateInfo();
    showNotice('ok','نتیجه ارسال ذخیره شد. وضعیت موفق/ناموفق را در صفحه جستجو ببین.'+(data.sender_corrected?'<br>شماره فرستنده با سرویس انتخاب‌شده اصلاح شد.':'')+'<br><a class="linkbtn" href="search.php">رفتن به جستجوی پیام‌ها</a>');
  }catch(err){const msg=(err.name==='AbortError')?'ارسال بیشتر از ۳۰ ثانیه طول کشید و متوقف شد. احتمالاً SMS.ir پاسخ نمی‌دهد یا تنظیمات وب‌سرویس اشتباه است.':err.message;showNotice('bad',escapeHtml(msg));}
  finally{btn.disabled=false;btn.textContent='ارسال پیام'}
}
window.addEventListener('load',()=>{document.getElementById('receiver-numbers').addEventListener('input',updateInfo);const svc=document.getElementById('sms-service');if(svc)svc.addEventListener('change',()=>{updateSenderOptions();updateInfo();});updateSenderOptions();updateInfo();if(location.protocol==='file:')showNotice('bad','برای ارسال باید پروژه روی هاست PHP یا لوکال‌سرور اجرا شود، نه مستقیم با file://')});
</script>

<script src="pwa.js"></script>
</body>
</html>
