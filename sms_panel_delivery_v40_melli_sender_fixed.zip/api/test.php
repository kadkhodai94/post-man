<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
sms_panel_require_permission_api('send');

echo json_encode([
    'php_version' => PHP_VERSION,
    'curl_enabled' => function_exists('curl_init'),
    'soap_enabled' => class_exists('SoapClient'),
    'melli_username_filled' => defined('MELI_USERNAME') && MELI_USERNAME !== '' && MELI_USERNAME !== 'نام_کاربری_پنل',
    'melli_api_key_filled' => defined('MELI_PASSWORD_OR_APIKEY') && MELI_PASSWORD_OR_APIKEY !== '' && MELI_PASSWORD_OR_APIKEY !== 'APIKey_جدید',
    'smsir_api_key_filled' => defined('SMSIR_API_KEY') && SMSIR_API_KEY !== '' && SMSIR_API_KEY !== 'SMSIR_API_KEY_اینجا' && SMSIR_API_KEY !== 'YOUR_SMSIR_API_KEY',
    'smsir_sender_filled' => defined('SMSIR_DEFAULT_SENDER') && preg_match('/^\d{5,}$/', (string)SMSIR_DEFAULT_SENDER),
    'smsir_api_base_url' => defined('SMSIR_API_BASE_URL') ? SMSIR_API_BASE_URL : '',
    'server_ip' => $_SERVER['SERVER_ADDR'] ?? '',
    'message' => 'برای SMS.ir باید curl_enabled و smsir_api_key_filled و smsir_sender_filled true باشند.'
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
