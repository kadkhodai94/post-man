<?php
/*
  تنظیمات پنل پیامک

  نکته امنیتی:
  این فایل شامل کلیدهای API است. آن را در اختیار افراد غیرمجاز قرار ندهید.
*/

/* ملی پیامک */
define('MELI_USERNAME', '9153480704');
define('MELI_PASSWORD_OR_APIKEY', '3b718e58-453f-4b8c-b251-45c28f2a2bae');
define('MELI_DEFAULT_SENDER', '50002710080704');
/* خطوط اختصاصی ملی پیامک - خط SMS.ir اینجا نباید استفاده شود */
define('MELI_SENDER_1', '50002710080704');

/* حالت خطایابی */
define('APP_DEBUG', true);

/* SMS.ir
   کلید API را از پنل SMS.ir بخش برنامه‌نویسان / API Key بردار و اینجا قرار بده.
   خط پیش‌فرض باید خط اختصاصی عددی پنل SMS.ir باشد.
*/
define('SMSIR_API_KEY', 'i0ecdjh1p4t1NqN5fgsDJbWrZ8m6hZMXTYEhKLZ9KGqb2zG6');
define('SMSIR_DEFAULT_SENDER', '30002108020400');
define('SMSIR_API_BASE_URL', 'https://api.sms.ir/v1');

/* خطوط اختصاصی SMS.ir شما */
define('SMSIR_SENDER_1', '30002108020400');
// خط 500031181890144 طبق پاسخ SMS.ir با کد 101 نامعتبر است و حذف شد.
// define('SMSIR_SENDER_2', '');
