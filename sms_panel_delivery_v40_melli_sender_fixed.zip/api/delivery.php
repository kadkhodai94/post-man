<?php
ini_set('display_errors', '0');
error_reporting(E_ALL);
ob_start();
header('Content-Type: application/json; charset=utf-8');
$__sms_panel_json_sent = false;
register_shutdown_function(function() use (&$__sms_panel_json_sent) {
    if ($__sms_panel_json_sent) return;
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        while (ob_get_level() > 0) @ob_end_clean();
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode([
            'status' => 'error',
            'message' => 'خطای داخلی PHP در فایل دلیوری. error_log هاست را بررسی کن.',
            'php_error' => basename($error['file']) . ':' . $error['line']
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
});

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
sms_panel_require_permission_api('search');

function respond_json($data, $httpCode = 200) {
    global $__sms_panel_json_sent;
    $__sms_panel_json_sent = true;
    while (ob_get_level() > 0) @ob_end_clean();
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function normalize_service($service) {
    $service = strtolower(trim((string)$service));
    if ($service === 'melipayamak') return 'melli';
    if (in_array($service, ['smsir', 'sms.ir', 'sms_ir', 'sms-ir'], true)) return 'smsir';
    return in_array($service, ['melli','smsir'], true) ? $service : 'melli';
}

function normalize_mobile($number) {
    $number = trim((string)$number);
    $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    $latin   = ['0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9'];
    $number = str_replace($persian, $latin, $number);
    $number = preg_replace('/[^0-9+]/', '', $number);
    if (strpos($number, '+98') === 0) $number = '0' . substr($number, 3);
    if (strpos($number, '0098') === 0) $number = '0' . substr($number, 4);
    if (strpos($number, '98') === 0 && strlen($number) === 12) $number = '0' . substr($number, 2);
    return $number;
}

function normalize_rec_id($value){return preg_replace('/\D+/', '', trim((string)$value));}

function parse_asmx_int_response($response){
    $clean=trim(strip_tags((string)$response));
    if(preg_match('/-?\d+/', $clean, $m)) return $m[0];
    return $clean;
}

function melli_delivery_text($code) {
    $map=[0=>'رسیده به گوشی',1=>'نرسیده به گوشی',2=>'رسیده به مخابرات',3=>'نرسیده به مخابرات',5=>'نامشخص / در صف بررسی',8=>'رسیده به مخابرات',16=>'نرسیده به مخابرات'];
    return $map[(int)$code] ?? ('کد دلیوری ملی پیامک: '.$code);
}
function melli_delivery_level($code){
    if((string)$code==='0')return 'delivered';
    if(in_array((string)$code,['1','3','16'],true))return 'failed';
    return 'pending';
}

function smsir_api_key_clean() {
    if (!defined('SMSIR_API_KEY')) return '';
    return trim((string)SMSIR_API_KEY);
}

function smsir_delivery_text($code) {
    if ($code === null || $code === '') return 'در انتظار گزارش دلیوری SMS.ir';
    $map = [
        1 => 'رسیده به گوشی',
        2 => 'نرسیده به گوشی',
        3 => 'پردازش در مخابرات؛ پیام از SMS.ir خارج شده و منتظر گزارش نهایی اپراتور است',
        4 => 'نرسیده به مخابرات',
        5 => 'رسیده به مخابرات؛ احتمالاً پیام ارسال شده ولی هنوز گزارش «رسیده به گوشی» ثبت نشده',
        6 => 'خطا',
        7 => 'لیست سیاه'
    ];
    return $map[(int)$code] ?? ('کد دلیوری SMS.ir: '.$code);
}
function smsir_delivery_level($code) {
    if ($code === null || $code === '') return 'pending';
    $c = (int)$code;
    if ($c === 1) return 'delivered';
    if (in_array($c, [2,4,6,7], true)) return 'failed';
    // کدهای 3 و 5 از سمت SMS.ir هنوز رسیدن قطعی به گوشی نیستند، ولی ارسال تا اپراتور پیش رفته است.
    return 'operator';
}
function shorten_debug($value, $limit = 5000) {
    if (is_string($value) && strlen($value) > $limit) {
        return substr($value, 0, $limit) . "\n...[truncated " . (strlen($value) - $limit) . " bytes]";
    }
    return $value;
}
function write_smsir_delivery_debug($entry) {
    if (defined('APP_DEBUG') && APP_DEBUG) {
        if (isset($entry['headers'])) {
            $entry['headers'] = array_map(function($h){ return preg_replace('/(x-api-key:)\s+.*/i', '$1 ***', $h); }, $entry['headers']);
        }
        if (isset($entry['response'])) $entry['response'] = shorten_debug((string)$entry['response']);
        @file_put_contents(__DIR__ . '/smsir_delivery_last_response.log', json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n\n", FILE_APPEND | LOCK_EX);
    }
}

function get_melli_delivery($recId) {
    if(!function_exists('curl_init')) return ['ok'=>false,'service'=>'melli','rec_id'=>$recId,'http_code'=>0,'delivery_code'=>null,'delivery_text'=>'افزونه cURL روی هاست فعال نیست','delivery_level'=>'unknown','raw_response'=>''];
    $ch=curl_init('https://api.payamak-panel.com/post/Send.asmx/GetDelivery');
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>http_build_query(['recId'=>$recId],'','&'),
        CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded; charset=utf-8'],
        CURLOPT_CONNECTTIMEOUT=>15,
        CURLOPT_TIMEOUT=>45,
        CURLOPT_SSL_VERIFYPEER=>true
    ]);
    $response=curl_exec($ch);
    $curlErr=curl_error($ch);
    $httpCode=curl_getinfo($ch,CURLINFO_HTTP_CODE);
    curl_close($ch);
    if($curlErr) return ['ok'=>false,'service'=>'melli','rec_id'=>$recId,'http_code'=>$httpCode,'delivery_code'=>null,'delivery_text'=>'خطای اتصال cURL: '.$curlErr,'delivery_level'=>'unknown','raw_response'=>$response ?: ''];
    $code=parse_asmx_int_response($response);
    $level=melli_delivery_level($code);
    return [
        'ok'=>($httpCode>=200 && $httpCode<300 && is_numeric($code)),
        'service'=>'melli',
        'rec_id'=>$recId,
        'http_code'=>$httpCode,
        'delivery_code'=>$code,
        'delivery_text'=>is_numeric($code)?melli_delivery_text($code):'پاسخ دلیوری قابل تشخیص نیست',
        'delivery_level'=>$level,
        'raw_response'=>APP_DEBUG?(string)$response:$code
    ];
}

function get_smsir_delivery($messageId) {
    if(!function_exists('curl_init')) return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>0,'delivery_code'=>null,'delivery_text'=>'افزونه cURL روی هاست فعال نیست','delivery_level'=>'unknown','raw_response'=>''];
    $apiKey = smsir_api_key_clean();
    if ($apiKey === '') return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>0,'delivery_code'=>null,'delivery_text'=>'API Key سامانه SMS.ir تنظیم نشده است','delivery_level'=>'unknown','raw_response'=>''];
    $base = defined('SMSIR_API_BASE_URL') ? rtrim(SMSIR_API_BASE_URL, '/') : 'https://api.sms.ir/v1';
    $url = $base . '/send/' . rawurlencode($messageId);
    $headers = ['Accept: application/json','X-API-KEY: '.$apiKey];
    $ch=curl_init($url);
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_HTTPHEADER=>$headers,
        CURLOPT_CONNECTTIMEOUT=>10,
        CURLOPT_TIMEOUT=>30,
        CURLOPT_SSL_VERIFYPEER=>true
    ]);
    $response=curl_exec($ch);
    $curlErr=curl_error($ch);
    $httpCode=curl_getinfo($ch,CURLINFO_HTTP_CODE);
    $contentType=curl_getinfo($ch,CURLINFO_CONTENT_TYPE);
    curl_close($ch);
    $json=json_decode((string)$response,true);
    write_smsir_delivery_debug(['time'=>date('c'),'url'=>$url,'headers'=>$headers,'http'=>$httpCode,'content_type'=>$contentType,'curl_error'=>$curlErr,'response'=>$response,'response_json'=>$json]);
    if($curlErr) return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>$httpCode,'delivery_code'=>null,'delivery_text'=>'خطای اتصال cURL به SMS.ir: '.$curlErr,'delivery_level'=>'unknown','raw_response'=>$response ?: ''];
    if(!is_array($json)) return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>$httpCode,'delivery_code'=>null,'delivery_text'=>'پاسخ دلیوری SMS.ir JSON نبود','delivery_level'=>'unknown','raw_response'=>APP_DEBUG?shorten_debug((string)$response):''];
    $status = $json['status'] ?? null;
    $message = isset($json['message']) ? (string)$json['message'] : '';
    $data = is_array($json['data'] ?? null) ? $json['data'] : [];
    if ((string)$status !== '1') {
        return ['ok'=>false,'service'=>'smsir','rec_id'=>$messageId,'http_code'=>$httpCode,'delivery_code'=>(string)($status ?? ''),'delivery_text'=>$message ?: 'خطا در دریافت دلیوری SMS.ir','delivery_level'=>'unknown','raw_response'=>APP_DEBUG?shorten_debug((string)$response):''];
    }
    $code = array_key_exists('deliveryState', $data) ? $data['deliveryState'] : null;
    return [
        'ok'=>true,
        'service'=>'smsir',
        'rec_id'=>$messageId,
        'http_code'=>$httpCode,
        'delivery_code'=>($code === null ? '' : (string)$code),
        'delivery_text'=>smsir_delivery_text($code),
        'delivery_level'=>smsir_delivery_level($code),
        'raw_response'=>APP_DEBUG?shorten_debug((string)$response):($code === null ? '' : (string)$code)
    ];
}

$service=normalize_service($_POST['service'] ?? $_POST['provider'] ?? 'melli');
$receiver=normalize_mobile($_POST['receiver'] ?? '');

$recId=normalize_rec_id($_POST['rec_id'] ?? $_POST['recId'] ?? '');
if(!$recId) respond_json(['status'=>'error','message'=>'شناسه پیام / recId ارسال نشده است.']);

if(!preg_match('/^\d{6,}$/',$recId)) {
    respond_json(['status'=>'done','result'=>[
        'ok'=>false,
        'service'=>$service,
        'rec_id'=>$recId,
        'http_code'=>0,
        'delivery_code'=>'',
        'delivery_text'=>'شناسه دلیوری واقعی نیست؛ این مقدار کد پاسخ API است',
        'delivery_level'=>'unknown',
        'raw_response'=>''
    ]]);
}

if($service==='smsir') respond_json(['status'=>'done','result'=>get_smsir_delivery($recId)]);
respond_json(['status'=>'done','result'=>get_melli_delivery($recId)]);
