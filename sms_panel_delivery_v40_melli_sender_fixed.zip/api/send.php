<?php
ini_set('display_errors', '0');
error_reporting(E_ALL);
ob_start();
header('Content-Type: application/json; charset=utf-8');
$__sms_panel_json_sent = false;
register_shutdown_function(function() use (&$__sms_panel_json_sent) {
    if ($__sms_panel_json_sent) return;
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        while (ob_get_level() > 0) @ob_end_clean();
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode([
            'status' => 'error',
            'message' => 'خطای داخلی PHP در فایل ارسال. error_log هاست را بررسی کن.',
            'php_error' => basename($error['file']) . ':' . $error['line']
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
});

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
sms_panel_require_permission_api('send');

function respond_json($data, $httpCode = 200) {
    global $__sms_panel_json_sent;
    $__sms_panel_json_sent = true;
    while (ob_get_level() > 0) @ob_end_clean();
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function normalize_mobile($number) {
    $number = trim((string)$number);
    $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    $latin   = ['0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9'];
    $number = str_replace($persian, $latin, $number);
    $number = preg_replace('/[^0-9+]/', '', $number);
    if (strpos($number, '+98') === 0) $number = '0' . substr($number, 3);
    if (strpos($number, '0098') === 0) $number = '0' . substr($number, 4);
    if (strpos($number, '98') === 0 && strlen($number) === 12) $number = '0' . substr($number, 2);
    return $number;
}

function normalize_line_number($sender) {
    $sender = trim((string)$sender);
    $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    $latin   = ['0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9'];
    $sender = str_replace($persian, $latin, $sender);
    return preg_replace('/\D+/', '', $sender);
}

function normalize_service($service) {
    $service = strtolower(trim((string)$service));
    if ($service === 'melipayamak') return 'melli';
    if (in_array($service, ['smsir', 'sms.ir', 'sms_ir', 'sms-ir'], true)) return 'smsir';
    return in_array($service, ['melli','smsir'], true) ? $service : 'melli';
}

function is_melli_config_placeholder() {
    return !defined('MELI_USERNAME') || !defined('MELI_PASSWORD_OR_APIKEY')
        || MELI_USERNAME === '' || MELI_PASSWORD_OR_APIKEY === ''
        || MELI_USERNAME === 'نام_کاربری_پنل'
        || MELI_PASSWORD_OR_APIKEY === 'APIKey_جدید';
}

function smsir_api_key_clean() {
    if (!defined('SMSIR_API_KEY')) return '';
    $key = trim((string)SMSIR_API_KEY);
    return trim($key);
}

function is_smsir_config_placeholder() {
    $key = smsir_api_key_clean();
    return $key === '' || $key === 'SMSIR_API_KEY_اینجا' || $key === 'YOUR_SMSIR_API_KEY' || $key === 'کلید_اینجا';
}

function configured_sender_lines($service) {
    $service = normalize_service($service);
    $lines = [];
    if ($service === 'smsir') {
        foreach (['SMSIR_DEFAULT_SENDER','SMSIR_SENDER_1','SMSIR_SENDER_2','SMSIR_SENDER_3','SMSIR_SENDER_4'] as $c) {
            if (defined($c) && trim((string)constant($c)) !== '') $lines[] = normalize_line_number(constant($c));
        }
    } else {
        foreach (['MELI_DEFAULT_SENDER','MELI_SENDER_1','MELI_SENDER_2','MELI_SENDER_3','MELI_SENDER_4'] as $c) {
            if (defined($c) && trim((string)constant($c)) !== '') $lines[] = normalize_line_number(constant($c));
        }
    }
    $lines = array_values(array_unique(array_filter($lines)));
    return $lines;
}

function pick_sender_for_service($service, $postedSender) {
    $service = normalize_service($service);
    $requested = normalize_line_number($postedSender);
    $allowed = configured_sender_lines($service);
    $default = $allowed[0] ?? '';
    if ($requested !== '' && in_array($requested, $allowed, true)) {
        return ['sender'=>$requested, 'requested_sender'=>$requested, 'corrected'=>false, 'allowed'=>$allowed];
    }
    return ['sender'=>$default, 'requested_sender'=>$requested, 'corrected'=>($requested !== '' && $requested !== $default), 'allowed'=>$allowed];
}


function status_message($code) {
    $map = [
        '-110' => 'الزام استفاده از APIKey به جای رمز عبور',
        '-109' => 'IP مجاز برای استفاده از API تنظیم نشده است',
        '-108' => 'IP به دلیل تلاش ناموفق استفاده از API مسدود شده است',
        '0' => 'نام کاربری یا رمز/APIKey اشتباه است',
        '1' => 'درخواست با موفقیت انجام شد',
        '2' => 'اعتبار کافی نیست',
        '3' => 'محدودیت در ارسال روزانه',
        '4' => 'محدودیت در حجم ارسال',
        '5' => 'شماره فرستنده معتبر نیست',
        '6' => 'سامانه در حال به‌روزرسانی است',
        '7' => 'متن حاوی کلمه فیلتر شده است',
        '9' => 'ارسال از خطوط عمومی از طریق وب‌سرویس امکان‌پذیر نیست',
        '10' => 'کاربر فعال نیست',
        '11' => 'ارسال نشده',
        '12' => 'مدارک کاربر کامل نیست',
        '14' => 'متن حاوی لینک است',
        '15' => 'لغو 11 در انتهای متن پیامک وجود ندارد',
        '16' => 'شماره گیرنده‌ای یافت نشد',
        '17' => 'متن پیامک خالی است',
        '18' => 'شماره گیرنده نامعتبر است',
    ];
    $key = (string)$code;
    return $map[$key] ?? 'پاسخ عددی API: ' . $key;
}

function smsir_status_message($code) {
    $map = [
        '1' => 'عملیات با موفقیت انجام شد',
        '0' => 'مشکلی در سامانه رخ داده است؛ با پشتیبانی SMS.ir در تماس باشید',
        '10' => 'کلید وب‌سرویس نامعتبر است',
        '11' => 'کلید وب‌سرویس غیرفعال است',
        '12' => 'کلید وب‌سرویس محدود به IP‌های تعریف شده است',
        '13' => 'حساب کاربری غیرفعال است',
        '14' => 'حساب کاربری در حالت تعلیق قرار دارد',
        '20' => 'تعداد درخواست بیشتر از حد مجاز است',
        '101' => 'شماره خط نامعتبر است',
        '102' => 'اعتبار کافی نیست',
        '103' => 'متن پیام خالی است',
        '104' => 'شماره موبایل نادرست است',
        '105' => 'تعداد موبایل‌ها بیشتر از حد مجاز است',
        '107' => 'لیست موبایل‌ها خالی است',
        '115' => 'شماره موبایل در لیست سیاه سامانه است',
        '117' => 'متن ارسال‌شده مورد تایید نیست',
        '123' => 'خط ارسال‌کننده نیاز به فعال‌سازی دارد',
    ];
    $key = (string)$code;
    return $map[$key] ?? ('کد وضعیت SMS.ir: ' . $key);
}

function parse_asmx_response($response) {
    $clean = trim(strip_tags((string)$response));
    if (preg_match('/-?\d+/', $clean, $m)) return $m[0];
    return $clean;
}

function detect_send_type($count, $service) {
    if ($service === 'smsir') {
        return [
            'send_type' => 'smsir_bulk',
            'send_type_label' => 'SMS.ir / Bulk',
            'send_type_note' => 'ارسال با وب‌سرویس SMS.ir انجام می‌شود و شناسه هر پیام برای دلیوری ذخیره می‌شود.'
        ];
    }
    if ($count < 10) {
        return [
            'send_type' => 'single',
            'send_type_label' => 'ارسال تکی',
            'send_type_note' => 'تعداد شماره‌ها کمتر از ۱۰ است؛ ارسال انبوه استفاده نمی‌شود و پیام‌ها با متد تکی ارسال می‌شوند.'
        ];
    }
    return [
        'send_type' => 'single_batch',
        'send_type_label' => 'ارسال چندتایی امن / تکی پشت‌سرهم',
        'send_type_note' => 'برای داشتن شناسه جداگانه و دلیوری دقیق، حتی برای ۱۰ شماره یا بیشتر هم ارسال به‌صورت تکی پشت‌سرهم انجام می‌شود.'
    ];
}

function shorten_debug($value, $limit = 5000) {
    if (is_string($value) && strlen($value) > $limit) {
        return substr($value, 0, $limit) . "\n...[truncated " . (strlen($value) - $limit) . " bytes]";
    }
    return $value;
}

function write_smsir_debug($entry) {
    if (defined('APP_DEBUG') && APP_DEBUG) {
        if (isset($entry['headers'])) {
            $entry['headers'] = array_map(function($h){ return preg_replace('/(x-api-key:)\s+.*/i', '$1 ***', $h); }, $entry['headers']);
        }
        if (isset($entry['response'])) $entry['response'] = shorten_debug((string)$entry['response']);
        @file_put_contents(__DIR__ . '/smsir_last_response.log', json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n\n", FILE_APPEND | LOCK_EX);
    }
}

function send_melli_sms($username, $password, $to, $from, $text) {
    if (!function_exists('curl_init')) return ['ok'=>false,'method'=>'curl SendSimpleSMS2','http_code'=>0,'api_code'=>null,'rec_id'=>'','status_text'=>'افزونه cURL روی هاست فعال نیست','raw_response'=>''];
    $url = 'https://api.payamak-panel.com/post/Send.asmx/SendSimpleSMS2';
    $fields = http_build_query(['username'=>$username,'password'=>$password,'to'=>$to,'from'=>$from,'text'=>$text,'isflash'=>'false'], '', '&');
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>$fields,
        CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded; charset=utf-8'],
        CURLOPT_CONNECTTIMEOUT=>15,
        CURLOPT_TIMEOUT=>45,
        CURLOPT_SSL_VERIFYPEER=>true
    ]);
    $response = curl_exec($ch);
    $curlErr = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($curlErr) return ['ok'=>false,'method'=>'curl SendSimpleSMS2','http_code'=>$httpCode,'api_code'=>null,'rec_id'=>'','status_text'=>'خطای اتصال cURL: '.$curlErr,'raw_response'=>$response ?: ''];
    $apiCode = parse_asmx_response($response);
    $numeric = is_numeric($apiCode) ? (int)$apiCode : null;
    $isRealRecId = ($numeric !== null && preg_match('/^\d{6,}$/', (string)$apiCode));
    return [
        'ok'=>($httpCode>=200 && $httpCode<300 && $isRealRecId),
        'method'=>'ملی پیامک / SendSimpleSMS2',
        'service'=>'melli',
        'http_code'=>$httpCode,
        'api_code'=>$apiCode,
        'rec_id'=>$isRealRecId ? (string)$apiCode : '',
        'status_text'=>$isRealRecId ? 'ارسال اولیه موفق؛ شناسه دلیوری واقعی دریافت شد' : ($numeric !== null ? status_message($numeric) : 'پاسخ API قابل تشخیص نیست'),
        'raw_response'=>APP_DEBUG ? (string)$response : $apiCode
    ];
}

function send_smsir_bulk($receivers, $from, $text) {
    $results = [];
    if (!function_exists('curl_init')) {
        foreach ($receivers as $r) $results[] = ['receiver'=>$r,'ok'=>false,'method'=>'SMS.ir / Bulk','service'=>'smsir','http_code'=>0,'api_code'=>'','rec_id'=>'','status_text'=>'افزونه cURL روی هاست فعال نیست','raw_response'=>''];
        return $results;
    }
    $apiKey = smsir_api_key_clean();
    if ($apiKey === '') {
        foreach ($receivers as $r) $results[] = ['receiver'=>$r,'ok'=>false,'method'=>'SMS.ir / Bulk','service'=>'smsir','http_code'=>0,'api_code'=>'','rec_id'=>'','status_text'=>'API Key سامانه SMS.ir تنظیم نشده است','raw_response'=>''];
        return $results;
    }
    $base = defined('SMSIR_API_BASE_URL') ? rtrim(SMSIR_API_BASE_URL, '/') : 'https://api.sms.ir/v1';
    $url = $base . '/send/bulk';
    $payload = [
        'lineNumber' => (int)normalize_line_number($from),
        'messageText' => $text,
        'mobiles' => array_values($receivers)
    ];
    $headers = [
        'Content-Type: application/json; charset=utf-8',
        'Accept: application/json',
        'X-API-KEY: ' . $apiKey
    ];
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER=>$headers,
        CURLOPT_CONNECTTIMEOUT=>10,
        CURLOPT_TIMEOUT=>45,
        CURLOPT_SSL_VERIFYPEER=>true
    ]);
    $response = curl_exec($ch);
    $curlErr = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);
    $json = json_decode((string)$response, true);
    write_smsir_debug(['time'=>date('c'),'url'=>$url,'headers'=>$headers,'http'=>$httpCode,'content_type'=>$contentType,'curl_error'=>$curlErr,'payload'=>$payload,'response'=>$response,'response_json'=>$json]);

    if ($curlErr) {
        foreach ($receivers as $r) $results[] = ['receiver'=>$r,'ok'=>false,'method'=>'SMS.ir / Bulk','service'=>'smsir','http_code'=>$httpCode,'api_code'=>'','rec_id'=>'','status_text'=>'خطای اتصال cURL به SMS.ir: '.$curlErr,'raw_response'=>$response ?: ''];
        return $results;
    }
    if (!is_array($json)) {
        foreach ($receivers as $r) $results[] = ['receiver'=>$r,'ok'=>false,'method'=>'SMS.ir / Bulk','service'=>'smsir','http_code'=>$httpCode,'api_code'=>'','rec_id'=>'','status_text'=>'پاسخ SMS.ir JSON نبود','raw_response'=>APP_DEBUG?shorten_debug((string)$response):''];
        return $results;
    }
    $status = $json['status'] ?? null;
    $message = isset($json['message']) ? (string)$json['message'] : smsir_status_message($status);
    $data = is_array($json['data'] ?? null) ? $json['data'] : [];
    $messageIds = is_array($data['messageIds'] ?? null) ? $data['messageIds'] : [];
    $packId = $data['packId'] ?? '';
    for ($i=0; $i<count($receivers); $i++) {
        $id = $messageIds[$i] ?? null;
        $ok = ($httpCode >= 200 && $httpCode < 300 && (string)$status === '1' && is_scalar($id) && preg_match('/^\d{6,}$/', (string)$id) && (int)$id > 0);
        if ($ok) {
            $statusText = 'ارسال اولیه موفق؛ شناسه دلیوری SMS.ir دریافت شد';
        } elseif ($id === 0 || $id === '0') {
            $statusText = 'ارسال نشد: شماره در لیست سیاه SMS.ir است';
        } elseif ($id === null && (string)$status === '1') {
            $statusText = 'ارسال نشد: شماره نامعتبر است یا متن بیش از حد مجاز است';
        } else {
            $statusText = $message ?: smsir_status_message($status);
        }
        $results[] = [
            'receiver'=>$receivers[$i],
            'ok'=>$ok,
            'method'=>'SMS.ir / send/bulk',
            'service'=>'smsir',
            'http_code'=>$httpCode,
            'api_code'=>$id !== null ? (string)$id : (string)($status ?? ''),
            'rec_id'=>$ok ? (string)$id : '',
            'pack_id'=>(string)$packId,
            'status_text'=>$statusText,
            'raw_response'=>APP_DEBUG ? shorten_debug((string)$response) : ($ok ? (string)$id : $statusText)
        ];
    }
    return $results;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond_json(['status'=>'error','message'=>'این آدرس فقط درخواست POST قبول می‌کند.'], 405);

$service = normalize_service($_POST['service'] ?? $_POST['provider'] ?? 'melli');

if ($service === 'smsir' && is_smsir_config_placeholder()) respond_json(['status'=>'config_error','message'=>'API Key سامانه SMS.ir داخل api/config.php تنظیم نشده است.']);
if ($service === 'melli' && is_melli_config_placeholder()) respond_json(['status'=>'config_error','message'=>'فایل api/config.php هنوز با نام کاربری و APIKey واقعی ملی پیامک تکمیل نشده است.']);

$senderPick = pick_sender_for_service($service, $_POST['sender'] ?? '');
$sender = $senderPick['sender'];
$senderCorrected = $senderPick['corrected'];
$requestedSender = $senderPick['requested_sender'];

$receiversRaw = trim($_POST['receivers'] ?? '');
$text = trim($_POST['text'] ?? '');

if (!$sender || !$receiversRaw || !$text) respond_json(['status'=>'error','message'=>'شماره فرستنده، گیرنده یا متن پیام خالی است.']);

$receivers = preg_split('/[\s,،]+/u', $receiversRaw, -1, PREG_SPLIT_NO_EMPTY);
$receivers = array_values(array_unique(array_map('normalize_mobile', $receivers)));
$receivers = array_values(array_filter($receivers, function($n){ return preg_match('/^09\d{9}$/', $n); }));

if (!$receivers) respond_json(['status'=>'error','message'=>'شماره گیرنده معتبر نیست. فرمت درست مثل 09123456789 است.']);
if (count($receivers) > 100) respond_json(['status'=>'error','message'=>'در هر ارسال حداکثر ۱۰۰ شماره مجاز است.']);

$sendType = detect_send_type(count($receivers), $service);
$results = [];

if ($service === 'smsir') {
    $results = send_smsir_bulk($receivers, $sender, $text);
} else {
    foreach ($receivers as $receiver) $results[] = send_melli_sms(MELI_USERNAME, MELI_PASSWORD_OR_APIKEY, $receiver, $sender, $text) + ['receiver'=>$receiver];
}

foreach ($results as &$r) {
    $r['send_type'] = $sendType['send_type'];
    $r['send_type_label'] = $sendType['send_type_label'];
    $r['send_type_note'] = $sendType['send_type_note'];
    $r['service'] = $service;
}
unset($r);

$successCount = count(array_filter($results, function($r){ return !empty($r['ok']); }));

respond_json([
    'status'=>'done',
    'service'=>$service,
    'send_type'=>$sendType['send_type'],
    'send_type_label'=>$sendType['send_type_label'],
    'send_type_note'=>$sendType['send_type_note'],
    'bulk_not_used_for_under_10'=>($service==='melli' && count($receivers)<10),
    'success_count'=>$successCount,
    'failed_count'=>count($results)-$successCount,
    'count'=>count($results),
    'sender_used'=>$sender,
    'requested_sender'=>$requestedSender,
    'sender_corrected'=>$senderCorrected,
    'sender_note'=>$senderCorrected ? 'شماره فرستنده با سرویس انتخاب‌شده هماهنگ نبود و به خط همان سرویس اصلاح شد.' : '',
    'results'=>$results
]);
