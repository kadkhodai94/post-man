<?php
require_once __DIR__ . '/auth_config.php';

function sms_panel_start_session() {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(PANEL_SESSION_NAME);
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        // سازگار با همه نسخه‌های PHP هاست؛ فرم آرایه‌ای روی بعضی هاست‌ها Notice می‌دهد.
        session_set_cookie_params(0, '/', '', $secure, true);
        session_start();
    }
}

function sms_panel_users() {
    global $SMS_PANEL_USERS;
    return is_array($SMS_PANEL_USERS ?? null) ? $SMS_PANEL_USERS : [];
}

function sms_panel_get_user($username) {
    $users = sms_panel_users();
    return $users[$username] ?? null;
}

function sms_panel_attempt_login($username, $password) {
    sms_panel_start_session();
    $username = trim((string)$username);
    $user = sms_panel_get_user($username);
    if (!$user || empty($user['password_hash']) || !password_verify((string)$password, $user['password_hash'])) {
        return false;
    }
    session_regenerate_id(true);
    $_SESSION['sms_panel_logged_in'] = true;
    $_SESSION['sms_panel_username'] = $username;
    $_SESSION['sms_panel_role'] = $user['role'] ?? 'user';
    $_SESSION['sms_panel_permissions'] = $user['permissions'] ?? [];
    $_SESSION['sms_panel_login_time'] = time();
    return true;
}

function sms_panel_is_logged_in() {
    sms_panel_start_session();
    return !empty($_SESSION['sms_panel_logged_in']) && $_SESSION['sms_panel_logged_in'] === true;
}

function sms_panel_current_username() {
    sms_panel_start_session();
    return $_SESSION['sms_panel_username'] ?? '';
}

function sms_panel_current_role() {
    sms_panel_start_session();
    return $_SESSION['sms_panel_role'] ?? '';
}

function sms_panel_has_permission($permission) {
    sms_panel_start_session();
    if (!sms_panel_is_logged_in()) return false;
    if (sms_panel_current_role() === 'admin') return true;
    $permissions = $_SESSION['sms_panel_permissions'] ?? [];
    return in_array($permission, $permissions, true);
}

function sms_panel_require_login_page() {
    if (!sms_panel_is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function sms_panel_require_permission_page($permission) {
    sms_panel_require_login_page();
    if (!sms_panel_has_permission($permission)) {
        http_response_code(403);
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>دسترسی غیرمجاز</title><style>body{font-family:Tahoma,Arial,sans-serif;background:#f4f7fb;color:#111827;direction:rtl;margin:0;padding:24px}.box{max-width:520px;margin:80px auto;background:#fff;border:1px solid #e2e8f0;border-radius:24px;padding:24px;box-shadow:0 14px 35px rgba(15,23,42,.07)}a{display:inline-block;margin-top:12px;color:#2563eb;font-weight:900;text-decoration:none}</style></head><body><div class="box"><h2>دسترسی غیرمجاز</h2><p>حساب کاربری شما به این بخش دسترسی ندارد.</p><a href="index.php">بازگشت به پنل</a></div></body></html>';
        exit;
    }
}

function sms_panel_require_login_api() {
    if (!sms_panel_is_logged_in()) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status' => 'auth_error',
            'message' => 'برای استفاده از پنل ابتدا وارد شوید.'
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

function sms_panel_require_permission_api($permission) {
    sms_panel_require_login_api();
    if (!sms_panel_has_permission($permission)) {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status' => 'permission_error',
            'message' => 'حساب کاربری شما به این بخش دسترسی ندارد.'
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

function sms_panel_nav($active) {
    $items = [];
    if (sms_panel_has_permission('send')) {
        $items[] = ['index.php', 'ارسال پیام', 'send'];
    }
    if (sms_panel_has_permission('search')) {
        $items[] = ['search.php', 'جستجوی پیام‌ها', 'search'];
    }
    if (sms_panel_has_permission('extract')) {
        $items[] = ['extract.php', 'استخراج شماره‌ها', 'extract'];
    }
    $items[] = ['logout.php', 'خروج', 'logout'];

    echo '<nav class="tabs tabs-count-' . count($items) . '">';
    foreach ($items as $item) {
        [$href, $label, $key] = $item;
        $class = 'tab';
        if ($active === $key) $class .= ' active';
        if ($key === 'logout') $class .= ' logout';
        echo '<a class="' . htmlspecialchars($class, ENT_QUOTES, 'UTF-8') . '" href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</a>';
    }
    echo '</nav>';
}
