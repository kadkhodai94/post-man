<?php
/*
  تنظیمات ورود و سطح دسترسی پنل

  کاربران پیش‌فرض:
  admin / admin123  => دسترسی کامل
  user  / user1234  => فقط ارسال پیام و جستجوی پیام‌ها

  برای ساخت هش رمز جدید:
  php -r "echo password_hash('رمز_جدید', PASSWORD_DEFAULT);"
*/

$SMS_PANEL_USERS = [
    'admin' => [
        'password_hash' => '$2y$12$xuXbmXGoSu/i7MDUrD3x9O.asqaKKG6yLHLK6.jTQuzgGpw/v7ZCG',
        'role' => 'admin',
        'permissions' => ['send', 'search', 'extract']
    ],
    'user' => [
        'password_hash' => '$2y$12$nK0wO7D6i0nkCCR2.rOBXuGGaZRuNx0o6L.q4seB0NdBnTZjqUOPm',
        'role' => 'user',
        'permissions' => ['send', 'search']
    ],
];

define('PANEL_SESSION_NAME', 'sms_panel_session');
