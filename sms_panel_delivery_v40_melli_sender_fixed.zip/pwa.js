(function(){
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function(){
      navigator.serviceWorker.register('sw.js').catch(function(){});
    });
  }

  var deferredPrompt = null;
  var installButtons = [];

  function updateButtons(show){
    installButtons = Array.prototype.slice.call(document.querySelectorAll('[data-install-app]'));
    installButtons.forEach(function(btn){
      btn.style.display = show ? 'inline-flex' : 'none';
    });
  }

  window.addEventListener('beforeinstallprompt', function(e){
    e.preventDefault();
    deferredPrompt = e;
    updateButtons(true);
  });

  window.addEventListener('appinstalled', function(){
    deferredPrompt = null;
    updateButtons(false);
  });

  document.addEventListener('click', async function(e){
    var btn = e.target.closest('[data-install-app]');
    if (!btn) return;
    if (!deferredPrompt) {
      alert('اگر دکمه نصب نمایش داده نشد، از منوی مرورگر گزینه Add to Home screen یا Install app را بزنید.');
      return;
    }
    deferredPrompt.prompt();
    await deferredPrompt.userChoice.catch(function(){});
    deferredPrompt = null;
    updateButtons(false);
  });

  document.addEventListener('DOMContentLoaded', function(){
    updateButtons(false);
  });
})();
