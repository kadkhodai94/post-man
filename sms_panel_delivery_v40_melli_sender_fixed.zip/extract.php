<?php require_once __DIR__ . '/api/auth.php'; sms_panel_require_permission_page('extract'); ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>استخراج شماره‌ها</title>
<style>
:root{--bg:#f4f7fb;--card:#fff;--text:#111827;--muted:#64748b;--line:#e2e8f0;--primary:#2563eb;--primary2:#1d4ed8;--dark:#334155;--soft:#f8fafc;--shadow:0 14px 35px rgba(15,23,42,.07)}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Tahoma,Arial,sans-serif;color:var(--text);direction:rtl}.app{max-width:760px;margin:auto;padding:14px 12px 30px}.header{position:sticky;top:0;z-index:10;background:rgba(244,247,251,.94);backdrop-filter:blur(10px);padding:10px 0 12px}.title{font-size:23px;font-weight:900;margin:8px 2px 14px}.tabs{display:grid;grid-template-columns:repeat(auto-fit,minmax(115px,1fr));gap:8px}.tab{display:flex;align-items:center;justify-content:center;min-height:44px;border:1px solid var(--line);border-radius:16px;background:#fff;color:#334155;text-decoration:none;font-size:13px;font-weight:800;box-shadow:0 6px 16px rgba(15,23,42,.04)}.tab.active{background:var(--primary);border-color:var(--primary);color:#fff}.tab.logout{background:#fff1f2;color:#be123c;border-color:#fecdd3}.card{background:#fff;border:1px solid var(--line);border-radius:24px;padding:16px;margin:14px 0;box-shadow:var(--shadow)}.stats{display:grid;grid-template-columns:1fr 1fr;gap:10px}.stat{background:var(--soft);border:1px solid var(--line);border-radius:18px;padding:13px;color:#475569}.stat b{display:block;font-size:25px;color:var(--primary);margin-top:5px}.actions{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}.btn{border:0;border-radius:17px;padding:13px 14px;background:var(--primary);color:#fff;font-size:14px;font-weight:900;cursor:pointer}.btn:hover{background:var(--primary2)}.btn.ghost{background:#eef2ff;color:#1e3a8a}.btn.dark{background:var(--dark)}.hint{font-size:12px;color:var(--muted);line-height:1.9;margin-top:10px}.list{display:flex;flex-direction:column;gap:8px;max-height:460px;overflow:auto}.item{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:center;border:1px solid var(--line);border-radius:16px;background:#fff;padding:11px 12px}.num{font-weight:900;font-size:16px;direction:ltr;text-align:right}.name{font-size:13px;font-weight:900;color:#1e293b;margin-top:4px}.mini{display:flex;gap:6px}.mini a,.mini button{border:0;border-radius:12px;padding:8px 10px;background:#eef2ff;color:#1e3a8a;text-decoration:none;font-weight:800;font-size:12px}.empty{text-align:center;color:var(--muted);border:1px dashed #cbd5e1;border-radius:18px;background:#fff;padding:18px}textarea{width:100%;min-height:150px;border:1px solid var(--line);border-radius:16px;padding:12px;font-size:14px;line-height:1.8;direction:ltr;text-align:left}@media(max-width:540px){.app{padding:10px 10px 24px}.title{font-size:21px}.tab{font-size:12px;min-height:42px;padding:0 4px}.stats,.actions{grid-template-columns:1fr}.item{grid-template-columns:1fr}.mini{justify-content:flex-start}.card{border-radius:22px;padding:14px}}
.install-app{display:none;align-items:center;justify-content:center;width:100%;min-height:42px;border:1px solid #bfdbfe;border-radius:16px;background:#eff6ff;color:#1d4ed8;font-size:13px;font-weight:900;margin-top:8px;cursor:pointer}.install-app:hover{background:#dbeafe}</style>

<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="#2563eb">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="پنل پیامک">
<link rel="apple-touch-icon" href="icons/icon-192.png">
</head>
<body>
<div class="app">
  <div class="header">
    <div class="title">استخراج شماره‌ها</div>
    <?php sms_panel_nav('extract'); ?>
    <button class="install-app" type="button" data-install-app>نصب پنل روی گوشی</button>
  </div>

  <section class="card">
    <div class="stats">
      <div class="stat">تعداد پیام‌های ثبت‌شده<b id="total-count">0</b></div>
      <div class="stat">شماره‌های یکتا<b id="unique-count">0</b></div>
    </div>
    <div class="actions">
      <button class="btn" onclick="saveVCF()">ذخیره داخل گوشی</button>
      <button class="btn ghost" onclick="copyNumbers()">کپی شماره‌ها</button>
      <button class="btn dark" onclick="downloadCSV()">دانلود CSV</button>
      <button class="btn ghost" onclick="toggleText()">نمایش لیست متنی</button>
    </div>
    <div class="hint">برای ذخیره داخل گوشی، فایل VCF دانلود می‌شود. فایل را باز کن و گزینه Import/ذخیره مخاطبین را بزن.</div>
  </section>

  <section class="card" id="text-card" style="display:none">
    <textarea id="numbers-text" readonly></textarea>
  </section>

  <section class="card">
    <div class="list" id="number-list"></div>
  </section>
</div>
<script>
const STORE_KEY = 'sms_messages';

function getMessages(){
  try {
    const raw = localStorage.getItem(STORE_KEY) || '[]';
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch(e) {
    return [];
  }
}

function escapeHtml(s){
  return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}

function normalizeDigits(str){
  const fa='۰۱۲۳۴۵۶۷۸۹', ar='٠١٢٣٤٥٦٧٨٩';
  return String(str ?? '')
    .replace(/[۰-۹]/g, d => fa.indexOf(d))
    .replace(/[٠-٩]/g, d => ar.indexOf(d));
}

function normalizeNumber(n){
  let x = normalizeDigits(n).replace(/\s+/g,'').replace(/[^0-9+]/g,'');
  if (x.startsWith('+98')) x = '0' + x.slice(3);
  if (x.startsWith('98') && x.length === 12) x = '0' + x.slice(2);
  return x;
}

function contactName(m){
  return (m.full_name || ((m.first_name || '') + ' ' + (m.last_name || '')).trim() || '').trim();
}

function getContacts(){
  const map = new Map();
  const messages = getMessages();

  messages.forEach((m, i) => {
    const n = normalizeNumber(m.receiver || m.phone || m.mobile || '');
    if (!/^09\d{9}$/.test(n)) return;

    const existing = map.get(n) || { number:n, name:'', lastIndex:-1, count:0 };
    const nm = contactName(m);

    map.set(n, {
      number: n,
      name: nm || existing.name,
      lastIndex: i,
      count: existing.count + 1
    });
  });

  return [...map.values()].sort((a,b) => b.lastIndex - a.lastIndex);
}

function setText(id, value){
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function loadNumbers(){
  const messages = getMessages();
  const contacts = getContacts();

  setText('total-count', messages.length);
  setText('unique-count', contacts.length);

  const textArea = document.getElementById('numbers-text');
  if (textArea) {
    textArea.value = contacts.map(c => (c.name ? c.name + ' - ' : '') + c.number).join('\n');
  }

  const list = document.getElementById('number-list');
  if (!list) return;
  list.innerHTML = '';

  if (!contacts.length) {
    list.innerHTML = '<div class="empty">هنوز شماره‌ای ثبت نشده است.</div>';
    return;
  }

  contacts.forEach(c => {
    const item = document.createElement('div');
    item.className = 'item';

    const left = document.createElement('div');

    const num = document.createElement('div');
    num.className = 'num';
    num.textContent = c.number;
    left.appendChild(num);

    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = c.name || 'بدون نام';
    left.appendChild(name);

    const mini = document.createElement('div');
    mini.className = 'mini';

    const call = document.createElement('a');
    call.href = 'tel:' + c.number;
    call.textContent = 'تماس';
    mini.appendChild(call);

    const sms = document.createElement('a');
    sms.href = 'sms:' + c.number;
    sms.textContent = 'پیامک';
    mini.appendChild(sms);

    const copy = document.createElement('button');
    copy.type = 'button';
    copy.textContent = 'کپی';
    copy.addEventListener('click', () => copyOne(c.number));
    mini.appendChild(copy);

    item.appendChild(left);
    item.appendChild(mini);
    list.appendChild(item);
  });
}

function copyOne(n){
  navigator.clipboard.writeText(n).then(() => alert('شماره کپی شد'));
}

function copyNumbers(){
  const contacts = getContacts();
  const text = contacts.map(c => (c.name ? c.name + ' - ' : '') + c.number).join('\n');
  if (!text) { alert('شماره‌ای وجود ندارد'); return; }
  navigator.clipboard.writeText(text).then(() => alert('شماره‌ها کپی شد'));
}

function downloadFile(name, content, type){
  const blob = new Blob([content], {type});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1200);
}

function downloadCSV(){
  const contacts = getContacts();
  if (!contacts.length) { alert('شماره‌ای وجود ندارد'); return; }
  const rows = contacts.map(c => '"' + String(c.name || '').replace(/"/g,'""') + '","' + String(c.number).replace(/"/g,'""') + '"');
  downloadFile('sms_contacts.csv', '\ufeffنام,شماره\n' + rows.join('\n'), 'text/csv;charset=utf-8');
}

function vcfSafe(s){
  return String(s || '').replace(/\r?\n/g, ' ').replace(/,/g, '\\,').replace(/;/g, '\\;');
}

function saveVCF(){
  const contacts = getContacts();
  if (!contacts.length) { alert('شماره‌ای وجود ندارد'); return; }
  let vcf = '';
  contacts.forEach((c, i) => {
    const name = c.name || ('SMS Contact ' + String(i + 1).padStart(3, '0'));
    vcf += 'BEGIN:VCARD\n';
    vcf += 'VERSION:3.0\n';
    vcf += 'FN:' + vcfSafe(name) + '\n';
    vcf += 'TEL;TYPE=CELL:' + c.number + '\n';
    vcf += 'END:VCARD\n';
  });
  downloadFile('sms_contacts.vcf', vcf, 'text/vcard;charset=utf-8');
}

function toggleText(){
  const c = document.getElementById('text-card');
  if (!c) return;
  c.style.display = c.style.display === 'none' ? 'block' : 'none';
  const t = document.getElementById('numbers-text');
  if (t) t.value = getContacts().map(x => (x.name ? x.name + ' - ' : '') + x.number).join('\n');
}

window.addEventListener('load', loadNumbers);
window.addEventListener('storage', loadNumbers);
</script>

<script src="pwa.js"></script>
</body>
</html>
