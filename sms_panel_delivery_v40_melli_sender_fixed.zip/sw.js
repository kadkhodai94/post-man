const SMS_PANEL_CACHE = 'sms-panel-install-v40';
const STATIC_ASSETS = [
  './manifest.webmanifest',
  './pwa.js',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(SMS_PANEL_CACHE).then(cache => cache.addAll(STATIC_ASSETS)).catch(() => null));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== SMS_PANEL_CACHE).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  const isStatic = url.pathname.endsWith('/manifest.webmanifest') ||
                   url.pathname.endsWith('/pwa.js') ||
                   url.pathname.includes('/icons/');
  if (!isStatic) return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request)));
});
