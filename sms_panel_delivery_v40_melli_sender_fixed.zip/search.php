<?php require_once __DIR__ . '/api/auth.php'; sms_panel_require_permission_page('search'); ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>جستجوی پیام‌ها</title>
<style>
:root{--bg:#f4f7fb;--card:#fff;--text:#111827;--muted:#64748b;--line:#e2e8f0;--primary:#2563eb;--primary2:#1d4ed8;--ok:#16a34a;--bad:#dc2626;--wait:#f59e0b;--unknown:#94a3b8;--soft:#f8fafc;--shadow:0 14px 35px rgba(15,23,42,.07)}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Tahoma,Arial,sans-serif;color:var(--text);direction:rtl}.app{max-width:760px;margin:auto;padding:14px 12px 30px}.header{position:sticky;top:0;z-index:10;background:rgba(244,247,251,.94);backdrop-filter:blur(10px);padding:10px 0 12px}.title{font-size:23px;font-weight:900;margin:8px 2px 14px}.tabs{display:grid;grid-template-columns:repeat(auto-fit,minmax(115px,1fr));gap:8px}.tab{display:flex;align-items:center;justify-content:center;min-height:44px;border:1px solid var(--line);border-radius:16px;background:#fff;color:#334155;text-decoration:none;font-size:13px;font-weight:800;box-shadow:0 6px 16px rgba(15,23,42,.04)}.tab.active{background:var(--primary);border-color:var(--primary);color:#fff}.tab.logout{background:#fff1f2;color:#be123c;border-color:#fecdd3}.card{background:#fff;border:1px solid var(--line);border-radius:24px;padding:16px;margin:14px 0;box-shadow:var(--shadow)}.searchbar{display:grid;grid-template-columns:1fr 110px;gap:10px}input{width:100%;border:1px solid #d7dee9;border-radius:17px;background:#fff;padding:14px 15px;font-size:15px;outline:none}.btn{border:0;border-radius:17px;padding:13px 14px;background:var(--primary);color:#fff;font-size:14px;font-weight:900;cursor:pointer;text-align:center;text-decoration:none;display:inline-flex;align-items:center;justify-content:center}.btn:hover{background:var(--primary2)}.btn.ghost{background:#eef2ff;color:#1e3a8a}.btn.dark{background:#334155}.btn.sms{background:#16a34a;color:#fff}.btn.sms:hover{background:#15803d}.actions{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}.hint{font-size:12px;color:var(--muted);line-height:1.9;margin-top:9px}.list{display:flex;flex-direction:column;gap:9px;margin-top:12px}.item{display:grid;grid-template-columns:34px 1fr;gap:10px;align-items:start;background:#fff;border:1px solid var(--line);border-radius:18px;padding:12px}.tick{width:31px;height:31px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900;font-size:17px;margin-top:3px}.ok{background:var(--ok)}.bad{background:var(--bad)}.wait{background:var(--wait)}.unknown{background:var(--unknown)}.main{min-width:0}.topline{display:flex;align-items:center;justify-content:space-between;gap:8px}.num{font-weight:900;font-size:16px;direction:ltr;text-align:right}.person{font-size:13px;font-weight:900;color:#1e293b;margin-top:2px}.date{font-size:11px;color:var(--muted);white-space:nowrap}.msg{font-size:13px;color:#334155;line-height:1.8;margin-top:5px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.sub{font-size:12px;color:var(--muted);line-height:1.8;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.status{display:inline-flex;margin-top:7px;font-size:12px;font-weight:900;border-radius:999px;padding:6px 10px}.status.ok{background:#dcfce7;color:#166534}.status.bad{background:#fee2e2;color:#991b1b}.status.wait{background:#fef3c7;color:#92400e}.status.unknown{background:#f1f5f9;color:#475569}details{grid-column:1/-1;margin-top:4px}summary{cursor:pointer;color:#475569;font-size:13px}.detailsbox{background:var(--soft);border-radius:14px;padding:10px;margin-top:8px;font-size:12px;line-height:1.9;color:#334155;word-break:break-word}.details-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}.empty{text-align:center;color:var(--muted);border:1px dashed #cbd5e1;border-radius:18px;background:#fff;padding:18px}.mini{font-size:12px;color:var(--muted);margin:4px 2px 0}.group-card{background:#fff;border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow);overflow:hidden}.group-card details{margin:0}.group-card summary{list-style:none}.group-card summary::-webkit-details-marker{display:none}.group-summary{display:grid;grid-template-columns:34px 1fr;gap:10px;align-items:start;padding:14px;cursor:pointer}.group-title{font-size:17px;font-weight:900;color:#111827}.group-meta{display:flex;flex-wrap:wrap;gap:7px;margin-top:7px}.pill{font-size:11px;font-weight:900;border-radius:999px;padding:5px 9px;background:#f1f5f9;color:#475569}.pill.ok{background:#dcfce7;color:#166534}.pill.bad{background:#fee2e2;color:#991b1b}.pill.wait{background:#fef3c7;color:#92400e}.group-body{border-top:1px solid var(--line);padding:10px 12px 13px;background:#fbfdff}.member{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;border:1px solid #e5e7eb;border-radius:15px;background:#fff;padding:10px;margin-top:8px}.member-main{min-width:0}.member .num{font-size:14px}.member-actions{display:flex;gap:6px;flex-wrap:wrap}.member-actions .btn{padding:9px 10px;font-size:12px;border-radius:13px}.group-help{font-size:12px;color:var(--muted);line-height:1.8;margin-top:7px}@media(max-width:540px){.app{padding:10px 10px 24px}.title{font-size:21px}.tab{font-size:12px;min-height:42px;padding:0 4px}.searchbar,.actions,.details-actions{grid-template-columns:1fr}.card{border-radius:22px;padding:14px}.topline{align-items:flex-start;flex-direction:column;gap:2px}.date{white-space:normal}.msg{-webkit-line-clamp:3}.member{grid-template-columns:1fr}.member-actions{display:grid;grid-template-columns:1fr 1fr}.group-summary{padding:12px}}
.install-app{display:none;align-items:center;justify-content:center;width:100%;min-height:42px;border:1px solid #bfdbfe;border-radius:16px;background:#eff6ff;color:#1d4ed8;font-size:13px;font-weight:900;margin-top:8px;cursor:pointer}.install-app:hover{background:#dbeafe}</style>

<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="#2563eb">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="پنل پیامک">
<link rel="apple-touch-icon" href="icons/icon-192.png">
</head>
<body>
<div class="app">
  <div class="header">
    <div class="title">جستجوی پیام‌ها</div>
    <?php sms_panel_nav('search'); ?>
    <button class="install-app" type="button" data-install-app>نصب پنل روی گوشی</button>
  </div>

  <section class="card">
    <div class="searchbar">
      <input type="text" id="q" placeholder="جستجو در کل پیام‌ها؛ اسم گروه، شماره، نام، فامیل، ۴ رقم آخر یا متن پیام">
      <button class="btn" onclick="searchMessages()">جستجو</button>
    </div>
    <div class="actions">
      <button class="btn ghost" onclick="showTodayMessages()">نمایش پیام‌های امروز</button>
      <button class="btn dark" onclick="autoCheckVisibleDeliveries(true)">به‌روزرسانی خودکار دلیوری</button>
    </div>
    <div class="hint">در حالت عادی فقط پیام‌های همان روز نمایش داده می‌شوند؛ اما وقتی جستجو کنی، جستجو بین کل پیام‌های ذخیره‌شده انجام می‌شود. پیام‌هایی که همزمان با یک متن ارسال شوند، داخل یک کادر گروهی نمایش داده می‌شوند. برای پیام‌های ناموفق، دکمه «ارسال عادی با گوشی» نمایش داده می‌شود.</div>
  </section>

  <div class="mini" id="count-line"></div>
  <section class="list" id="result-list"></section>
</div>
<script>
let visibleMessages=[];
let currentMode='today';
let autoTimer=null;
let checking=false;

function getMessages(){try{return JSON.parse(localStorage.getItem('sms_messages')||'[]')}catch(e){return []}}
function saveMessages(m){localStorage.setItem('sms_messages',JSON.stringify(m))}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function normalizeDigits(str){const fa='۰۱۲۳۴۵۶۷۸۹',ar='٠١٢٣٤٥٦٧٨٩';return String(str).replace(/[۰-۹]/g,d=>fa.indexOf(d)).replace(/[٠-٩]/g,d=>ar.indexOf(d))}
function todayFaDate(){return normalizeDigits(new Intl.DateTimeFormat('fa-IR',{year:'numeric',month:'numeric',day:'numeric'}).format(new Date())).replace(/\s/g,'')}
function messageFaDate(m){
  if(m.created_at_iso){const d=new Date(m.created_at_iso);if(!isNaN(d))return normalizeDigits(new Intl.DateTimeFormat('fa-IR',{year:'numeric',month:'numeric',day:'numeric'}).format(d)).replace(/\s/g,'')}
  const raw=normalizeDigits(m.date||'').replace(/\s/g,'');
  const match=raw.match(/\d{4}[\/\-.]\d{1,2}[\/\-.]\d{1,2}/);
  return match?match[0]:raw.split(/[،,\s]/)[0]
}
function isToday(m){return messageFaDate(m)===todayFaDate()}
function isValidRecId(v,service){const x=String(v||'').trim(); return /^\d{6,}$/.test(x)}
function smallApiCode(m){return String(m.send_api_code||m.rec_id||'').trim()}
function fullName(m){return (m.full_name || ((m.first_name||'')+' '+(m.last_name||'')).trim() || '').trim()}

function finalStatus(m){
  const recId = m.rec_id || '';
  const validRec = isValidRecId(recId, m.service||'melli');
  const lvl = m.delivery_level || 'unknown';
  const code = smallApiCode(m);
  if(!validRec){
    if(code && /^\d+$/.test(code) && Number(code) > 1 && Number(code) < 100){
      return {cls:'bad',tick:'×',label:'ارسال ناموفق',line:m.send_status || ('کد API '+code+' شناسه دلیوری نیست')};
    }
    return {cls:'wait',tick:'…',label:'در انتظار دلیوری',line:m.delivery_text || 'شناسه دلیوری واقعی هنوز دریافت نشده'};
  }
  if(lvl==='delivered') return {cls:'ok',tick:'✓',label:'رسیده به گوشی',line:m.delivery_text||'رسیده به گوشی'};
  if(lvl==='failed') return {cls:'bad',tick:'×',label:'نرسیده / ناموفق',line:m.delivery_text||'دلیوری ناموفق'};
  if(lvl==='operator'){
    const dc=String(m.delivery_code||'');
    if(dc==='5') return {cls:'wait',tick:'↗',label:'رسیده به مخابرات',line:m.delivery_text||'رسیده به مخابرات'};
    if(dc==='3') return {cls:'wait',tick:'↻',label:'پردازش در مخابرات',line:m.delivery_text||'پردازش در مخابرات'};
    return {cls:'wait',tick:'↗',label:'در مسیر اپراتور',line:m.delivery_text||'در مسیر اپراتور'};
  }
  return {cls:'wait',tick:'…',label:'در انتظار دلیوری',line:m.delivery_text||'در انتظار گزارش اپراتور'};
}
function deliveryLabel(m){return finalStatus(m).line}
function isFailed(m){return finalStatus(m).cls==='bad'}
function smsHref(m){return 'sms:'+encodeURIComponent(String(m.receiver||''))+'?body='+encodeURIComponent(String(m.text||''))}
function shouldAutoCheck(m){
  if(!isValidRecId(m.rec_id, m.service||'melli')) return false;
  const lvl=m.delivery_level||'unknown';
  return lvl!=='delivered' && lvl!=='failed';
}
function groupSummaryStatus(items){
  const metas=items.map(finalStatus);
  const delivered=metas.filter(x=>x.cls==='ok').length;
  const failed=metas.filter(x=>x.cls==='bad').length;
  const waiting=items.length-delivered-failed;
  if(failed>0) return {cls:'bad',tick:'×',label:failed+' ناموفق',delivered,failed,waiting};
  if(delivered===items.length) return {cls:'ok',tick:'✓',label:'همه رسیده به گوشی',delivered,failed,waiting};
  return {cls:'wait',tick:'…',label:'در حال بررسی',delivered,failed,waiting};
}
function buildUnits(messages){
  const order=[];
  const groups=new Map();
  messages.forEach(m=>{
    const gid=String(m.group_id||'');
    if(gid && Number(m.group_size||0)>1){
      if(!groups.has(gid)){groups.set(gid,[]);order.push({type:'group',id:gid})}
      groups.get(gid).push(m);
    }else{
      order.push({type:'single',message:m});
    }
  });
  return order.map(u=>u.type==='group'?{type:'group',id:u.id,messages:groups.get(u.id)}:u);
}
function renderSingle(m){
  const meta=finalStatus(m);
  const recId=isValidRecId(m.rec_id, m.service||'melli')?m.rec_id:'';
  const name=fullName(m);
  const row=document.createElement('div');
  row.className='item';
  const smsBtn=isFailed(m)?'<a class="btn sms" href="'+escapeHtml(smsHref(m))+'">ارسال عادی با گوشی</a>':'';
  row.innerHTML=
    '<div class="tick '+meta.cls+'">'+meta.tick+'</div>'+ 
    '<div class="main">'+
      '<div class="topline"><div><div class="num">'+escapeHtml(m.receiver)+'</div>'+(name?'<div class="person">'+escapeHtml(name)+'</div>':'')+'</div><div class="date">'+escapeHtml(m.date||'-')+'</div></div>'+ 
      '<div class="msg">'+escapeHtml(m.text||'بدون متن')+'</div>'+ 
      '<div class="sub">'+escapeHtml(deliveryLabel(m))+'</div>'+ 
      '<span class="status '+meta.cls+'">'+meta.label+'</span>'+ 
    '</div>'+ 
    '<details><summary>جزئیات</summary>'+ 
      '<div class="detailsbox">'+
        '<b>گروه:</b> '+escapeHtml(m.group_title||'-')+'<br>'+
        '<b>نام:</b> '+escapeHtml(name||'-')+'<br>'+ 
        '<b>تاریخ:</b> '+escapeHtml(m.date||'-')+'<br>'+ 
        '<b>فرستنده:</b> '+escapeHtml(m.sender||'-')+'<br>'+ 
        '<b>سرویس:</b> '+escapeHtml((m.service==='smsir')?'SMS.ir':'ملی پیامک')+'<br>'+ 
        '<b>نوع ارسال:</b> '+escapeHtml(m.send_type_label||'-')+'<br>'+ 
        '<b>شناسه دلیوری:</b> '+escapeHtml(recId||'ندارد')+'<br>'+ 
        '<b>کد API:</b> '+escapeHtml(m.send_api_code||'-')+'<br>'+ 
        '<b>وضعیت اولیه:</b> '+escapeHtml(m.send_status||'-')+'<br>'+ 
        '<b>دلیوری:</b> '+escapeHtml(m.delivery_text||'در انتظار')+'<br>'+ 
        '<b>آخرین بررسی خودکار:</b> '+escapeHtml(m.delivery_checked_at||'-')+
      '</div>'+ 
      '<div class="details-actions">'+
        '<button class="btn ghost" onclick="copyText(\''+escapeHtml(m.receiver||'')+'\')">کپی شماره</button>'+smsBtn+
      '</div>'+ 
    '</details>';
  return row;
}
function memberHtml(m){
  const meta=finalStatus(m);
  const name=fullName(m);
  const smsBtn=isFailed(m)?'<a class="btn sms" href="'+escapeHtml(smsHref(m))+'">ارسال عادی با گوشی</a>':'';
  return '<div class="member">'+
    '<div class="member-main"><div class="num">'+escapeHtml(m.receiver||'-')+'</div>'+(name?'<div class="person">'+escapeHtml(name)+'</div>':'')+'<div class="sub">'+escapeHtml(meta.line)+'</div><span class="status '+meta.cls+'">'+escapeHtml(meta.label)+'</span></div>'+ 
    '<div class="member-actions"><button class="btn ghost" onclick="copyText(\''+escapeHtml(m.receiver||'')+'\')">کپی</button>'+smsBtn+'</div>'+ 
  '</div>';
}
function renderGroup(items){
  const first=items[0]||{};
  const st=groupSummaryStatus(items);
  const title=first.group_title||'گروه بدون عنوان';
  const row=document.createElement('div');
  row.className='group-card';
  row.innerHTML=
    '<details>'+ 
      '<summary class="group-summary">'+
        '<div class="tick '+st.cls+'">'+st.tick+'</div>'+ 
        '<div class="main">'+
          '<div class="topline"><div><div class="group-title">'+escapeHtml(title)+'</div><div class="sub">'+escapeHtml(first.text||'بدون متن')+'</div></div><div class="date">'+escapeHtml(first.date||'-')+'</div></div>'+ 
          '<div class="group-meta"><span class="pill">'+items.length+' شماره</span><span class="pill ok">'+st.delivered+' رسیده</span><span class="pill wait">'+st.waiting+' در انتظار</span><span class="pill bad">'+st.failed+' ناموفق</span><span class="pill '+st.cls+'">'+st.label+'</span></div>'+ 
          '<div class="group-help">برای دیدن شماره‌ها روی همین کادر بزن.</div>'+ 
        '</div>'+ 
      '</summary>'+ 
      '<div class="group-body">'+items.map(memberHtml).join('')+'</div>'+ 
    '</details>';
  return row;
}
function renderMessages(messages,modeText){
  visibleMessages=messages;
  const list=document.getElementById('result-list');
  const count=document.getElementById('count-line');
  list.innerHTML='';
  const units=buildUnits(messages);
  count.textContent=(modeText?modeText+' | ':'')+(messages.length?'تعداد پیام: '+messages.length+' / تعداد کادر: '+units.length:'');
  if(!messages.length){list.innerHTML='<div class="empty">پیامی پیدا نشد.</div>';return}
  units.slice().reverse().forEach(u=>{list.appendChild(u.type==='group'?renderGroup(u.messages):renderSingle(u.message))})
}
function messageMatches(m,q){
  const name=normalizeDigits((fullName(m)+' '+(m.group_title||'')).trim());
  return String(m.receiver||'').includes(q)||String(m.receiver||'').slice(-4)===q||normalizeDigits(String(m.text||'')).includes(q)||name.includes(q);
}
function currentFilteredMessages(){
  const q=normalizeDigits(document.getElementById('q').value.trim());
  const all=getMessages();
  if(q){
    const base=all.filter(m=>messageMatches(m,q));
    const baseIds=new Set(base.map(m=>m.id));
    const groupIds=new Set(base.map(m=>m.group_id).filter(Boolean));
    return all.filter(m=>baseIds.has(m.id)||groupIds.has(m.group_id));
  }
  return all.filter(isToday);
}
function refreshCurrent(){renderMessages(currentFilteredMessages(), document.getElementById('q').value.trim()?'نتیجه جستجو در کل پیام‌ها':'پیام‌های امروز')}
function searchMessages(){currentMode='search';refreshCurrent();autoCheckVisibleDeliveries(false)}
function showTodayMessages(){currentMode='today';document.getElementById('q').value='';refreshCurrent();autoCheckVisibleDeliveries(false)}
function copyText(t){navigator.clipboard.writeText(t).then(()=>alert('کپی شد')).catch(()=>alert('کپی خودکار انجام نشد'))}

async function fetchDelivery(message){
  const recId=message.rec_id;
  const res=await fetch('api/delivery.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:new URLSearchParams({service:message.service||'melli',rec_id:recId,receiver:message.receiver||''})});
  const raw=await res.text();
  let data;try{data=JSON.parse(raw)}catch(e){throw new Error('پاسخ دلیوری قابل خواندن نبود')}
  if(data.status!=='done'||!data.result) throw new Error(data.message||'خطا در دریافت دلیوری');
  return data.result;
}
async function autoCheckVisibleDeliveries(manualMessage){
  if(checking) return;
  const targets=visibleMessages.filter(shouldAutoCheck).slice(0,20);
  if(!targets.length){if(manualMessage) alert('فعلاً پیام قابل به‌روزرسانی دلیوری وجود ندارد. پیام‌های بدون شناسه معتبر در حالت انتظار می‌مانند.');return}
  checking=true;
  let messages=getMessages();
  for(const m of targets){
    try{
      const result=await fetchDelivery(m);
      const idx=messages.findIndex(x=>x.id===m.id);
      if(idx!==-1){
        messages[idx].delivery_code=result.delivery_code||'';
        messages[idx].delivery_text=result.delivery_text||'';
        messages[idx].delivery_level=result.delivery_level||'unknown';
        messages[idx].delivery_checked_at=new Date().toLocaleString('fa-IR');
      }
    }catch(e){/* خطای موقت دلیوری، صفحه را شلوغ نکن */}
  }
  saveMessages(messages);
  checking=false;
  refreshCurrent();
}
window.addEventListener('load',()=>{
  showTodayMessages();
  setTimeout(()=>autoCheckVisibleDeliveries(false), 1500);
  autoTimer=setInterval(()=>autoCheckVisibleDeliveries(false), 15000);
});
</script>

<script src="pwa.js"></script>
</body>
</html>
