نسخه v32 - جایگزینی IPPanel با SMS.ir

فایل‌های اصلی اصلاح‌شده:
- api/config.php
- api/send.php
- api/delivery.php
- api/test.php
- index.php
- search.php

تنظیم SMS.ir:
1) وارد پنل SMS.ir شوید.
2) از بخش برنامه‌نویسان / API Key یک کلید معتبر بردارید.
3) فایل api/config.php را باز کنید و این دو مقدار را با اطلاعات واقعی خودتان جایگزین کنید:

define('SMSIR_API_KEY', 'SMSIR_API_KEY_اینجا');
define('SMSIR_DEFAULT_SENDER', '500031181890144');

نکته:
- SMSIR_DEFAULT_SENDER باید شماره خط اختصاصی عددی پنل SMS.ir باشد.
- مسیر ارسال استفاده‌شده: POST https://api.sms.ir/v1/send/bulk
- مسیر دلیوری استفاده‌شده: GET https://api.sms.ir/v1/send/{messageId}
- لاگ ارسال SMS.ir در api/smsir_last_response.log ذخیره می‌شود.
- لاگ دلیوری SMS.ir در api/smsir_delivery_last_response.log ذخیره می‌شود.

بعد از آپلود:
- error_log قدیمی را پاک کنید.
- اگر خطا گرفتید فایل‌های smsir_last_response.log و smsir_delivery_last_response.log را بررسی کنید.


نسخه v33:
- خطوط SMS.ir کاربر داخل config و صفحه ارسال اضافه شد.
- سرویس پیش‌فرض صفحه ارسال روی SMS.ir قرار گرفت.
- خطوط اضافه‌شده:
  1) 500031181890144
  2) 30002108020400

برای فعال شدن ارسال فقط SMSIR_API_KEY را در api/config.php با کلید واقعی پنل SMS.ir جایگزین کن.
