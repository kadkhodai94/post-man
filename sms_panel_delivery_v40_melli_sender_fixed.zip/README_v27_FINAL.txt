نسخه v27 نهایی

تغییرات:
- فایل api/auth.php هم داخل بسته است تا خطای Array to string conversion در هاست‌های PHP قدیمی رفع شود.
- api/send.php همیشه JSON برمی‌گرداند و با خطاهای PHP خروجی صفحه را خراب نمی‌کند.
- کلید IPPanel در api/config.php بدون پیشوند اشتباه قرار گرفته است.
- ارسال IPPanel زمان انتظار کوتاه دارد و روی «در حال ارسال» قفل نمی‌ماند.
- اگر IPPanel پیام را قبول نکند، خطا داخل api/ippanel_last_response.log ثبت می‌شود.

بعد از Extract، اگر هنوز IPPanel ارسال نکرد، فایل api/ippanel_last_response.log را بفرست.
