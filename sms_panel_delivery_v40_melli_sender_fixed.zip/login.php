<?php
require_once __DIR__ . '/api/auth.php';

if (sms_panel_is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if (sms_panel_attempt_login($username, $password)) {
        header('Location: index.php');
        exit;
    }
    $error = 'نام کاربری یا رمز عبور اشتباه است.';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ورود به پنل پیامک</title>
<style>
:root{--bg:#f4f7fb;--card:#fff;--text:#111827;--muted:#64748b;--line:#e2e8f0;--primary:#2563eb;--primary2:#1d4ed8;--bad:#dc2626;--shadow:0 18px 45px rgba(15,23,42,.09)}
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:linear-gradient(180deg,#eef5ff,var(--bg));font-family:Tahoma,Arial,sans-serif;color:var(--text);direction:rtl;display:flex;align-items:center;justify-content:center;padding:18px}.login{width:100%;max-width:420px;background:var(--card);border:1px solid var(--line);border-radius:28px;padding:24px;box-shadow:var(--shadow)}.logo{width:54px;height:54px;border-radius:18px;background:#dbeafe;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;font-size:26px}.title{text-align:center;font-size:23px;font-weight:900;margin:0 0 8px}.sub{text-align:center;color:var(--muted);font-size:13px;line-height:1.9;margin-bottom:18px}label{display:block;font-size:14px;font-weight:800;margin:12px 2px 8px}input{width:100%;border:1px solid #d7dee9;border-radius:17px;background:#fff;padding:14px 15px;font-size:15px;outline:none}input:focus{border-color:#93c5fd;box-shadow:0 0 0 4px #dbeafe}.btn{width:100%;border:0;border-radius:18px;padding:15px;margin-top:18px;background:var(--primary);color:#fff;font-size:16px;font-weight:900;cursor:pointer}.btn:hover{background:var(--primary2)}.error{background:#fee2e2;color:#991b1b;border:1px solid #fecaca;border-radius:16px;padding:12px 13px;font-size:14px;line-height:1.8;margin-bottom:14px}.hint{margin-top:14px;color:var(--muted);font-size:12px;line-height:1.9;text-align:center}
.install-app{display:none;align-items:center;justify-content:center;width:100%;min-height:42px;border:1px solid #bfdbfe;border-radius:16px;background:#eff6ff;color:#1d4ed8;font-size:13px;font-weight:900;margin-top:8px;cursor:pointer}.install-app:hover{background:#dbeafe}</style>

<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="#2563eb">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="پنل پیامک">
<link rel="apple-touch-icon" href="icons/icon-192.png">
</head>
<body>
<form class="login" method="post" autocomplete="off">
  <div class="logo">🔐</div>
  <h1 class="title">ورود به پنل پیامک</h1>
  <div class="sub">برای دسترسی به بخش‌های مجاز پنل وارد شوید.</div>
  <?php if ($error): ?><div class="error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
  <label for="username">نام کاربری</label>
  <input id="username" name="username" type="text" required autofocus>
  <label for="password">رمز عبور</label>
  <input id="password" name="password" type="password" required>
  <button class="btn" type="submit">ورود</button>
  <button class="install-app" type="button" data-install-app>نصب پنل روی گوشی</button>
</form>

<script src="pwa.js"></script>
</body>
</html>
