import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const PostSmsApp());

const persianMonths = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

const shipmentTypes = ['بسته', 'پاکت', 'امانت', 'کارت سوخت', 'کارت بانکی', 'کارت پلاک', 'برگ سبز'];

const String kDefaultApiBase = 'https://podtman.anony.ir/post/api';

const statusText = {
  'registered': 'ثبت شد',
  'processing': 'در حال پردازش',
  'in_transit': 'در مسیر',
  'delivered': 'تحویل شد',
  'returned': 'برگشتی',
  'cancelled': 'لغو شده',
};

String toFa(Object? value) => '$value'.replaceAllMapped(RegExp(r'\d'), (m) => '۰۱۲۳۴۵۶۷۸۹'[int.parse(m.group(0)!)]);
String dateVal(int y, int m, int d) => '$y/${persianMonths[m - 1]}/$d';

List<int> gregorianToJalali(int gy, int gm, int gd) {
  final gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  var jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  final gy2 = gm > 2 ? gy + 1 : gy;
  var days = 365 * gy + ((gy2 + 3) ~/ 4) - ((gy2 + 99) ~/ 100) + ((gy2 + 399) ~/ 400) - 80 + gd + gdm[gm - 1];
  jy += 33 * (days ~/ 12053);
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    jy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  final jm = days < 186 ? 1 + (days ~/ 31) : 7 + ((days - 186) ~/ 30);
  final jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

class PostSmsApp extends StatelessWidget {
  const PostSmsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سامانه مرسولات و پیامک',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xff0f4c81),
          primary: const Color(0xff0f4c81),
          secondary: const Color(0xff2f80ed),
          surface: Colors.white,
        ),
        scaffoldBackgroundColor: const Color(0xfff8fafc),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          backgroundColor: Colors.white,
          foregroundColor: Color(0xff111827),
          surfaceTintColor: Colors.white,
          elevation: 0.6,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 1.5,
          margin: const EdgeInsets.symmetric(vertical: 7),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xffd9e2ec)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xff0f4c81), width: 1.7),
          ),
        ),
      ),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const HomePage(),
    );
  }
}

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}

class ApiService {
  String baseUrl = '';
  String token = '';

  Uri uri(String path, [Map<String, String>? query]) {
    final normalized = baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    final fullPath = path.startsWith('/') ? path : '/$path';
    final parsed = Uri.parse('$normalized$fullPath');
    return query == null || query.isEmpty ? parsed : parsed.replace(queryParameters: query);
  }

  String imageUrl(String src) {
    if (src.startsWith('http://') || src.startsWith('https://')) return src;
    final root = baseUrl.trim().replaceAll(RegExp(r'/api/?$'), '').replaceAll(RegExp(r'/+$'), '');
    final clean = src.startsWith('/') ? src.substring(1) : src;
    return '$root/$clean';
  }

  Map<String, String> get authHeaders => token.isEmpty ? {} : {'Authorization': 'Bearer $token'};

  Future<Map<String, dynamic>> login(String username, String password) async {
    final response = await http.post(
      uri('/login.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> getJson(String path, {Map<String, String>? query}) async {
    final response = await http.get(uri(path, query), headers: authHeaders);
    return _decode(response);
  }

  Future<Map<String, dynamic>> postJson(String path, Map<String, dynamic> data) async {
    final response = await http.post(
      uri(path),
      headers: {'Content-Type': 'application/json; charset=utf-8', ...authHeaders},
      body: jsonEncode(data),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> deleteJson(String path, {Map<String, String>? query}) async {
    final response = await http.delete(uri(path, query), headers: authHeaders);
    return _decode(response);
  }

  Future<Map<String, dynamic>> saveShipment({required Map<String, String> fields, required List<PendingPhoto> photos}) async {
    final request = http.MultipartRequest('POST', uri('/save.php'));
    request.headers.addAll(authHeaders);
    request.fields.addAll(fields);
    for (var i = 0; i < photos.length; i++) {
      final name = photos[i].file.name.isEmpty ? 'photo_${i + 1}.jpg' : photos[i].file.name;
      request.files.add(http.MultipartFile.fromBytes('images[]', photos[i].bytes, filename: name));
    }
    final streamed = await request.send();
    final response = await http.Response.fromStream(streamed);
    return _decode(response);
  }

  Map<String, dynamic> _decode(http.Response response) {
    late Map<String, dynamic> decoded;
    try {
      decoded = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      final body = utf8.decode(response.bodyBytes, allowMalformed: true);
      throw ApiException('پاسخ سرور معتبر نیست: ${body.substring(0, body.length < 180 ? body.length : 180)}');
    }
    if (decoded['ok'] != true) {
      throw ApiException((decoded['error'] ?? decoded['message'] ?? 'خطای سرور').toString());
    }
    return decoded;
  }
}

class PendingPhoto {
  PendingPhoto(this.file, this.bytes);
  final XFile file;
  final Uint8List bytes;
}

class Shipment {
  Shipment({
    required this.id,
    required this.trackingCode,
    required this.fullname,
    required this.phone,
    required this.receiverInfo,
    required this.shipmentType,
    required this.status,
    required this.shamsiDate,
    required this.description,
    required this.images,
    required this.createdBy,
    required this.updatedBy,
    required this.createdAt,
  });

  final int id;
  final String trackingCode;
  final String fullname;
  final String phone;
  final String receiverInfo;
  final String shipmentType;
  final String status;
  final String shamsiDate;
  final String description;
  final List<String> images;
  final String createdBy;
  final String updatedBy;
  final String createdAt;

  factory Shipment.fromJson(Map<String, dynamic> json) {
    final imgs = <String>[];
    final raw = json['images'];
    if (raw is List) imgs.addAll(raw.map((e) => '$e').where((e) => e.isNotEmpty));
    if (raw is String && raw.trim().isNotEmpty) {
      try {
        final dec = jsonDecode(raw);
        if (dec is List) imgs.addAll(dec.map((e) => '$e').where((e) => e.isNotEmpty));
      } catch (_) {}
    }
    final single = (json['image'] ?? '').toString();
    if (imgs.isEmpty && single.isNotEmpty) imgs.add(single);
    return Shipment(
      id: int.tryParse('${json['id']}') ?? 0,
      trackingCode: (json['tracking_code'] ?? '').toString(),
      fullname: (json['fullname'] ?? '').toString(),
      phone: (json['phone'] ?? '').toString(),
      receiverInfo: (json['receiver_info'] ?? '').toString(),
      shipmentType: (json['shipment_type'] ?? 'بسته').toString(),
      status: (json['status'] ?? 'registered').toString(),
      shamsiDate: (json['shamsi_date'] ?? '').toString(),
      description: (json['description'] ?? '').toString(),
      images: imgs,
      createdBy: (json['created_by'] ?? '').toString(),
      updatedBy: (json['updated_by'] ?? '').toString(),
      createdAt: (json['created_at'] ?? '').toString(),
    );
  }
}

class DashboardData {
  DashboardData({required this.total, required this.today, required this.month, required this.latest});
  final int total;
  final int today;
  final int month;
  final List<Shipment> latest;

  factory DashboardData.fromJson(Map<String, dynamic> json) {
    final latest = <Shipment>[];
    final raw = json['latest'];
    if (raw is List) {
      for (final item in raw) {
        if (item is Map) latest.add(Shipment.fromJson(Map<String, dynamic>.from(item)));
      }
    }
    return DashboardData(
      total: int.tryParse('${json['total']}') ?? 0,
      today: int.tryParse('${json['today']}') ?? 0,
      month: int.tryParse('${json['month']}') ?? 0,
      latest: latest,
    );
  }
}

class AppUser {
  AppUser({required this.id, required this.username, required this.roleLabel, required this.isActive, required this.lastLoginAt});
  final int id;
  final String username;
  final String roleLabel;
  final bool isActive;
  final String lastLoginAt;

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        id: int.tryParse('${json['id']}') ?? 0,
        username: (json['username'] ?? '').toString(),
        roleLabel: (json['role_label'] ?? json['role'] ?? 'کاربر عادی').toString(),
        isActive: '${json['is_active']}' == '1' || json['is_active'] == true,
        lastLoginAt: (json['last_login_at'] ?? '-').toString(),
      );
}

class AppLog {
  AppLog({required this.createdAt, required this.username, required this.action, required this.entity, required this.ip, required this.details});
  final String createdAt;
  final String username;
  final String action;
  final String entity;
  final String ip;
  final String details;

  factory AppLog.fromJson(Map<String, dynamic> json) => AppLog(
        createdAt: (json['created_at'] ?? '').toString(),
        username: (json['username'] ?? '-').toString(),
        action: (json['action'] ?? '-').toString(),
        entity: '${json['entity'] ?? '-'} #${json['entity_id'] ?? ''}',
        ip: (json['ip_address'] ?? '-').toString(),
        details: (json['details'] ?? '-').toString(),
      );
}

class SmsStats {
  SmsStats({required this.total, required this.today, required this.month, required this.delivered, required this.failed, required this.waiting});
  final int total;
  final int today;
  final int month;
  final int delivered;
  final int failed;
  final int waiting;
  factory SmsStats.fromJson(Map<String, dynamic> json) => SmsStats(
        total: int.tryParse('${json['total']}') ?? 0,
        today: int.tryParse('${json['today']}') ?? 0,
        month: int.tryParse('${json['month']}') ?? 0,
        delivered: int.tryParse('${json['delivered']}') ?? 0,
        failed: int.tryParse('${json['failed']}') ?? 0,
        waiting: int.tryParse('${json['waiting']}') ?? 0,
      );
}

class SmsMessage {
  SmsMessage({
    required this.id,
    required this.groupId,
    required this.groupTitle,
    required this.receiver,
    required this.fullName,
    required this.sender,
    required this.text,
    required this.service,
    required this.recId,
    required this.sendOk,
    required this.sendStatus,
    required this.deliveryText,
    required this.deliveryLevel,
    required this.createdAt,
  });
  final int id;
  final String groupId;
  final String groupTitle;
  final String receiver;
  final String fullName;
  final String sender;
  final String text;
  final String service;
  final String recId;
  final bool sendOk;
  final String sendStatus;
  final String deliveryText;
  final String deliveryLevel;
  final String createdAt;

  factory SmsMessage.fromJson(Map<String, dynamic> json) => SmsMessage(
        id: int.tryParse('${json['id']}') ?? 0,
        groupId: (json['group_id'] ?? '').toString(),
        groupTitle: (json['group_title'] ?? '').toString(),
        receiver: (json['receiver'] ?? '').toString(),
        fullName: (json['full_name'] ?? '').toString(),
        sender: (json['sender'] ?? '').toString(),
        text: (json['text'] ?? '').toString(),
        service: (json['service'] ?? 'smsir').toString(),
        recId: (json['rec_id'] ?? '').toString(),
        sendOk: '${json['send_ok']}' == '1' || json['send_ok'] == true,
        sendStatus: (json['send_status'] ?? '').toString(),
        deliveryText: (json['delivery_text'] ?? '').toString(),
        deliveryLevel: (json['delivery_level'] ?? 'unknown').toString(),
        createdAt: (json['created_at'] ?? '').toString(),
      );
}

class SmsContact {
  SmsContact({required this.number, required this.name, required this.count});
  final String number;
  final String name;
  final int count;
  factory SmsContact.fromJson(Map<String, dynamic> json) => SmsContact(
        number: (json['number'] ?? '').toString(),
        name: (json['name'] ?? '').toString(),
        count: int.tryParse('${json['count']}') ?? 0,
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final api = ApiService();
  final picker = ImagePicker();

  final apiController = TextEditingController(text: kDefaultApiBase);
  final loginUserController = TextEditingController(text: 'admin');
  final loginPassController = TextEditingController();
  final searchController = TextEditingController();
  final fullnameController = TextEditingController();
  final phoneController = TextEditingController();
  final receiverController = TextEditingController();
  final newUserController = TextEditingController();
  final newPassController = TextEditingController();
  final userIdController = TextEditingController();
  final smsSenderController = TextEditingController(text: '30002108020400');
  final smsNumbersController = TextEditingController();
  final smsTextController = TextEditingController();
  final smsGroupController = TextEditingController();
  final smsSearchController = TextEditingController();
  final logUserController = TextEditingController();

  bool loggedIn = false;
  bool loading = false;
  bool saving = false;
  bool sendingSms = false;
  bool rememberMe = true;
  String username = '';
  String role = '';
  String roleLabel = '';
  List<String> permissions = [];

  int pageIndex = 0;
  String shipmentType = shipmentTypes.first;
  int jy = 1405, jm = 1, jd = 1;
  int ry = 1405, rm = 1, rd = 1;
  int reportTypeIndex = 0;
  int? editingShipmentId;
  bool newUserActive = true;
  String smsService = 'smsir';
  bool smsTodayOnly = true;
  String logAction = '';
  String logEntity = '';

  DashboardData? dashboard;
  SmsStats? smsStats;
  List<Shipment> shipments = [];
  List<PendingPhoto> selectedPhotos = [];
  List<AppUser> users = [];
  List<AppLog> logs = [];
  List<SmsMessage> smsMessages = [];
  List<SmsContact> smsContacts = [];
  Timer? searchDebounce;

  bool has(String permission) => permissions.contains(permission);
  bool get canAdmin => role == 'admin';

  @override
  void initState() {
    super.initState();
    _setToday();
    _restoreSession();
  }

  @override
  void dispose() {
    searchDebounce?.cancel();
    for (final c in [
      apiController, loginUserController, loginPassController, searchController, fullnameController,
      phoneController, receiverController, newUserController, newPassController, userIdController,
      smsSenderController, smsNumbersController, smsTextController, smsGroupController, smsSearchController,
      logUserController,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  void _setToday() {
    final now = DateTime.now();
    final j = gregorianToJalali(now.year, now.month, now.day);
    jy = ry = j[0];
    jm = rm = j[1];
    jd = rd = j[2];
  }

  Future<void> _restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    apiController.text = prefs.getString('post_api_base') ?? kDefaultApiBase;
    final token = prefs.getString('post_token') ?? '';
    if (token.isEmpty) return;
    api.baseUrl = apiController.text.trim();
    api.token = token;
    username = prefs.getString('post_user') ?? '';
    role = prefs.getString('post_role') ?? '';
    roleLabel = prefs.getString('post_role_label') ?? role;
    permissions = prefs.getStringList('post_permissions') ?? [];
    setState(() => loggedIn = true);
    await boot();
  }

  Future<void> login() async {
    final base = (apiController.text.trim().isEmpty ? kDefaultApiBase : apiController.text.trim()).replaceAll(RegExp(r'/+$'), '');
    setState(() => loading = true);
    try {
      api.baseUrl = base;
      final result = await api.login(loginUserController.text.trim(), loginPassController.text);
      api.token = result['token'].toString();
      username = (result['username'] ?? '').toString();
      role = (result['role'] ?? '').toString();
      roleLabel = (result['role_label'] ?? role).toString();
      permissions = (result['permissions'] as List? ?? []).map((e) => e.toString()).toList();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('post_api_base', base);
      await prefs.setString('post_token', api.token);
      await prefs.setString('post_user', username);
      await prefs.setString('post_role', role);
      await prefs.setString('post_role_label', roleLabel);
      await prefs.setStringList('post_permissions', permissions);
      setState(() {
        loggedIn = true;
        pageIndex = has('shipment.create') ? 0 : 1;
      });
      await boot();
      showSnack('ورود موفق بود');
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('post_token');
    await prefs.remove('post_user');
    await prefs.remove('post_role');
    await prefs.remove('post_role_label');
    await prefs.remove('post_permissions');
    api.token = '';
    setState(() {
      loggedIn = false;
      dashboard = null;
      smsStats = null;
      shipments.clear();
      users.clear();
      logs.clear();
      smsMessages.clear();
      smsContacts.clear();
    });
  }

  Future<void> boot() async {
    try {
      if (has('dashboard.view')) await loadDashboard();
      await loadSmsDashboard(silent: true);
      if (has('shipment.view')) await loadShipments();
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> loadDashboard() async {
    if (!has('dashboard.view')) return;
    final result = await api.getJson('/dashboard.php');
    setState(() => dashboard = DashboardData.fromJson(Map<String, dynamic>.from(result['data'])));
  }

  Future<void> loadSmsDashboard({bool silent = false}) async {
    try {
      final result = await api.getJson('/sms_dashboard.php');
      setState(() => smsStats = SmsStats.fromJson(Map<String, dynamic>.from(result['data'])));
    } catch (e) {
      if (!silent) showSnack(e.toString());
    }
  }

  Future<void> loadShipments() async {
    if (!has('shipment.view')) return;
    final query = <String, String>{};
    final q = searchController.text.trim();
    if (q.isNotEmpty) query['q'] = q;
    final result = await api.getJson('/shipments.php', query: query);
    final data = result['data'] as List? ?? [];
    setState(() => shipments = data.map((e) => Shipment.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadUsers() async {
    if (!has('user.view')) return;
    final result = await api.getJson('/users.php');
    final data = result['data'] as List? ?? [];
    setState(() => users = data.map((e) => AppUser.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadLogs() async {
    if (!has('log.view')) return;
    final query = <String, String>{};
    if (logUserController.text.trim().isNotEmpty) query['username'] = logUserController.text.trim();
    if (logAction.isNotEmpty) query['action'] = logAction;
    if (logEntity.isNotEmpty) query['entity'] = logEntity;
    final result = await api.getJson('/logs.php', query: query);
    final data = result['data'] as List? ?? [];
    setState(() => logs = data.map((e) => AppLog.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadSmsMessages() async {
    final query = <String, String>{};
    if (smsSearchController.text.trim().isNotEmpty) query['q'] = smsSearchController.text.trim();
    if (smsTodayOnly && smsSearchController.text.trim().isEmpty) query['today'] = '1';
    final result = await api.getJson('/sms_messages.php', query: query);
    final data = result['data'] as List? ?? [];
    setState(() => smsMessages = data.map((e) => SmsMessage.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  Future<void> loadSmsContacts() async {
    final result = await api.getJson('/sms_contacts.php');
    final data = result['data'] as List? ?? [];
    setState(() => smsContacts = data.map((e) => SmsContact.fromJson(Map<String, dynamic>.from(e as Map))).toList());
  }

  void showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> openPage(int index) async {
    setState(() => pageIndex = index);
    Navigator.of(context).maybePop();
    try {
      if (index == 1) await loadShipments();
      if (index == 2) await loadSmsDashboard(silent: true);
      if (index == 3) await loadSmsMessages();
      if (index == 4) await loadSmsContacts();
      if (index == 5) { await loadDashboard(); await loadSmsDashboard(silent: true); }
      if (index == 6) await loadShipments();
      if (index == 7) await loadUsers();
      if (index == 8) await loadLogs();
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> pickFromCamera() async {
    final photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 82, maxWidth: 1600);
    if (photo == null) return;
    final bytes = await photo.readAsBytes();
    if (!mounted) return;
    setState(() => selectedPhotos.add(PendingPhoto(photo, bytes)));
  }

  Future<void> pickFromGallery() async {
    final photos = await picker.pickMultiImage(imageQuality: 82, maxWidth: 1600);
    final pending = <PendingPhoto>[];
    for (final photo in photos) pending.add(PendingPhoto(photo, await photo.readAsBytes()));
    setState(() => selectedPhotos.addAll(pending));
  }

  Future<void> saveShipment() async {
    if (!has('shipment.create')) return showSnack('شما اجازه ثبت ندارید');
    if (fullnameController.text.trim().isEmpty) return showSnack('نام و نام خانوادگی گیرنده الزامی است');
    setState(() => saving = true);
    try {
      await api.saveShipment(
        fields: {
          'editId': editingShipmentId?.toString() ?? '',
          'fullname': fullnameController.text.trim(),
          'phone': phoneController.text.trim(),
          'shipment_type': shipmentType,
          'receiver_info': receiverController.text.trim(),
          'description': '',
          'shamsi_date': dateVal(jy, jm, jd),
        },
        photos: selectedPhotos,
      );
      resetForm();
      await loadShipments();
      await loadDashboard();
      showSnack('مرسوله ذخیره شد');
      setState(() => pageIndex = 1);
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void resetForm() {
    fullnameController.clear();
    phoneController.clear();
    receiverController.clear();
    editingShipmentId = null;
    shipmentType = shipmentTypes.first;
    selectedPhotos.clear();
    _setToday();
    setState(() {});
  }

  void editShipment(Shipment shipment) {
    if (!has('shipment.edit')) return showSnack('شما اجازه ویرایش ندارید');
    setState(() {
      editingShipmentId = shipment.id;
      fullnameController.text = shipment.fullname;
      phoneController.text = shipment.phone;
      receiverController.text = shipment.receiverInfo;
      shipmentType = shipmentTypes.contains(shipment.shipmentType) ? shipment.shipmentType : shipmentTypes.first;
      selectedPhotos.clear();
      pageIndex = 0;
    });
  }

  Future<bool?> confirm(String message) => showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('تأیید'),
          content: Text(message),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تأیید')),
          ],
        ),
      );

  Future<void> deleteShipment(Shipment shipment) async {
    if (!has('shipment.delete')) return showSnack('شما اجازه حذف ندارید');
    if (await confirm('این مرسوله حذف شود؟') != true) return;
    try {
      await api.deleteJson('/delete.php', query: {'id': shipment.id.toString()});
      await loadShipments();
      await loadDashboard();
      showSnack('مرسوله حذف شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  void resetUserForm() {
    userIdController.clear();
    newUserController.clear();
    newPassController.clear();
    newUserActive = true;
    setState(() {});
  }

  void editUser(AppUser user) {
    if (!has('user.manage')) return showSnack('شما اجازه مدیریت کاربر ندارید');
    userIdController.text = user.id.toString();
    newUserController.text = user.username;
    newPassController.clear();
    newUserActive = user.isActive;
    setState(() {});
    showSnack('کاربر ${user.username} برای ویرایش انتخاب شد');
  }

  Future<void> saveUser() async {
    if (!has('user.manage')) return showSnack('شما اجازه مدیریت کاربر ندارید');
    try {
      await api.postJson('/save_user.php', {
        'id': int.tryParse(userIdController.text) ?? 0,
        'username': newUserController.text.trim(),
        'password': newPassController.text,
        'is_active': newUserActive ? 1 : 0,
      });
      resetUserForm();
      await loadUsers();
      showSnack('کاربر ذخیره شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> disableUser(AppUser user) async {
    if (!has('user.manage')) return;
    if (await confirm('کاربر ${user.username} غیرفعال شود؟') != true) return;
    try {
      await api.deleteJson('/delete_user.php', query: {'id': user.id.toString()});
      await loadUsers();
      showSnack('کاربر غیرفعال شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> sendSms() async {
    final numbers = smsNumbersController.text.trim();
    final text = smsTextController.text.trim();
    if (numbers.isEmpty || text.isEmpty) return showSnack('شماره گیرنده و متن پیام را وارد کنید');
    setState(() => sendingSms = true);
    try {
      final result = await api.postJson('/sms_send.php', {
        'service': smsService,
        'sender': smsSenderController.text.trim(),
        'receivers': numbers,
        'text': text,
        'group_title': smsGroupController.text.trim(),
      });
      final success = result['success_count'] ?? 0;
      final failed = result['failed_count'] ?? 0;
      smsNumbersController.clear();
      smsGroupController.clear();
      await loadSmsDashboard(silent: true);
      await loadSmsMessages();
      showSnack('ارسال ثبت شد؛ موفق: $success / ناموفق: $failed');
      setState(() => pageIndex = 3);
    } catch (e) {
      showSnack(e.toString());
    } finally {
      if (mounted) setState(() => sendingSms = false);
    }
  }

  Future<void> updateDelivery(SmsMessage message) async {
    if (message.recId.isEmpty) return showSnack('این پیام شناسه دلیوری ندارد');
    try {
      await api.postJson('/sms_delivery.php', {
        'id': message.id,
        'service': message.service,
        'rec_id': message.recId,
        'receiver': message.receiver,
      });
      await loadSmsMessages();
      await loadSmsDashboard(silent: true);
      showSnack('وضعیت دلیوری به‌روزرسانی شد');
    } catch (e) {
      showSnack(e.toString());
    }
  }

  Future<void> shareVcf() async {
    if (smsContacts.isEmpty) return showSnack('شماره‌ای برای ذخیره وجود ندارد');
    final buffer = StringBuffer();
    for (var i = 0; i < smsContacts.length; i++) {
      final c = smsContacts[i];
      final name = (c.name.isNotEmpty ? c.name : 'SMS Contact ${i + 1}').replaceAll('\n', ' ');
      buffer.write('BEGIN:VCARD\nVERSION:3.0\nFN:$name\nTEL;TYPE=CELL:${c.number}\nEND:VCARD\n');
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/sms_contacts.vcf');
    await file.writeAsString(buffer.toString(), encoding: utf8);
    await Share.shareXFiles([XFile(file.path)], text: 'خروجی شماره‌های پنل پیامکی');
  }

  List<Shipment> reportRows() {
    final rows = List<Shipment>.from(shipments);
    if (reportTypeIndex == 0) return rows.where((e) => e.shamsiDate == dateVal(ry, rm, rd)).toList();
    if (reportTypeIndex == 1) return rows.where((e) => e.shamsiDate.startsWith('$ry/${persianMonths[rm - 1]}/')).toList();
    return rows;
  }

  @override
  Widget build(BuildContext context) => loggedIn ? buildShell() : buildLogin();

  Widget buildLogin() {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xff0f172a), Color(0xff1d4ed8), Color(0xff38bdf8)])),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: Card(
                elevation: 18,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('📮✉️', style: TextStyle(fontSize: 50)),
                    const SizedBox(height: 8),
                    const Text('ورود به سامانه', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Text('مرسولات + پنل پیامکی آنلاین', style: TextStyle(color: Colors.blueGrey.shade600)),
                    const SizedBox(height: 18),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xffeef2ff),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: const Color(0xffc7d2fe)),
                      ),
                      child: const Text('اتصال به سرور اصلی فعال است', textAlign: TextAlign.center),
                    ),
                    const SizedBox(height: 12),
                    TextField(controller: loginUserController, decoration: const InputDecoration(labelText: 'نام کاربری')),
                    const SizedBox(height: 12),
                    TextField(controller: loginPassController, obscureText: true, decoration: const InputDecoration(labelText: 'رمز عبور')),
                    const SizedBox(height: 8),
                    CheckboxListTile(value: rememberMe, onChanged: (v) => setState(() => rememberMe = v ?? true), title: const Text('مرا به خاطر بسپار'), controlAffinity: ListTileControlAffinity.leading, contentPadding: EdgeInsets.zero),
                    const SizedBox(height: 8),
                    SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: loading ? null : login, child: loading ? const CircularProgressIndicator() : const Text('ورود'))),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildShell() {
    final pages = [
      buildShipmentForm(), buildShipmentList(), buildSmsSend(), buildSmsMessages(), buildSmsContacts(), buildDashboard(), buildReport(), buildUsers(), buildLogs()
    ];
    final titles = ['ثبت مرسوله', 'مرسولات', 'ارسال پیامک', 'پیام‌های ثبت‌شده', 'استخراج شماره‌ها', 'داشبورد', 'گزارش مرسولات', 'کاربران', 'لاگ‌ها'];
    return Scaffold(
      appBar: AppBar(
        title: Text(titles[pageIndex], style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        actions: [
          Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Text('$username | $roleLabel', style: const TextStyle(fontSize: 12)))),
          IconButton(onPressed: logout, icon: const Icon(Icons.logout), tooltip: 'خروج'),
        ],
      ),
      drawer: Drawer(child: SafeArea(child: buildDrawer())),
      body: Container(color: const Color(0xfff8fafc), child: SafeArea(child: pages[pageIndex])),
      floatingActionButton: pageIndex == 0 ? null : FloatingActionButton.extended(
        onPressed: () => openPage(0),
        icon: const Icon(Icons.add_box_outlined),
        label: const Text('ثبت سریع'),
      ),
    );
  }

  Widget buildDrawer() {
    Widget item(int index, IconData icon, String title) => ListTile(
          selected: pageIndex == index,
          leading: Icon(icon),
          title: Text(title),
          onTap: () => openPage(index),
        );
    return ListView(padding: EdgeInsets.zero, children: [
      DrawerHeader(
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xff0f4c81), Color(0xff2f80ed)])),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('📮✉️', style: TextStyle(fontSize: 42)),
          const Spacer(),
          Text(username, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
          Text(roleLabel, style: const TextStyle(color: Colors.white70)),
        ]),
      ),
      if (has('shipment.create')) item(0, Icons.add_circle, 'ثبت مرسوله'),
      if (has('shipment.view')) item(1, Icons.inventory_2, 'مرسولات'),
      const Divider(),
      item(2, Icons.send, 'ارسال پیامک'),
      item(3, Icons.mark_chat_read, 'پیام‌های ثبت‌شده'),
      item(4, Icons.contacts, 'استخراج شماره‌ها'),
      const Divider(),
      if (has('dashboard.view')) item(5, Icons.dashboard, 'داشبورد'),
      if (has('report.view')) item(6, Icons.bar_chart, 'گزارش مرسولات'),
      if (has('user.view')) item(7, Icons.people, 'کاربران'),
      if (has('log.view')) item(8, Icons.receipt_long, 'لاگ‌ها'),
      ListTile(leading: const Icon(Icons.logout), title: const Text('خروج'), onTap: logout),
    ]);
  }

  Widget pageList({required List<Widget> children, Future<void> Function()? onRefresh}) {
    final list = ListView(padding: const EdgeInsets.all(16), children: children);
    return onRefresh == null ? list : RefreshIndicator(onRefresh: onRefresh, child: list);
  }

  Widget sectionTitle(String title, [String? subtitle]) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 12, 4, 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          if (subtitle != null) Text(subtitle, style: TextStyle(color: Colors.blueGrey.shade600)),
        ]),
      );

  Widget statCard(String title, Object value, IconData icon) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const Spacer(),
            Text(toFa(value), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Text(title, style: TextStyle(color: Colors.blueGrey.shade600, fontWeight: FontWeight.bold)),
          ]),
        ),
      );

  Widget buildDashboard() {
    final d = dashboard;
    final s = smsStats;
    return pageList(onRefresh: () async { await loadDashboard(); await loadSmsDashboard(); }, children: [
      sectionTitle('داشبورد', 'خلاصه مرسولات و پیامک‌ها'),
      GridView.count(
        crossAxisCount: MediaQuery.sizeOf(context).width > 720 ? 4 : 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 1.35,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        children: [
          statCard('کل مرسولات', d?.total ?? 0, Icons.inventory_2),
          statCard('مرسولات امروز', d?.today ?? 0, Icons.today),
          statCard('کل پیامک‌ها', s?.total ?? 0, Icons.sms),
          statCard('پیامک امروز', s?.today ?? 0, Icons.mark_email_read),
        ],
      ),
      const SizedBox(height: 8),
      Card(child: ListTile(leading: const Icon(Icons.cloud_done), title: const Text('ذخیره پیام‌ها آنلاین است'), subtitle: const Text('پیام‌ها داخل دیتابیس همان سامانه مرسولات ذخیره می‌شوند، نه حافظه گوشی.'))),
      if (d?.latest.isNotEmpty == true) ...[
        sectionTitle('آخرین مرسولات'),
        ...d!.latest.map((e) => Card(child: ListTile(title: Text(e.fullname), subtitle: Text('${e.trackingCode}\n${e.phone}'), isThreeLine: true, leading: shipmentThumbs(e), onTap: () => openPage(1)))).toList(),
      ],
    ]);
  }

  Widget buildShipmentList() {
    if (!has('shipment.view')) return noAccess();
    return pageList(onRefresh: loadShipments, children: [
      sectionTitle('مرسولات'),
      TextField(
        controller: searchController,
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search), labelText: 'جستجو در مرسولات', suffixIcon: IconButton(icon: const Icon(Icons.refresh), onPressed: loadShipments)),
        onChanged: (_) {
          searchDebounce?.cancel();
          searchDebounce = Timer(const Duration(milliseconds: 500), loadShipments);
        },
      ),
      const SizedBox(height: 10),
      if (shipments.isEmpty) emptyBox('مرسوله‌ای پیدا نشد'),
      ...shipments.map((s) => Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  shipmentThumbs(s),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [Expanded(child: Text(s.fullname, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))), Chip(label: Text(statusText[s.status] ?? s.status))]),
                    Text('کد: ${s.trackingCode}'),
                    if (s.phone.isNotEmpty) Text('تلفن: ${s.phone}'),
                    Text('نوع: ${s.shipmentType} | تاریخ: ${s.shamsiDate}'),
                    if (s.receiverInfo.isNotEmpty) Text(s.receiverInfo),
                  ])),
                ]),
                Row(children: [
                  if (has('shipment.edit')) TextButton.icon(onPressed: () => editShipment(s), icon: const Icon(Icons.edit), label: const Text('ویرایش')),
                  if (has('shipment.delete')) TextButton.icon(onPressed: () => deleteShipment(s), icon: const Icon(Icons.delete), label: const Text('حذف')),
                ]),
              ]),
            ),
          )),
    ]);
  }


  Widget shipmentThumbs(Shipment shipment) {
    if (shipment.images.isEmpty) {
      return Container(
        width: 74,
        height: 74,
        decoration: BoxDecoration(color: const Color(0xffeef2f7), borderRadius: BorderRadius.circular(16)),
        child: const Icon(Icons.image_not_supported_outlined, color: Color(0xff64748b)),
      );
    }
    final first = api.imageUrl(shipment.images.first);
    return GestureDetector(
      onTap: () => showShipmentImages(shipment),
      child: Stack(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.network(
            first,
            width: 74,
            height: 74,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              width: 74,
              height: 74,
              decoration: BoxDecoration(color: const Color(0xffeef2f7), borderRadius: BorderRadius.circular(16)),
              child: const Icon(Icons.broken_image_outlined, color: Color(0xff64748b)),
            ),
          ),
        ),
        if (shipment.images.length > 1)
          Positioned(
            left: 4,
            bottom: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(10)),
              child: Text('+${toFa(shipment.images.length - 1)}', style: const TextStyle(color: Colors.white, fontSize: 11)),
            ),
          ),
      ]),
    );
  }

  void showShipmentImages(Shipment shipment) {
    if (shipment.images.isEmpty) return;
    showDialog(
      context: context,
      builder: (context) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Expanded(child: Text(shipment.fullname, style: const TextStyle(fontWeight: FontWeight.w900))),
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
            ]),
            SizedBox(
              height: MediaQuery.sizeOf(context).height * 0.65,
              child: PageView(
                children: shipment.images.map((img) => InteractiveViewer(
                  child: Image.network(api.imageUrl(img), fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Center(child: Text('تصویر قابل نمایش نیست'))),
                )).toList(),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget selectedPhotoPreview() {
    if (selectedPhotos.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 92,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: selectedPhotos.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) => Stack(children: [
          ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(selectedPhotos[i].bytes, width: 92, height: 92, fit: BoxFit.cover)),
          Positioned(
            top: 2,
            left: 2,
            child: InkWell(
              onTap: () => setState(() => selectedPhotos.removeAt(i)),
              child: Container(decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle), padding: const EdgeInsets.all(3), child: const Icon(Icons.close, color: Colors.white, size: 16)),
            ),
          ),
        ]),
      ),
    );
  }

  Widget buildShipmentForm() {
    if (!has('shipment.create')) return noAccess();
    return pageList(children: [
      sectionTitle(editingShipmentId == null ? 'ثبت سریع مرسوله' : 'ویرایش مرسوله', 'این صفحه، صفحه اصلی برنامه است.'),
      TextField(controller: fullnameController, decoration: const InputDecoration(labelText: 'نام و نام خانوادگی گیرنده')),
      const SizedBox(height: 10),
      TextField(controller: phoneController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره تماس')),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: shipmentType, decoration: const InputDecoration(labelText: 'نوع مرسوله'), items: shipmentTypes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => shipmentType = v ?? shipmentTypes.first)),
      const SizedBox(height: 10),
      TextField(controller: receiverController, minLines: 3, maxLines: 5, decoration: const InputDecoration(labelText: 'اطلاعات گیرنده / توضیحات')),
      const SizedBox(height: 10),
      buildDatePicker('تاریخ شمسی', jy, jm, jd, (y, m, d) => setState(() { jy = y; jm = m; jd = d; })),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: [
        FilledButton.tonalIcon(onPressed: pickFromCamera, icon: const Icon(Icons.camera_alt), label: const Text('دوربین')),
        FilledButton.tonalIcon(onPressed: pickFromGallery, icon: const Icon(Icons.photo_library), label: const Text('گالری')),
        if (selectedPhotos.isNotEmpty) FilledButton.tonalIcon(onPressed: () => setState(selectedPhotos.clear), icon: const Icon(Icons.clear), label: Text('حذف عکس‌ها (${selectedPhotos.length})')),
      ]),
      const SizedBox(height: 10),
      selectedPhotoPreview(),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: saving ? null : saveShipment, child: saving ? const CircularProgressIndicator() : const Text('ذخیره مرسوله'))),
    ]);
  }

  Widget buildDatePicker(String title, int y, int m, int d, void Function(int, int, int) onChanged) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: DropdownButtonFormField<int>(value: y, items: List.generate(8, (i) => 1403 + i).map((e) => DropdownMenuItem(value: e, child: Text(toFa(e)))).toList(), onChanged: (v) => onChanged(v ?? y, m, d), decoration: const InputDecoration(labelText: 'سال'))),
              const SizedBox(width: 8),
              Expanded(child: DropdownButtonFormField<int>(value: m, items: List.generate(12, (i) => i + 1).map((e) => DropdownMenuItem(value: e, child: Text(persianMonths[e - 1]))).toList(), onChanged: (v) => onChanged(y, v ?? m, d), decoration: const InputDecoration(labelText: 'ماه'))),
              const SizedBox(width: 8),
              Expanded(child: DropdownButtonFormField<int>(value: d, items: List.generate(31, (i) => i + 1).map((e) => DropdownMenuItem(value: e, child: Text(toFa(e)))).toList(), onChanged: (v) => onChanged(y, m, v ?? d), decoration: const InputDecoration(labelText: 'روز'))),
            ]),
          ]),
        ),
      );

  Widget buildReport() {
    if (!has('report.view')) return noAccess();
    final rows = reportRows();
    return pageList(children: [
      sectionTitle('گزارش مرسولات'),
      SegmentedButton<int>(segments: const [ButtonSegment(value: 0, label: Text('روزانه')), ButtonSegment(value: 1, label: Text('ماهانه')), ButtonSegment(value: 2, label: Text('همه'))], selected: {reportTypeIndex}, onSelectionChanged: (v) => setState(() => reportTypeIndex = v.first)),
      const SizedBox(height: 10),
      if (reportTypeIndex != 2) buildDatePicker('تاریخ گزارش', ry, rm, rd, (y, m, d) => setState(() { ry = y; rm = m; rd = d; })),
      Card(child: ListTile(leading: const Icon(Icons.bar_chart), title: Text('تعداد نتیجه: ${toFa(rows.length)}'))),
      ...rows.map((e) => Card(child: ListTile(title: Text(e.fullname), subtitle: Text('${e.trackingCode} | ${e.shamsiDate}')))),
    ]);
  }

  Widget buildSmsSend() {
    return pageList(children: [
      sectionTitle('ارسال پیامک', 'پیام‌ها بعد از ارسال در دیتابیس آنلاین ذخیره می‌شوند'),
      DropdownButtonFormField<String>(value: smsService, decoration: const InputDecoration(labelText: 'سرویس ارسال'), items: const [DropdownMenuItem(value: 'smsir', child: Text('SMS.ir')), DropdownMenuItem(value: 'melli', child: Text('ملی پیامک'))], onChanged: (v) => setState(() => smsService = v ?? 'smsir')),
      const SizedBox(height: 10),
      TextField(controller: smsSenderController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره خط فرستنده')),
      const SizedBox(height: 10),
      TextField(controller: smsGroupController, decoration: const InputDecoration(labelText: 'عنوان گروه ارسال - اختیاری')),
      const SizedBox(height: 10),
      TextField(controller: smsNumbersController, minLines: 5, maxLines: 10, keyboardType: TextInputType.multiline, decoration: const InputDecoration(labelText: 'شماره گیرنده‌ها + نام اختیاری', hintText: 'مثال:\n09123456789\nعلی احمدی\nیا: 09123456789 علی احمدی')),
      const SizedBox(height: 10),
      TextField(controller: smsTextController, minLines: 5, maxLines: 10, decoration: const InputDecoration(labelText: 'متن پیام')),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(onPressed: sendingSms ? null : sendSms, icon: const Icon(Icons.send), label: sendingSms ? const Text('در حال ارسال...') : const Text('ارسال و ذخیره آنلاین'))),
      const SizedBox(height: 8),
      const Card(child: ListTile(leading: Icon(Icons.security), title: Text('API Key داخل اپ نیست'), subtitle: Text('کلیدهای SMS فقط در هاست و فایل PHP نگهداری می‌شوند.'))),
    ]);
  }

  Widget buildSmsMessages() {
    return pageList(onRefresh: loadSmsMessages, children: [
      sectionTitle('پیام‌های ثبت‌شده'),
      Row(children: [
        Expanded(child: TextField(controller: smsSearchController, decoration: InputDecoration(prefixIcon: const Icon(Icons.search), labelText: 'جستجو شماره، متن یا نام', suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: loadSmsMessages)), onSubmitted: (_) => loadSmsMessages())),
        const SizedBox(width: 8),
        FilterChip(label: const Text('امروز'), selected: smsTodayOnly, onSelected: (v) async { setState(() => smsTodayOnly = v); await loadSmsMessages(); }),
      ]),
      const SizedBox(height: 10),
      if (smsMessages.isEmpty) emptyBox('پیامی پیدا نشد'),
      ...smsMessages.map((m) => Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  CircleAvatar(child: Icon(m.deliveryLevel == 'delivered' ? Icons.check : (m.deliveryLevel == 'failed' ? Icons.close : Icons.more_horiz))),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(m.receiver, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16), textDirection: TextDirection.ltr), if (m.fullName.isNotEmpty) Text(m.fullName)])),
                  Chip(label: Text(m.service == 'smsir' ? 'SMS.ir' : 'ملی')),
                ]),
                const SizedBox(height: 8),
                Text(m.text, maxLines: 3, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 6),
                Text('ارسال: ${m.sendStatus}', style: TextStyle(color: Colors.blueGrey.shade700)),
                Text('دلیوری: ${m.deliveryText.isEmpty ? 'در انتظار' : m.deliveryText}', style: TextStyle(color: Colors.blueGrey.shade700)),
                Text('تاریخ: ${m.createdAt}', style: TextStyle(color: Colors.blueGrey.shade600, fontSize: 12)),
                Row(children: [
                  TextButton.icon(onPressed: m.recId.isEmpty ? null : () => updateDelivery(m), icon: const Icon(Icons.refresh), label: const Text('بررسی دلیوری')),
                  TextButton.icon(onPressed: () { smsNumbersController.text = m.receiver; smsTextController.text = m.text; setState(() => pageIndex = 2); }, icon: const Icon(Icons.replay), label: const Text('ارسال مجدد')),
                ]),
              ]),
            ),
          )),
    ]);
  }

  Widget buildSmsContacts() {
    return pageList(onRefresh: loadSmsContacts, children: [
      sectionTitle('استخراج شماره‌ها', 'از پیام‌های ذخیره‌شده آنلاین'),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: loadSmsContacts, icon: const Icon(Icons.refresh), label: const Text('به‌روزرسانی'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.tonalIcon(onPressed: shareVcf, icon: const Icon(Icons.save_alt), label: const Text('ذخیره VCF'))),
      ]),
      const SizedBox(height: 10),
      Card(child: ListTile(leading: const Icon(Icons.contacts), title: Text('شماره‌های یکتا: ${toFa(smsContacts.length)}'))),
      if (smsContacts.isEmpty) emptyBox('شماره‌ای پیدا نشد'),
      ...smsContacts.map((c) => Card(child: ListTile(leading: const Icon(Icons.person), title: Text(c.number, textDirection: TextDirection.ltr), subtitle: Text((c.name.isNotEmpty ? c.name : 'بدون نام') + ' | تعداد پیام: ${toFa(c.count)}')))),
    ]);
  }

  Widget buildUsers() {
    if (!has('user.view')) return noAccess();
    final isEditingUser = userIdController.text.trim().isNotEmpty;
    return pageList(onRefresh: loadUsers, children: [
      sectionTitle(isEditingUser ? 'ویرایش کاربر' : 'مدیریت کاربران'),
      if (has('user.manage')) Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
        if (isEditingUser)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(color: const Color(0xffeef2ff), borderRadius: BorderRadius.circular(14)),
            child: Text('حالت ویرایش فعال است؛ شناسه کاربر: ${userIdController.text}', textAlign: TextAlign.center),
          ),
        TextField(controller: newUserController, decoration: const InputDecoration(labelText: 'نام کاربری')),
        const SizedBox(height: 10),
        TextField(controller: newPassController, obscureText: true, decoration: InputDecoration(labelText: isEditingUser ? 'رمز جدید؛ اگر خالی بماند تغییر نمی‌کند' : 'رمز عبور')),
        SwitchListTile(value: newUserActive, onChanged: (v) => setState(() => newUserActive = v), title: const Text('کاربر فعال باشد')),
        Row(children: [
          Expanded(child: FilledButton(onPressed: saveUser, child: Text(isEditingUser ? 'ذخیره ویرایش' : 'ثبت کاربر'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton(onPressed: resetUserForm, child: const Text('فرم جدید'))),
        ]),
      ]))),
      if (users.isEmpty) emptyBox('کاربری پیدا نشد'),
      ...users.map((u) => Card(child: ListTile(
        leading: Icon(u.isActive ? Icons.check_circle_outline : Icons.block_outlined),
        title: Text(u.username),
        subtitle: Text('${u.roleLabel} | ${u.isActive ? 'فعال' : 'غیرفعال'} | آخرین ورود: ${u.lastLoginAt}'),
        trailing: has('user.manage') ? Wrap(spacing: 4, children: [
          IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'ویرایش', onPressed: () => editUser(u)),
          if (u.username != 'admin') IconButton(icon: const Icon(Icons.block), tooltip: 'غیرفعال کردن', onPressed: () => disableUser(u)),
        ]) : null,
      ))),
    ]);
  }

  Widget buildLogs() {
    if (!has('log.view')) return noAccess();
    return pageList(onRefresh: loadLogs, children: [
      sectionTitle('لاگ‌ها'),
      TextField(controller: logUserController, decoration: InputDecoration(labelText: 'فیلتر نام کاربری', suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: loadLogs))),
      const SizedBox(height: 10),
      if (logs.isEmpty) emptyBox('لاگی پیدا نشد'),
      ...logs.map((l) => Card(child: ListTile(title: Text('${l.action} | ${l.entity}'), subtitle: Text('${l.username} | ${l.createdAt}\n${l.details}'), isThreeLine: true))),
    ]);
  }

  Widget emptyBox(String text) => Card(child: Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(text, style: TextStyle(color: Colors.blueGrey.shade600)))));
  Widget noAccess() => Center(child: Text('شما به این بخش دسترسی ندارید', style: TextStyle(color: Colors.blueGrey.shade700, fontWeight: FontWeight.bold)));
}
